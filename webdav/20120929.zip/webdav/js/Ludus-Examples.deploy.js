smalltalk.addPackage('Ludus-Examples', {});
smalltalk.addClass('Pong', smalltalk.Game, ['ball', 'score', 'paddle1', 'paddle2', 'speed', 'ai'], 'Ludus-Examples');
smalltalk.addMethod(
'_startGame',
smalltalk.method({
selector: 'startGame',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_width_", [(640)]);return smalltalk.send($rec, "_height_", [(360)]);})(self);
self['@speed']=(10);
smalltalk.send(self['@canvas'], "_style_", [unescape("background-color%3A%20black")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/applause.ogg")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/click.ogg")]);
(function($rec){smalltalk.send($rec, "_createPaddle1", []);smalltalk.send($rec, "_createPaddle2", []);return smalltalk.send($rec, "_createBall", []);})(self);
smalltalk.send(self['@ball'], "_direction_", [smalltalk.send(smalltalk.send([(-1), (1)], "_at_", [smalltalk.send((2), "_atRandom", [])]), "__at", [((($receiver = ((($receiver = smalltalk.send((20), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(10) : smalltalk.send($receiver, "__minus", [(10)]))).klass === smalltalk.Number) ? $receiver /(10) : smalltalk.send($receiver, "__slash", [(10)]))])]);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_createPaddle1',
smalltalk.method({
selector: 'createPaddle1',
fn: function (){
var self=this;
var verticalOffset=nil;
self['@paddle1']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/paddle.png")]);
smalltalk.send(self['@paddle1'], "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send((0), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle1'], "_addFrameGroupNamed_origin_size_frameCount_", ["up", smalltalk.send((15), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle1'], "_addFrameGroupNamed_origin_size_frameCount_", ["down", smalltalk.send((30), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
verticalOffset=((($receiver = smalltalk.send(self['@paddle1'], "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]));
smalltalk.send(self['@paddle1'], "_x_", [(10)]);
smalltalk.send(self['@paddle1'], "_y_", [((($receiver = ((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))).klass === smalltalk.Number) ? $receiver -verticalOffset : smalltalk.send($receiver, "__minus", [verticalOffset]))]);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_createPaddle2',
smalltalk.method({
selector: 'createPaddle2',
fn: function (){
var self=this;
self['@paddle2']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/paddle.png")]);
smalltalk.send(self['@paddle2'], "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send((0), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle2'], "_addFrameGroupNamed_origin_size_frameCount_", ["up", smalltalk.send((15), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle2'], "_addFrameGroupNamed_origin_size_frameCount_", ["down", smalltalk.send((30), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle2'], "_x_", [((($receiver = ((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self['@paddle2'], "_width", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self['@paddle2'], "_width", [])]))).klass === smalltalk.Number) ? $receiver -(10) : smalltalk.send($receiver, "__minus", [(10)]))]);
smalltalk.send(self['@paddle2'], "_y_", [smalltalk.send(self['@paddle1'], "_y", [])]);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_draw',
smalltalk.method({
selector: 'draw',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_clearCanvas", []);smalltalk.send($rec, "_drawSprite_", [self['@paddle1']]);smalltalk.send($rec, "_drawSprite_", [self['@paddle2']]);smalltalk.send($rec, "_drawMiddleLine", []);return smalltalk.send($rec, "_drawSprite_", [self['@ball']]);})(self);
smalltalk.send(self['@paddle1'], "_currentFrameGroup_", ["still"]);
smalltalk.send(self['@paddle2'], "_currentFrameGroup_", ["still"]);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_drawMiddleLine',
smalltalk.method({
selector: 'drawMiddleLine',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_moveTo_y_", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), (0)]);smalltalk.send($rec, "_lineTo_y_", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), smalltalk.send(self, "_height", [])]);smalltalk.send($rec, "_strokeStyle_", ["white"]);return smalltalk.send($rec, "_stroke", []);})(self['@context']);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_goUp_',
smalltalk.method({
selector: 'goUp:',
fn: function (aPaddle){
var self=this;
((($receiver = ((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver <self['@speed'] : smalltalk.send($receiver, "__lt", [self['@speed']]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(aPaddle, "_y_", [((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver -self['@speed'] : smalltalk.send($receiver, "__minus", [self['@speed']]))]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(aPaddle, "_y_", [((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver -self['@speed'] : smalltalk.send($receiver, "__minus", [self['@speed']]))]);})]));
smalltalk.send(aPaddle, "_currentFrameGroup_", ["up"]);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_goDown_',
smalltalk.method({
selector: 'goDown:',
fn: function (aPaddle){
var self=this;
var maxBottom=nil;
maxBottom=((($receiver = ((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver -self['@speed'] : smalltalk.send($receiver, "__minus", [self['@speed']]))).klass === smalltalk.Number) ? $receiver -smalltalk.send(aPaddle, "_height", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(aPaddle, "_height", [])]));
((($receiver = ((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver >maxBottom : smalltalk.send($receiver, "__gt", [maxBottom]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(aPaddle, "_y_", [((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver +self['@speed'] : smalltalk.send($receiver, "__plus", [self['@speed']]))]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(aPaddle, "_y_", [((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver +self['@speed'] : smalltalk.send($receiver, "__plus", [self['@speed']]))]);})]));
smalltalk.send(aPaddle, "_currentFrameGroup_", ["down"]);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_createBall',
smalltalk.method({
selector: 'createBall',
fn: function (){
var self=this;
var offsetX=nil;
var offsetY=nil;
self['@ball']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/ball.png")]);
smalltalk.send(self['@ball'], "_addFrameGroupNamed_origin_size_frameCount_", ["moving", smalltalk.send((0), "__at", [(0)]), smalltalk.send((15), "__at", [(15)]), (6)]);
smalltalk.send(self['@ball'], "_centre_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "__at", [((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))])]);
smalltalk.send(self['@ball'], "_frameRate_", [(5)]);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_processBallMovement',
smalltalk.method({
selector: 'processBallMovement',
fn: function (){
var self=this;
var ballStep=nil;
smalltalk.send(self, "_processBallCollision", []);
smalltalk.send(self['@ball'], "_centre_", [((($receiver = smalltalk.send(self['@ball'], "_centre", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *self['@speed'] : smalltalk.send($receiver, "__star", [self['@speed']])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *self['@speed'] : smalltalk.send($receiver, "__star", [self['@speed']]))]))]);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_processBallCollision',
smalltalk.method({
selector: 'processBallCollision',
fn: function (){
var self=this;
smalltalk.send(self, "_processBallBorderCollision", []);
((($receiver = smalltalk.send(self['@ball'], "_leftCollidesWith_", [self['@paddle1']])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_bounceAgainstPaddle1", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_bounceAgainstPaddle1", []);})]));
((($receiver = smalltalk.send(self['@ball'], "_rightCollidesWith_", [self['@paddle2']])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_bounceAgainstPaddle2", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_bounceAgainstPaddle2", []);})]));
smalltalk.send(self, "_processEndGame", []);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_processEndGame',
smalltalk.method({
selector: 'processEndGame',
fn: function (){
var self=this;
var offsetX=nil;
offsetX=((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self['@ball'], "_width", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self['@ball'], "_width", [])]));
((($receiver = ((($receiver = smalltalk.send(self['@ball'], "_x", [])).klass === smalltalk.Number) ? $receiver <=(0) : smalltalk.send($receiver, "__lt_eq", [(0)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("Right%20player%20wins%21")]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("Right%20player%20wins%21")]);})]));
((($receiver = ((($receiver = smalltalk.send(self['@ball'], "_x", [])).klass === smalltalk.Number) ? $receiver >=offsetX : smalltalk.send($receiver, "__gt_eq", [offsetX]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("Left%20player%20wins%21")]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("Left%20player%20wins%21")]);})]));
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_processBallBorderCollision',
smalltalk.method({
selector: 'processBallBorderCollision',
fn: function (){
var self=this;
var offsetY=nil;
offsetY=((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self['@ball'], "_height", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self['@ball'], "_height", [])]));
((($receiver = smalltalk.send(((($receiver = smalltalk.send(self['@ball'], "_y", [])).klass === smalltalk.Number) ? $receiver <=(0) : smalltalk.send($receiver, "__lt_eq", [(0)])), "_or_", [(function(){return ((($receiver = smalltalk.send(self['@ball'], "_y", [])).klass === smalltalk.Number) ? $receiver >=offsetY : smalltalk.send($receiver, "__gt_eq", [offsetY]));})])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self['@ball'], "_direction_", [((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *smalltalk.send((1), "__at", [(-1)]) : smalltalk.send($receiver, "__star", [smalltalk.send((1), "__at", [(-1)])]))]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self['@ball'], "_direction_", [((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *smalltalk.send((1), "__at", [(-1)]) : smalltalk.send($receiver, "__star", [smalltalk.send((1), "__at", [(-1)])]))]);})]));
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_bounceAgainstPaddle1',
smalltalk.method({
selector: 'bounceAgainstPaddle1',
fn: function (){
var self=this;
var y=nil;
y=smalltalk.send(self, "_verticalAngleFor_", [self['@paddle1']]);
smalltalk.send(self['@ball'], "_direction_", [((($receiver = ((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *smalltalk.send((-1), "__at", [(0)]) : smalltalk.send($receiver, "__star", [smalltalk.send((-1), "__at", [(0)])]))).klass === smalltalk.Number) ? $receiver +smalltalk.send((0), "__at", [y]) : smalltalk.send($receiver, "__plus", [smalltalk.send((0), "__at", [y])]))]);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["click"]), "_play", []);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_bounceAgainstPaddle2',
smalltalk.method({
selector: 'bounceAgainstPaddle2',
fn: function (){
var self=this;
smalltalk.send(self['@ball'], "_direction_", [((($receiver = ((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *smalltalk.send((-1), "__at", [(0)]) : smalltalk.send($receiver, "__star", [smalltalk.send((-1), "__at", [(0)])]))).klass === smalltalk.Number) ? $receiver +smalltalk.send((0), "__at", [smalltalk.send(self, "_verticalAngleFor_", [self['@paddle2']])]) : smalltalk.send($receiver, "__plus", [smalltalk.send((0), "__at", [smalltalk.send(self, "_verticalAngleFor_", [self['@paddle2']])])]))]);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["click"]), "_play", []);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_verticalAngleFor_',
smalltalk.method({
selector: 'verticalAngleFor:',
fn: function (aPaddle){
var self=this;
var impactPosition=nil;
impactPosition=((($receiver = ((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self['@ball'], "_y", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self['@ball'], "_y", [])]))).klass === smalltalk.Number) ? $receiver /smalltalk.send(aPaddle, "_height", []) : smalltalk.send($receiver, "__slash", [smalltalk.send(aPaddle, "_height", [])]));
return ((($receiver = ((($receiver = ((($receiver = impactPosition).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]))).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]));
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_step',
smalltalk.method({
selector: 'step',
fn: function (){
var self=this;
((($receiver = self['@ai']).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return (function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_w", []), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})]);return smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_s", []), (function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);})]);})(self);})() : (function(){return smalltalk.send(self, "_processAI", []);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){return (function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_w", []), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})]);return smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_s", []), (function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);})]);})(self);}), (function(){return smalltalk.send(self, "_processAI", []);})]));
(function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_upArrow", []), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle2']]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_downArrow", []), (function(){return smalltalk.send(self, "_goDown_", [self['@paddle2']]);})]);return smalltalk.send($rec, "_processBallMovement", []);})(self);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_end',
smalltalk.method({
selector: 'end',
fn: function (){
var self=this;
smalltalk.send(self, "_end", [], smalltalk.Game);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["applause"]), "_play", []);
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_withAI',
smalltalk.method({
selector: 'withAI',
fn: function (){
var self=this;
self['@ai']=true;
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_initialize',
smalltalk.method({
selector: 'initialize',
fn: function (){
var self=this;
smalltalk.send(self, "_initialize", [], smalltalk.Game);
self['@ai']=false;
return self;}
}),
smalltalk.Pong);

smalltalk.addMethod(
'_processAI',
smalltalk.method({
selector: 'processAI',
fn: function (){
var self=this;
((($receiver = smalltalk.send(smalltalk.send(self['@step'], "_\\\\", [(5)]), "__eq", [(0)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ball'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver >smalltalk.send(smalltalk.send(self['@paddle1'], "_centre", []), "_y", []) : smalltalk.send($receiver, "__gt", [smalltalk.send(smalltalk.send(self['@paddle1'], "_centre", []), "_y", [])]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);})() : (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);}), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})]));})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ball'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver >smalltalk.send(smalltalk.send(self['@paddle1'], "_centre", []), "_y", []) : smalltalk.send($receiver, "__gt", [smalltalk.send(smalltalk.send(self['@paddle1'], "_centre", []), "_y", [])]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);})() : (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);}), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})]));})]));
return self;}
}),
smalltalk.Pong);



smalltalk.addClass('Sokoban', smalltalk.Game, ['guy', 'walls', 'stepSize', 'boxes', 'exits', 'lastMove', 'floor', 'currentLevel', 'directionDictionary', 'guyOffsetDictionary', 'boxOffsetDictionary'], 'Ludus-Examples');
smalltalk.addMethod(
'_startGame',
smalltalk.method({
selector: 'startGame',
fn: function (){
var self=this;
self['@fps']=(20);
self['@stepSize']=(10);
(function($rec){smalltalk.send($rec, "_width_", [(720)]);return smalltalk.send($rec, "_height_", [(540)]);})(self);
smalltalk.send(self['@canvas'], "_style_", [unescape("border%3A%201px%20solid%3B%20background-image%3A%20url%28%22images/background.png%22%29")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/slide.ogg")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/factory.ogg")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/applause.ogg")]);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["factory"]), "_loop", []);
smalltalk.send(self, "_createLevel", []);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_startPositionFor_',
smalltalk.method({
selector: 'startPositionFor:',
fn: function (aLevel){
var self=this;
try{smalltalk.send(aLevel, "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(8)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(8)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return (function(){throw({name: 'stReturn', selector: '_startPositionFor_', fn: function(){return smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])}})})();})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return (function(){throw({name: 'stReturn', selector: '_startPositionFor_', fn: function(){return smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])}})})();})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(8)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return (function(){throw({name: 'stReturn', selector: '_startPositionFor_', fn: function(){return smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])}})})();})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return (function(){throw({name: 'stReturn', selector: '_startPositionFor_', fn: function(){return smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])}})})();})]));})]);})]));})]);
return self;
} catch(e) {if(e.name === 'stReturn' && e.selector === '_startPositionFor_'){return e.fn()} throw(e)}}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_step',
smalltalk.method({
selector: 'step',
fn: function (){
var self=this;
smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("still", "__comma", [smalltalk.send(self, "_lastMove", [])])]);
(function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_leftArrow", []), (function(){return smalltalk.send(self, "_go_", ["Left"]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_rightArrow", []), (function(){return smalltalk.send(self, "_go_", ["Right"]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_upArrow", []), (function(){return smalltalk.send(self, "_go_", ["Up"]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_downArrow", []), (function(){return smalltalk.send(self, "_go_", ["Down"]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_r", []), (function(){return smalltalk.send(self, "_restartLevel", []);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_m", []), (function(){return smalltalk.send(smalltalk.send(self, "_soundNamed_", ["factory"]), "_stop", []);})]);return smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_n", []), (function(){return smalltalk.send(self, "_advanceLevel", []);})]);})(self);
((($receiver = smalltalk.send(self, "_isLevelOver", [])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_advanceLevel", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_advanceLevel", []);})]));
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_end',
smalltalk.method({
selector: 'end',
fn: function (){
var self=this;
smalltalk.send(self, "_end", [], smalltalk.Game);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["factory"]), "_stop", []);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_isLevelOver',
smalltalk.method({
selector: 'isLevelOver',
fn: function (){
var self=this;
try{var exitCentres=nil;
exitCentres=smalltalk.send(smalltalk.send(self, "_exits", []), "_collect_", [(function(each){return smalltalk.send(each, "_centre", []);})]);
smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(elem){return ((($receiver = smalltalk.send(exitCentres, "_includes_", [smalltalk.send(elem, "_centre", [])])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return (function(){throw({name: 'stReturn', selector: '_isLevelOver', fn: function(){return false}})})();})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return (function(){throw({name: 'stReturn', selector: '_isLevelOver', fn: function(){return false}})})();})]));})]);
(function(){throw({name: 'stReturn', selector: '_isLevelOver', fn: function(){return true}})})();
return self;
} catch(e) {if(e.name === 'stReturn' && e.selector === '_isLevelOver'){return e.fn()} throw(e)}}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_draw',
smalltalk.method({
selector: 'draw',
fn: function (){
var self=this;
smalltalk.send(self, "_clearCanvas", []);
smalltalk.send(smalltalk.send(self, "_floor", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);
smalltalk.send(smalltalk.send(self, "_walls", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);
smalltalk.send(smalltalk.send(self, "_exits", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);
smalltalk.send(self, "_drawSprite_", [self['@guy']]);
smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level1',
smalltalk.method({
selector: 'level1',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (2), (2), (7), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (2), (1), (2), (1), (1), (2), (1), (0), (0), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (1), (2), (2), (2), (1), (2), (1), (1), (2), (1), (1), (1), (1), (2), (2), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (1), (2), (7), (2), (2), (7), (2), (2), (2), (2), (2), (2), (2), (2), (2), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (1), (2), (1), (1), (1), (2), (1), (8), (1), (2), (2), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level2',
smalltalk.method({
selector: 'level2',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (2), (2), (2), (2), (2), (1), (1), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (2), (7), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (7), (1), (1), (1), (1), (2), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (2), (2), (8), (2), (1), (1), (2), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (2), (1), (2), (2), (7), (2), (1), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (2), (1), (1), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (2), (7), (2), (2), (7), (2), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_currentLevel',
smalltalk.method({
selector: 'currentLevel',
fn: function (){
var self=this;
(($receiver = self['@currentLevel']) == nil || $receiver == undefined) ? (function(){return self['@currentLevel']=(1);})() : $receiver;
return smalltalk.send(self, "_perform_", [smalltalk.send("level", "__comma", [smalltalk.send(self['@currentLevel'], "_asString", [])])]);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_advanceLevel',
smalltalk.method({
selector: 'advanceLevel',
fn: function (){
var self=this;
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["applause"]), "_play", []);
(($receiver = smalltalk.send(smalltalk.send(self, "_class", []), "_methodAt_", [smalltalk.send("level", "__comma", [smalltalk.send(((($receiver = self['@currentLevel']).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)])), "_asString", [])])])) == nil || $receiver == undefined) ? (function(){return smalltalk.send(self, "_end", []);})() : (function(){return self['@currentLevel']=((($receiver = self['@currentLevel']).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));})();
smalltalk.send(self, "_clearLevel", []);
smalltalk.send(self, "_createLevel", []);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_createLevel',
smalltalk.method({
selector: 'createLevel',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_createFloor", []);smalltalk.send($rec, "_createExits", []);smalltalk.send($rec, "_createGuy", []);smalltalk.send($rec, "_createBoxes", []);return smalltalk.send($rec, "_createWalls", []);})(self);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_clearLevel',
smalltalk.method({
selector: 'clearLevel',
fn: function (){
var self=this;
self['@boxes']=[];
self['@walls']=[];
self['@exits']=[];
self['@floor']=[];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level3',
smalltalk.method({
selector: 'level3',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (8), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (1), (7), (2), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (2), (2), (7), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (7), (2), (1), (2), (1), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (1), (1), (2), (7), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (9), (9), (9), (2), (2), (2), (2), (7), (2), (2), (7), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level4',
smalltalk.method({
selector: 'level4',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (1), (2), (2), (7), (2), (7), (2), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (7), (7), (1), (7), (2), (2), (7), (2), (1), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (2), (2), (2), (2), (2), (7), (2), (1), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (7), (2), (1), (7), (2), (7), (2), (7), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (2), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (1), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (1), (2), (2), (2), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (2), (7), (2), (2), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (7), (1), (7), (7), (2), (2), (8), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (1), (2), (2), (2), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level5',
smalltalk.method({
selector: 'level5',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (1), (7), (1), (1), (2), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (7), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (1), (1), (1), (2), (2), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (1), (1), (2), (7), (2), (2), (7), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (2), (2), (7), (2), (7), (7), (2), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (1), (1), (7), (2), (2), (7), (2), (8), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (2), (7), (2), (2), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (2), (7), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (2), (1), (1), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level6',
smalltalk.method({
selector: 'level6',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (0), (0), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (0), (1), (1), (8), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (1), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (2), (2), (2), (2), (2), (7), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (2), (1), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (1), (1), (1), (2), (1), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (2), (7), (2), (1), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (7), (1), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (1), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_restartLevel',
smalltalk.method({
selector: 'restartLevel',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_clearLevel", []);return smalltalk.send($rec, "_createLevel", []);})(self);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level7',
smalltalk.method({
selector: 'level7',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (2), (2), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (2), (1), (2), (8), (1), (1), (2), (7), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (2), (2), (7), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (7), (2), (2), (1), (1), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (2), (1), (1), (1), (1), (1), (7), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (7), (2), (2), (1), (1), (1), (2), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (7), (2), (7), (2), (7), (2), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (2), (2), (1), (1), (1), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (7), (7), (2), (1), (0), (1), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (1), (1), (1), (0), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level8',
smalltalk.method({
selector: 'level8',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (7), (2), (2), (2), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (7), (1), (2), (7), (2), (1), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (7), (2), (7), (2), (2), (1), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (2), (7), (1), (2), (1), (2), (2), (1), (1), (1), (1), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (8), (1), (7), (2), (7), (2), (7), (2), (2), (1), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (2), (2), (2), (2), (7), (2), (1), (7), (1), (2), (2), (2), (1), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (2), (2), (2), (7), (2), (2), (2), (2), (7), (2), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (9), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (9), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (9), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level9',
smalltalk.method({
selector: 'level9',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (9), (2), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (1), (1), (2), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (2), (1), (1), (2), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (2), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (7), (7), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (7), (2), (7), (2), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (2), (2), (2), (1), (7), (2), (7), (2), (2), (2), (1), (2), (2), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (8), (2), (7), (2), (2), (7), (2), (2), (2), (2), (7), (2), (2), (7), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (2), (7), (7), (2), (7), (2), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level10',
smalltalk.method({
selector: 'level10',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (1), (1), (8), (1), (1), (1), (1), (2), (2), (2), (2), (2), (2), (2), (1), (2), (2), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (7), (2), (2), (2), (7), (7), (2), (2), (7), (2), (7), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (7), (7), (1), (2), (2), (2), (2), (7), (2), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (2), (2), (2), (1), (2), (7), (7), (2), (7), (7), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (1), (1), (2), (2), (2), (1), (2), (2), (7), (2), (2), (2), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (2), (1), (2), (7), (2), (7), (2), (7), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (1), (1), (1), (1), (1), (1), (2), (1), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (1), (2), (1), (2), (2), (1), (2), (2), (7), (2), (7), (2), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (1), (1), (2), (1), (2), (7), (7), (2), (7), (2), (7), (1), (1), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (9), (9), (1), (2), (1), (2), (2), (7), (2), (2), (2), (2), (2), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (9), (9), (1), (2), (1), (2), (7), (7), (7), (2), (7), (7), (7), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (1), (1), (1), (1), (1), (2), (1), (2), (2), (2), (2), (2), (2), (2), (1), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level11',
smalltalk.method({
selector: 'level11',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (0), (1), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (2), (8), (1), (1), (1), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (2), (2), (2), (2), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (1), (2), (2), (7), (2), (7), (7), (1), (1), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (1), (7), (1), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (1), (2), (7), (2), (7), (7), (2), (1), (2), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (7), (2), (1), (2), (2), (1), (2), (7), (2), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (1), (1), (1), (1), (2), (2), (2), (2), (1), (2), (2), (7), (7), (2), (1), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (1), (1), (1), (1), (2), (1), (1), (2), (7), (2), (2), (2), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (1), (9), (2), (2), (2), (2), (1), (1), (1), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (1), (9), (9), (2), (9), (9), (1), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (1), (9), (9), (9), (1), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (1), (9), (9), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level12',
smalltalk.method({
selector: 'level12',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (1), (1), (1), (1), (1), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (2), (7), (2), (7), (2), (7), (2), (7), (1), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (2), (2), (7), (8), (7), (2), (2), (2), (1), (1), (2), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (2), (7), (2), (7), (2), (7), (1), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (2), (2), (7), (2), (7), (2), (2), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (1), (1), (7), (7), (7), (2), (7), (2), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (1), (2), (1), (1), (2), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (2), (1), (1), (2), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (2), (2), (2), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_level13',
smalltalk.method({
selector: 'level13',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (2), (2), (2), (1), (1), (2), (2), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (1), (1), (1), (2), (2), (2), (2), (2), (1), (2), (2), (1), (2), (2), (2), (2), (1), (1), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (2), (1), (7), (2), (1), (2), (2), (1), (2), (2), (9), (9), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (1), (2), (7), (1), (8), (7), (1), (1), (2), (1), (2), (1), (9), (1), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (1), (2), (1), (7), (2), (2), (1), (2), (2), (2), (2), (9), (2), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (2), (2), (2), (2), (7), (2), (1), (2), (1), (2), (1), (9), (1), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (1), (1), (2), (2), (1), (1), (7), (2), (7), (2), (9), (2), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (2), (1), (2), (2), (2), (1), (2), (2), (1), (7), (1), (9), (1), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (1), (2), (7), (2), (2), (7), (2), (2), (2), (7), (2), (2), (7), (9), (9), (9), (2), (1), (0), (0), (0)], [(0), (0), (0), (1), (7), (2), (1), (1), (1), (1), (1), (1), (2), (2), (2), (2), (1), (1), (2), (2), (1), (0), (0), (0)], [(0), (0), (0), (1), (2), (2), (1), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_processMovement',
smalltalk.method({
selector: 'processMovement',
fn: function (){
var self=this;
smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("still", "__comma", [smalltalk.send(self, "_lastMove", [])])]);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_lastMove',
smalltalk.method({
selector: 'lastMove',
fn: function (){
var self=this;
return (($receiver = self['@lastMove']) == nil || $receiver == undefined) ? (function(){return self['@lastMove']="Down";})() : $receiver;
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_moveBox_direction_',
smalltalk.method({
selector: 'moveBox:direction:',
fn: function (aBox, aDirection){
var self=this;
var side=nil;
var offset=nil;
side=smalltalk.send(smalltalk.send(self, "_directionDictionary", []), "_at_", [aDirection]);
offset=smalltalk.send(smalltalk.send(self, "_boxOffsetDictionary", []), "_at_", [aDirection]);
smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver +offset : smalltalk.send($receiver, "__plus", [offset]))]);
((($receiver = smalltalk.send(aBox, "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@walls']]])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return ((($receiver = smalltalk.send(aBox, "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@boxes']]])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){smalltalk.send(smalltalk.send(self, "_soundNamed_", ["slide"]), "_play", []);return smalltalk.send((5), "_timesRepeat_", [(function(){smalltalk.send((function(){return smalltalk.send(aBox, "_moveCentreBy_", [offset]);}), "_valueWithTimeout_", [(100)]);smalltalk.send(self, "_clearCanvas", []);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]);})() : (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){smalltalk.send(smalltalk.send(self, "_soundNamed_", ["slide"]), "_play", []);return smalltalk.send((5), "_timesRepeat_", [(function(){smalltalk.send((function(){return smalltalk.send(aBox, "_moveCentreBy_", [offset]);}), "_valueWithTimeout_", [(100)]);smalltalk.send(self, "_clearCanvas", []);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]);}), (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})]));})() : (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){return ((($receiver = smalltalk.send(aBox, "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@boxes']]])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){smalltalk.send(smalltalk.send(self, "_soundNamed_", ["slide"]), "_play", []);return smalltalk.send((5), "_timesRepeat_", [(function(){smalltalk.send((function(){return smalltalk.send(aBox, "_moveCentreBy_", [offset]);}), "_valueWithTimeout_", [(100)]);smalltalk.send(self, "_clearCanvas", []);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]);})() : (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){smalltalk.send(smalltalk.send(self, "_soundNamed_", ["slide"]), "_play", []);return smalltalk.send((5), "_timesRepeat_", [(function(){smalltalk.send((function(){return smalltalk.send(aBox, "_moveCentreBy_", [offset]);}), "_valueWithTimeout_", [(100)]);smalltalk.send(self, "_clearCanvas", []);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]);}), (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})]));}), (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})]));
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_go_',
smalltalk.method({
selector: 'go:',
fn: function (aDirection){
var self=this;
var side=nil;
var offset=nil;
side=smalltalk.send(smalltalk.send(self, "_directionDictionary", []), "_at_", [aDirection]);
offset=smalltalk.send(smalltalk.send(self, "_guyOffsetDictionary", []), "_at_", [aDirection]);
smalltalk.send(self['@guy'], "_moveCentreBy_", [offset]);
((($receiver = smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@walls']]])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return ((($receiver = smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@boxes']]])).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_moveBox_direction_", [smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithWhichOf:"]), [self['@boxes']]]), aDirection]);smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);})() : (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = ((($receiver = offset).klass === smalltalk.Number) ? $receiver /(8) : smalltalk.send($receiver, "__slash", [(8)]))).klass === smalltalk.Number) ? $receiver *((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)])) : smalltalk.send($receiver, "__star", [((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)]))]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("walk", "__comma", [aDirection])]);})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){smalltalk.send(self, "_moveBox_direction_", [smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithWhichOf:"]), [self['@boxes']]]), aDirection]);smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);}), (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = ((($receiver = offset).klass === smalltalk.Number) ? $receiver /(8) : smalltalk.send($receiver, "__slash", [(8)]))).klass === smalltalk.Number) ? $receiver *((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)])) : smalltalk.send($receiver, "__star", [((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)]))]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("walk", "__comma", [aDirection])]);})]));})() : (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){return ((($receiver = smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@boxes']]])).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_moveBox_direction_", [smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithWhichOf:"]), [self['@boxes']]]), aDirection]);smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);})() : (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = ((($receiver = offset).klass === smalltalk.Number) ? $receiver /(8) : smalltalk.send($receiver, "__slash", [(8)]))).klass === smalltalk.Number) ? $receiver *((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)])) : smalltalk.send($receiver, "__star", [((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)]))]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("walk", "__comma", [aDirection])]);})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){smalltalk.send(self, "_moveBox_direction_", [smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithWhichOf:"]), [self['@boxes']]]), aDirection]);smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);}), (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = ((($receiver = offset).klass === smalltalk.Number) ? $receiver /(8) : smalltalk.send($receiver, "__slash", [(8)]))).klass === smalltalk.Number) ? $receiver *((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)])) : smalltalk.send($receiver, "__star", [((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)]))]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("walk", "__comma", [aDirection])]);})]));}), (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);})]));
self['@lastMove']=aDirection;
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_walls',
smalltalk.method({
selector: 'walls',
fn: function (){
var self=this;
return (($receiver = self['@walls']) == nil || $receiver == undefined) ? (function(){return self['@walls']=[];})() : $receiver;
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_boxes',
smalltalk.method({
selector: 'boxes',
fn: function (){
var self=this;
return (($receiver = self['@boxes']) == nil || $receiver == undefined) ? (function(){return self['@boxes']=[];})() : $receiver;
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_exits',
smalltalk.method({
selector: 'exits',
fn: function (){
var self=this;
return (($receiver = self['@exits']) == nil || $receiver == undefined) ? (function(){return self['@exits']=[];})() : $receiver;
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_floor',
smalltalk.method({
selector: 'floor',
fn: function (){
var self=this;
return (($receiver = self['@floor']) == nil || $receiver == undefined) ? (function(){return self['@floor']=[];})() : $receiver;
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_createGuy',
smalltalk.method({
selector: 'createGuy',
fn: function (){
var self=this;
self['@guy']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/guy.png")]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["walkDown", smalltalk.send((0), "__at", [(0)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["walkUp", smalltalk.send((0), "__at", [(25)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["walkLeft", smalltalk.send((0), "__at", [(50)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["walkRight", smalltalk.send((0), "__at", [(75)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["stillDown", smalltalk.send((50), "__at", [(0)]), smalltalk.send((25), "__at", [(25)]), (1)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["stillUp", smalltalk.send((50), "__at", [(25)]), smalltalk.send((25), "__at", [(25)]), (1)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["stillLeft", smalltalk.send((50), "__at", [(50)]), smalltalk.send((25), "__at", [(25)]), (1)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["stillRight", smalltalk.send((50), "__at", [(75)]), smalltalk.send((25), "__at", [(25)]), (1)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["pushDown", smalltalk.send((75), "__at", [(0)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["pushUp", smalltalk.send((75), "__at", [(25)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["pushLeft", smalltalk.send((75), "__at", [(50)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["pushRight", smalltalk.send((75), "__at", [(75)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_centre_", [smalltalk.send(self, "_startPositionFor_", [smalltalk.send(self, "_currentLevel", [])])]);
smalltalk.send(self['@guy'], "_frameRate_", [(2)]);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_createWalls',
smalltalk.method({
selector: 'createWalls',
fn: function (){
var self=this;
var wall=nil;
smalltalk.send(smalltalk.send(self, "_currentLevel", []), "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){wall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/wall.png")]);smalltalk.send(wall, "_addFrameGroupNamed_origin_size_frameCount_", ["wall", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);(function($rec){smalltalk.send($rec, "_x_", [((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);return smalltalk.send($rec, "_y_", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);})(wall);return smalltalk.send(smalltalk.send(self, "_walls", []), "_add_", [wall]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){wall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/wall.png")]);smalltalk.send(wall, "_addFrameGroupNamed_origin_size_frameCount_", ["wall", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);(function($rec){smalltalk.send($rec, "_x_", [((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);return smalltalk.send($rec, "_y_", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);})(wall);return smalltalk.send(smalltalk.send(self, "_walls", []), "_add_", [wall]);})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){wall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/wall.png")]);smalltalk.send(wall, "_addFrameGroupNamed_origin_size_frameCount_", ["wall", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);(function($rec){smalltalk.send($rec, "_x_", [((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);return smalltalk.send($rec, "_y_", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);})(wall);return smalltalk.send(smalltalk.send(self, "_walls", []), "_add_", [wall]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){wall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/wall.png")]);smalltalk.send(wall, "_addFrameGroupNamed_origin_size_frameCount_", ["wall", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);(function($rec){smalltalk.send($rec, "_x_", [((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);return smalltalk.send($rec, "_y_", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);})(wall);return smalltalk.send(smalltalk.send(self, "_walls", []), "_add_", [wall]);})]));})]);})]));})]);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_createBoxes',
smalltalk.method({
selector: 'createBoxes',
fn: function (){
var self=this;
var box=nil;
smalltalk.send(smalltalk.send(self, "_currentLevel", []), "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(7)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(7)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){box=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/box.png")]);smalltalk.send(box, "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send(((($receiver = ((($receiver = smalltalk.send((6), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]))).klass === smalltalk.Number) ? $receiver *(28) : smalltalk.send($receiver, "__star", [(28)])), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(box, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_add_", [box]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){box=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/box.png")]);smalltalk.send(box, "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send(((($receiver = ((($receiver = smalltalk.send((6), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]))).klass === smalltalk.Number) ? $receiver *(28) : smalltalk.send($receiver, "__star", [(28)])), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(box, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_add_", [box]);})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(7)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){box=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/box.png")]);smalltalk.send(box, "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send(((($receiver = ((($receiver = smalltalk.send((6), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]))).klass === smalltalk.Number) ? $receiver *(28) : smalltalk.send($receiver, "__star", [(28)])), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(box, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_add_", [box]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){box=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/box.png")]);smalltalk.send(box, "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send(((($receiver = ((($receiver = smalltalk.send((6), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]))).klass === smalltalk.Number) ? $receiver *(28) : smalltalk.send($receiver, "__star", [(28)])), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(box, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_add_", [box]);})]));})]);})]));})]);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_createExits',
smalltalk.method({
selector: 'createExits',
fn: function (){
var self=this;
var exit=nil;
smalltalk.send(smalltalk.send(self, "_currentLevel", []), "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(9)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(9)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){exit=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/exit.png")]);smalltalk.send(exit, "_addFrameGroupNamed_origin_size_frameCount_", ["exit", smalltalk.send((0), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(exit, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_exits", []), "_add_", [exit]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){exit=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/exit.png")]);smalltalk.send(exit, "_addFrameGroupNamed_origin_size_frameCount_", ["exit", smalltalk.send((0), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(exit, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_exits", []), "_add_", [exit]);})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(9)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){exit=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/exit.png")]);smalltalk.send(exit, "_addFrameGroupNamed_origin_size_frameCount_", ["exit", smalltalk.send((0), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(exit, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_exits", []), "_add_", [exit]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){exit=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/exit.png")]);smalltalk.send(exit, "_addFrameGroupNamed_origin_size_frameCount_", ["exit", smalltalk.send((0), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(exit, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_exits", []), "_add_", [exit]);})]));})]);})]));})]);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_createFloor',
smalltalk.method({
selector: 'createFloor',
fn: function (){
var self=this;
var tile=nil;
smalltalk.send(smalltalk.send(self, "_currentLevel", []), "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = ((($receiver = eachColumn).klass === smalltalk.Number) ? $receiver >(1) : smalltalk.send($receiver, "__gt", [(1)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){tile=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/floor.png")]);smalltalk.send(tile, "_addFrameGroupNamed_origin_size_frameCount_", ["tile", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);smalltalk.send(tile, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_floor", []), "_add_", [tile]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){tile=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/floor.png")]);smalltalk.send(tile, "_addFrameGroupNamed_origin_size_frameCount_", ["tile", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);smalltalk.send(tile, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_floor", []), "_add_", [tile]);})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = ((($receiver = eachColumn).klass === smalltalk.Number) ? $receiver >(1) : smalltalk.send($receiver, "__gt", [(1)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){tile=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/floor.png")]);smalltalk.send(tile, "_addFrameGroupNamed_origin_size_frameCount_", ["tile", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);smalltalk.send(tile, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_floor", []), "_add_", [tile]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){tile=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/floor.png")]);smalltalk.send(tile, "_addFrameGroupNamed_origin_size_frameCount_", ["tile", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);smalltalk.send(tile, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_floor", []), "_add_", [tile]);})]));})]);})]));})]);
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_directionDictionary',
smalltalk.method({
selector: 'directionDictionary',
fn: function (){
var self=this;
return (($receiver = self['@directionDictionary']) == nil || $receiver == undefined) ? (function(){return self['@directionDictionary']=smalltalk.HashedCollection._fromPairs_([smalltalk.send("Down", "__minus_gt", ["bottom"]),smalltalk.send("Up", "__minus_gt", ["top"]),smalltalk.send("Left", "__minus_gt", ["left"]),smalltalk.send("Right", "__minus_gt", ["right"])]);})() : $receiver;
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_guyOffsetDictionary',
smalltalk.method({
selector: 'guyOffsetDictionary',
fn: function (){
var self=this;
return (($receiver = self['@guyOffsetDictionary']) == nil || $receiver == undefined) ? (function(){return self['@guyOffsetDictionary']=smalltalk.HashedCollection._fromPairs_([smalltalk.send("Down", "__minus_gt", [smalltalk.send((0), "__at", [(8)])]),smalltalk.send("Up", "__minus_gt", [smalltalk.send((0), "__at", [(-8)])]),smalltalk.send("Left", "__minus_gt", [smalltalk.send((-8), "__at", [(0)])]),smalltalk.send("Right", "__minus_gt", [smalltalk.send((8), "__at", [(0)])])]);})() : $receiver;
return self;}
}),
smalltalk.Sokoban);

smalltalk.addMethod(
'_boxOffsetDictionary',
smalltalk.method({
selector: 'boxOffsetDictionary',
fn: function (){
var self=this;
return (($receiver = self['@boxOffsetDictionary']) == nil || $receiver == undefined) ? (function(){return self['@boxOffsetDictionary']=smalltalk.HashedCollection._fromPairs_([smalltalk.send("Down", "__minus_gt", [smalltalk.send((0), "__at", [(5)])]),smalltalk.send("Up", "__minus_gt", [smalltalk.send((0), "__at", [(-5)])]),smalltalk.send("Left", "__minus_gt", [smalltalk.send((-5), "__at", [(0)])]),smalltalk.send("Right", "__minus_gt", [smalltalk.send((5), "__at", [(0)])])]);})() : $receiver;
return self;}
}),
smalltalk.Sokoban);



smalltalk.addClass('SimplePacman', smalltalk.Game, ['pacman', 'ghost', 'pills'], 'Ludus-Examples');
smalltalk.addMethod(
'_startGame',
smalltalk.method({
selector: 'startGame',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_width_", [(720)]);smalltalk.send($rec, "_height_", [(540)]);return smalltalk.send($rec, "_backgroundColor_", ["black"]);})(self);
smalltalk.send(self, "_createPacman", []);
smalltalk.send(self, "_createGhost", []);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_createPacman',
smalltalk.method({
selector: 'createPacman',
fn: function (){
var self=this;
self['@pacman']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/pacman.png")]);
smalltalk.send(self['@pacman'], "_addFrameGroupNamed_origin_size_frameCount_", ["left", smalltalk.send((0), "__at", [(0)]), smalltalk.send((50), "__at", [(50)]), (2)]);
smalltalk.send(self['@pacman'], "_addFrameGroupNamed_origin_size_frameCount_", ["right", smalltalk.send((0), "__at", [(50)]), smalltalk.send((50), "__at", [(50)]), (2)]);
smalltalk.send(self['@pacman'], "_addFrameGroupNamed_origin_size_frameCount_", ["down", smalltalk.send((100), "__at", [(0)]), smalltalk.send((50), "__at", [(50)]), (2)]);
smalltalk.send(self['@pacman'], "_addFrameGroupNamed_origin_size_frameCount_", ["up", smalltalk.send((100), "__at", [(50)]), smalltalk.send((50), "__at", [(50)]), (2)]);
smalltalk.send(self['@pacman'], "_centre_", [smalltalk.send((100), "__at", [(100)])]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_createGhost',
smalltalk.method({
selector: 'createGhost',
fn: function (){
var self=this;
self['@ghost']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/ghost.png")]);
smalltalk.send(self['@ghost'], "_addFrameGroupNamed_origin_size_frameCount_", ["down", smalltalk.send((0), "__at", [(0)]), smalltalk.send((50), "__at", [(55)]), (2)]);
smalltalk.send(self['@ghost'], "_addFrameGroupNamed_origin_size_frameCount_", ["up", smalltalk.send((100), "__at", [(0)]), smalltalk.send((50), "__at", [(55)]), (2)]);
smalltalk.send(self['@ghost'], "_addFrameGroupNamed_origin_size_frameCount_", ["right", smalltalk.send((0), "__at", [(55)]), smalltalk.send((50), "__at", [(55)]), (2)]);
smalltalk.send(self['@ghost'], "_addFrameGroupNamed_origin_size_frameCount_", ["left", smalltalk.send((100), "__at", [(55)]), smalltalk.send((50), "__at", [(55)]), (2)]);
smalltalk.send(self['@ghost'], "_centre_", [smalltalk.send((500), "__at", [(500)])]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_draw',
smalltalk.method({
selector: 'draw',
fn: function (){
var self=this;
smalltalk.send(self, "_clearCanvas", []);
smalltalk.send(self, "_drawSprite_", [self['@ghost']]);
smalltalk.send(self, "_drawSprite_", [self['@pacman']]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveUp',
smalltalk.method({
selector: 'moveUp',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@pacman'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver <=(25) : smalltalk.send($receiver, "__lt_eq", [(25)]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(-15)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(-15)])]);})]));
smalltalk.send(self['@pacman'], "_currentFrameGroup_", ["up"]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveDown',
smalltalk.method({
selector: 'moveDown',
fn: function (){
var self=this;
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@pacman'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver +(25) : smalltalk.send($receiver, "__plus", [(25)]))).klass === smalltalk.Number) ? $receiver >=smalltalk.send(self, "_height", []) : smalltalk.send($receiver, "__gt_eq", [smalltalk.send(self, "_height", [])]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(15)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(15)])]);})]));
smalltalk.send(self['@pacman'], "_currentFrameGroup_", ["down"]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveLeft',
smalltalk.method({
selector: 'moveLeft',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@pacman'], "_centre", []), "_x", [])).klass === smalltalk.Number) ? $receiver <=(25) : smalltalk.send($receiver, "__lt_eq", [(25)]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((-15), "__at", [(0)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((-15), "__at", [(0)])]);})]));
smalltalk.send(self['@pacman'], "_currentFrameGroup_", ["left"]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveRight',
smalltalk.method({
selector: 'moveRight',
fn: function (){
var self=this;
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@pacman'], "_centre", []), "_x", [])).klass === smalltalk.Number) ? $receiver +(25) : smalltalk.send($receiver, "__plus", [(25)]))).klass === smalltalk.Number) ? $receiver >=smalltalk.send(self, "_width", []) : smalltalk.send($receiver, "__gt_eq", [smalltalk.send(self, "_width", [])]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((15), "__at", [(0)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((15), "__at", [(0)])]);})]));
smalltalk.send(self['@pacman'], "_currentFrameGroup_", ["right"]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveGhost',
smalltalk.method({
selector: 'moveGhost',
fn: function (){
var self=this;
var direction=nil;
direction=smalltalk.send((4), "_atRandom", []);
((($receiver = smalltalk.send(direction, "__eq", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_moveGhostUp", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_moveGhostUp", []);})]));
((($receiver = smalltalk.send(direction, "__eq", [(2)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_moveGhostDown", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_moveGhostDown", []);})]));
((($receiver = smalltalk.send(direction, "__eq", [(3)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_moveGhostLeft", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_moveGhostLeft", []);})]));
((($receiver = smalltalk.send(direction, "__eq", [(4)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_moveGhostRight", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_moveGhostRight", []);})]));
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveGhostDown',
smalltalk.method({
selector: 'moveGhostDown',
fn: function (){
var self=this;
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ghost'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver +(27) : smalltalk.send($receiver, "__plus", [(27)]))).klass === smalltalk.Number) ? $receiver >=smalltalk.send(self, "_height", []) : smalltalk.send($receiver, "__gt_eq", [smalltalk.send(self, "_height", [])]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(15)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(15)])]);})]));
smalltalk.send(self['@ghost'], "_currentFrameGroup_", ["down"]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveGhostLeft',
smalltalk.method({
selector: 'moveGhostLeft',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ghost'], "_centre", []), "_x", [])).klass === smalltalk.Number) ? $receiver <=(25) : smalltalk.send($receiver, "__lt_eq", [(25)]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((-15), "__at", [(0)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((-15), "__at", [(0)])]);})]));
smalltalk.send(self['@ghost'], "_currentFrameGroup_", ["left"]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveGhostUp',
smalltalk.method({
selector: 'moveGhostUp',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ghost'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver <=(27) : smalltalk.send($receiver, "__lt_eq", [(27)]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(-15)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(-15)])]);})]));
smalltalk.send(self['@ghost'], "_currentFrameGroup_", ["up"]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_moveGhostRight',
smalltalk.method({
selector: 'moveGhostRight',
fn: function (){
var self=this;
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ghost'], "_centre", []), "_x", [])).klass === smalltalk.Number) ? $receiver +(25) : smalltalk.send($receiver, "__plus", [(25)]))).klass === smalltalk.Number) ? $receiver >=smalltalk.send(self, "_width", []) : smalltalk.send($receiver, "__gt_eq", [smalltalk.send(self, "_width", [])]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((15), "__at", [(0)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((15), "__at", [(0)])]);})]));
smalltalk.send(self['@ghost'], "_currentFrameGroup_", ["right"]);
return self;}
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
'_step',
smalltalk.method({
selector: 'step',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_leftArrow", []), (function(){return smalltalk.send(self, "_moveLeft", []);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_rightArrow", []), (function(){return smalltalk.send(self, "_moveRight", []);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_upArrow", []), (function(){return smalltalk.send(self, "_moveUp", []);})]);return smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_downArrow", []), (function(){return smalltalk.send(self, "_moveDown", []);})]);})(self);
smalltalk.send(self, "_onMouseClickDo_", [(function(){return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(self, "_mousePosition", []), "_x", []), "_asString", []), "__comma", [unescape("%2C")]), "__comma", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_mousePosition", []), "_y", []), "_asString", [])])]);})]);
smalltalk.send(self, "_moveGhost", []);
((($receiver = smalltalk.send(self['@pacman'], "_collidesWith_", [self['@ghost']])).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("You%20lost%21")]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("You%20lost%21")]);})]));
return self;}
}),
smalltalk.SimplePacman);



smalltalk.addClass('SmallCave', smalltalk.Game, ['ship', 'gravity', 'trail', 'upOrDown', 'bumps', 'goingUp', 'light', 'maxVariation', 'obstaclePositions', 'started', 'scrollSpeed'], 'Ludus-Examples');
smalltalk.addMethod(
'_startGame',
smalltalk.method({
selector: 'startGame',
fn: function (){
var self=this;
self['@fps']=(30);
self['@gravity']=(1.1);
(function($rec){smalltalk.send($rec, "_width_", [(720)]);smalltalk.send($rec, "_height_", [(540)]);return smalltalk.send($rec, "_backgroundColor_", ["black"]);})(self);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_draw',
smalltalk.method({
selector: 'draw',
fn: function (){
var self=this;
((($receiver = smalltalk.send(self, "_started", [])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self, "_drawWelcomeScreen", []);})() : (function(){(function($rec){smalltalk.send($rec, "_clearCanvas", []);smalltalk.send($rec, "_drawCeiling", []);smalltalk.send($rec, "_drawFloor", []);smalltalk.send($rec, "_drawObstacles", []);return smalltalk.send($rec, "_drawSprite_", [self['@ship']]);})(self);return smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_allButLast", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){return smalltalk.send(self, "_drawWelcomeScreen", []);}), (function(){(function($rec){smalltalk.send($rec, "_clearCanvas", []);smalltalk.send($rec, "_drawCeiling", []);smalltalk.send($rec, "_drawFloor", []);smalltalk.send($rec, "_drawObstacles", []);return smalltalk.send($rec, "_drawSprite_", [self['@ship']]);})(self);return smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_allButLast", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]));
smalltalk.send(self, "_onMouseClickDo_", [(function(){return self['@started']=true;})]);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_step',
smalltalk.method({
selector: 'step',
fn: function (){
var self=this;
((($receiver = smalltalk.send(self, "_started", [])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return (function($rec){smalltalk.send($rec, "_detectCollision", []);smalltalk.send($rec, "_updateTrail", []);smalltalk.send($rec, "_updateBumps", []);smalltalk.send($rec, "_updateObstacles", []);smalltalk.send($rec, "_updateDifficulty", []);return smalltalk.send($rec, "_moveShip", []);})(self);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return (function($rec){smalltalk.send($rec, "_detectCollision", []);smalltalk.send($rec, "_updateTrail", []);smalltalk.send($rec, "_updateBumps", []);smalltalk.send($rec, "_updateObstacles", []);smalltalk.send($rec, "_updateDifficulty", []);return smalltalk.send($rec, "_moveShip", []);})(self);})]));
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_ship',
smalltalk.method({
selector: 'ship',
fn: function (){
var self=this;
return (($receiver = self['@ship']) == nil || $receiver == undefined) ? (function(){return self['@ship']=smalltalk.send(smalltalk.send((smalltalk.Ship || Ship), "_new", []), "_centre_", [smalltalk.send((105), "__at", [((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))])]);})() : $receiver;
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_moveShip',
smalltalk.method({
selector: 'moveShip',
fn: function (){
var self=this;
smalltalk.send(self, "_whileMouseUpDo_", [(function(){return smalltalk.send(smalltalk.send(self, "_ship", []), "_increaseSpeed", []);})]);
smalltalk.send(self, "_whileMouseDownDo_", [(function(){return smalltalk.send(smalltalk.send(self, "_ship", []), "_decreaseSpeed", []);})]);
smalltalk.send(smalltalk.send(self, "_ship", []), "_y_", [((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_y", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_speed", [])).klass === smalltalk.Number) ? $receiver *self['@gravity'] : smalltalk.send($receiver, "__star", [self['@gravity']])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_speed", [])).klass === smalltalk.Number) ? $receiver *self['@gravity'] : smalltalk.send($receiver, "__star", [self['@gravity']]))]))]);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_trail',
smalltalk.method({
selector: 'trail',
fn: function (){
var self=this;
return (($receiver = self['@trail']) == nil || $receiver == undefined) ? (function(){self['@trail']=[];smalltalk.send((0), "_to_do_", [(10), (function(i){var ghostBall=nil;
ghostBall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/trail.png")]);smalltalk.send(ghostBall, "_addFrameGroupNamed_origin_size_frameCount_", ["trail", smalltalk.send((0), "__at", [(0)]), smalltalk.send((10), "__at", [(10)]), (1)]);smalltalk.send(ghostBall, "_position_", [smalltalk.send(((($receiver = i).klass === smalltalk.Number) ? $receiver *(10) : smalltalk.send($receiver, "__star", [(10)])), "__at", [((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))])]);return smalltalk.send(self['@trail'], "_add_", [ghostBall]);})]);return self['@trail'];})() : $receiver;
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_updateTrail',
smalltalk.method({
selector: 'updateTrail',
fn: function (){
var self=this;
smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_allButLast", []), "_withIndexDo_", [(function(each, i){return smalltalk.send(each, "_y_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_at_", [((($receiver = i).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]))]), "_y", [])]);})]);
smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_last", []), "_centre_", [smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_last", []), "_x", []), "__at", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_ship", []), "_centre", []), "_y", [])])]);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_drawCeiling',
smalltalk.method({
selector: 'drawCeiling',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_beginPath", []);smalltalk.send($rec, "_moveTo_y_", [(-200), (0)]);return smalltalk.send($rec, "_lineTo_y_", [(-200), smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_first", []), "_y", [])]);})(self['@context']);
smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_allButFirst", []), "_allButLast", []), "_do_", [(function(eachBump){return smalltalk.send(self['@context'], "_lineTo_y_", [smalltalk.send(eachBump, "_x", []), smalltalk.send(eachBump, "_y", [])]);})]);
(function($rec){smalltalk.send($rec, "_lineTo_y_", [smalltalk.send(self, "_width", []), smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_last", []), "_y", [])]);smalltalk.send($rec, "_lineTo_y_", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +(200) : smalltalk.send($receiver, "__plus", [(200)])), (0)]);smalltalk.send($rec, "_closePath", []);smalltalk.send($rec, "_fillStyle_", ["green"]);return smalltalk.send($rec, "_fill", []);})(self['@context']);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_drawFloor',
smalltalk.method({
selector: 'drawFloor',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_beginPath", []);smalltalk.send($rec, "_moveTo_y_", [(-200), smalltalk.send(self, "_height", [])]);return smalltalk.send($rec, "_lineTo_y_", [(-200), ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_first", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_light", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_light", [])]))]);})(self['@context']);
smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_allButFirst", []), "_allButLast", []), "_do_", [(function(eachBump){return smalltalk.send(self['@context'], "_lineTo_y_", [smalltalk.send(eachBump, "_x", []), ((($receiver = smalltalk.send(eachBump, "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_light", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_light", [])]))]);})]);
(function($rec){smalltalk.send($rec, "_lineTo_y_", [smalltalk.send(self, "_width", []), ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_light", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_light", [])]))]);smalltalk.send($rec, "_lineTo_y_", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +(200) : smalltalk.send($receiver, "__plus", [(200)])), smalltalk.send(self, "_height", [])]);smalltalk.send($rec, "_closePath", []);smalltalk.send($rec, "_fillStyle_", ["green"]);return smalltalk.send($rec, "_fill", []);})(self['@context']);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_detectCollision',
smalltalk.method({
selector: 'detectCollision',
fn: function (){
var self=this;
var imageData=nil;
var greenComponent=nil;
imageData=smalltalk.send(self['@context'], "_getImageData_y_width_height_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_ship", []), "_centre", []), "_x", []), ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_ship", []), "_height", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_ship", []), "_height", [])]))).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)])), (1), (1)]);
greenComponent = imageData.data[1];;
((($receiver = ((($receiver = greenComponent).klass === smalltalk.Number) ? $receiver >(0) : smalltalk.send($receiver, "__gt", [(0)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_end", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_end", []);})]));
imageData=smalltalk.send(self['@context'], "_getImageData_y_width_height_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_ship", []), "_centre", []), "_x", []), ((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_y", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)])), (1), (1)]);
greenComponent = imageData.data[1];;
((($receiver = ((($receiver = greenComponent).klass === smalltalk.Number) ? $receiver >(0) : smalltalk.send($receiver, "__gt", [(0)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_end", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_end", []);})]));
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_updateBumps',
smalltalk.method({
selector: 'updateBumps',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_second", []), "_x", [])).klass === smalltalk.Number) ? $receiver <((($receiver = (0) - smalltalk.send(self, "_scrollSpeed", [])).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))])) : smalltalk.send($receiver, "__lt", [((($receiver = (0) - smalltalk.send(self, "_scrollSpeed", [])).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))]))]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){var y=nil;
y=((($receiver = smalltalk.send(self, "_goingUp", [])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]))).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))]));})() : (function(){return ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]));})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]))).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))]));}), (function(){return ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]));})]));smalltalk.send(smalltalk.send(self, "_bumps", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))])), "__at", [y])]);return smalltalk.send(smalltalk.send(self, "_bumps", []), "_remove_", [smalltalk.send(smalltalk.send(self, "_bumps", []), "_first", [])]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){var y=nil;
y=((($receiver = smalltalk.send(self, "_goingUp", [])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]))).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))]));})() : (function(){return ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]));})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]))).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))]));}), (function(){return ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]));})]));smalltalk.send(smalltalk.send(self, "_bumps", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))])), "__at", [y])]);return smalltalk.send(smalltalk.send(self, "_bumps", []), "_remove_", [smalltalk.send(smalltalk.send(self, "_bumps", []), "_first", [])]);})]));
smalltalk.send(smalltalk.send(self, "_bumps", []), "_do_", [(function(each){return smalltalk.send(each, "_x_", [((($receiver = smalltalk.send(each, "_x", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self, "_scrollSpeed", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self, "_scrollSpeed", [])]))]);})]);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_bumps',
smalltalk.method({
selector: 'bumps',
fn: function (){
var self=this;
return (($receiver = self['@bumps']) == nil || $receiver == undefined) ? (function(){return self['@bumps']=smalltalk.send(smalltalk.send((0), "_to_", [(25)]), "_collect_", [(function(x){return smalltalk.send(((($receiver = ((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))).klass === smalltalk.Number) ? $receiver *x : smalltalk.send($receiver, "__star", [x])), "__at", [((($receiver = smalltalk.send(((($receiver = self['@step']).klass === smalltalk.Number) ? $receiver /(20) : smalltalk.send($receiver, "__slash", [(20)])), "_atRandom", [])).klass === smalltalk.Number) ? $receiver +((($receiver = self['@step']).klass === smalltalk.Number) ? $receiver /(20) : smalltalk.send($receiver, "__slash", [(20)])) : smalltalk.send($receiver, "__plus", [((($receiver = self['@step']).klass === smalltalk.Number) ? $receiver /(20) : smalltalk.send($receiver, "__slash", [(20)]))]))]);})]);})() : $receiver;
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_goingUp',
smalltalk.method({
selector: 'goingUp',
fn: function (){
var self=this;
(($receiver = self['@goingUp']) == nil || $receiver == undefined) ? (function(){return self['@goingUp']=false;})() : $receiver;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver <(0) : smalltalk.send($receiver, "__lt", [(0)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@goingUp']=false;})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@goingUp']=false;})]));
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_light", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_light", [])]))).klass === smalltalk.Number) ? $receiver >smalltalk.send(self, "_height", []) : smalltalk.send($receiver, "__gt", [smalltalk.send(self, "_height", [])]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@goingUp']=true;})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@goingUp']=true;})]));
return self['@goingUp'];
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_light',
smalltalk.method({
selector: 'light',
fn: function (){
var self=this;
return (($receiver = self['@light']) == nil || $receiver == undefined) ? (function(){return self['@light']=((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver *(0.75) : smalltalk.send($receiver, "__star", [(0.75)]));})() : $receiver;
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_maxVariation',
smalltalk.method({
selector: 'maxVariation',
fn: function (){
var self=this;
return (($receiver = self['@maxVariation']) == nil || $receiver == undefined) ? (function(){return self['@maxVariation']=(2);})() : $receiver;
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_updateDifficulty',
smalltalk.method({
selector: 'updateDifficulty',
fn: function (){
var self=this;
((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_stepCount", []), "_\\\\", [(200)]), "__eq", [(0)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@goingUp']=smalltalk.send([false,true], "_at_", [smalltalk.send((2), "_atRandom", [])]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@goingUp']=smalltalk.send([false,true], "_at_", [smalltalk.send((2), "_atRandom", [])]);})]));
((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_stepCount", []), "_\\\\", [(50)]), "__eq", [(0)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@light']=((($receiver = smalltalk.send(self, "_light", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]));})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@light']=((($receiver = smalltalk.send(self, "_light", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]));})]));
((($receiver = ((($receiver = smalltalk.send(self, "_light", [])).klass === smalltalk.Number) ? $receiver <(20) : smalltalk.send($receiver, "__lt", [(20)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@light']=(20);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@light']=(20);})]));
((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_stepCount", []), "_\\\\", [(1200)]), "__eq", [(0)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){self['@maxVariation']=((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", [])])), "__at", [smalltalk.send(smalltalk.send(self, "_height", []), "_atRandom", [])])]);return self['@scrollSpeed']=((($receiver = smalltalk.send(self, "_scrollSpeed", [])).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){self['@maxVariation']=((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", [])])), "__at", [smalltalk.send(smalltalk.send(self, "_height", []), "_atRandom", [])])]);return self['@scrollSpeed']=((($receiver = smalltalk.send(self, "_scrollSpeed", [])).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));})]));
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_obstaclePositions',
smalltalk.method({
selector: 'obstaclePositions',
fn: function (){
var self=this;
return (($receiver = self['@obstaclePositions']) == nil || $receiver == undefined) ? (function(){return self['@obstaclePositions']=[smalltalk.send(smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "_atRandom", []), "__at", [smalltalk.send(((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "_atRandom", [])]),smalltalk.send(((($receiver = smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "_atRandom", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_width", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_width", [])])), "__at", [((($receiver = smalltalk.send(((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "_atRandom", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))]))])];})() : $receiver;
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_drawObstacles',
smalltalk.method({
selector: 'drawObstacles',
fn: function (){
var self=this;
smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_do_", [(function(each){return (function($rec){smalltalk.send($rec, "_fillStyle_", ["green"]);return smalltalk.send($rec, "_fillRect_y_width_height_", [smalltalk.send(each, "_x", []), smalltalk.send(each, "_y", []), (50), (100)]);})(self['@context']);})]);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_updateObstacles',
smalltalk.method({
selector: 'updateObstacles',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_first", []), "_x", [])).klass === smalltalk.Number) ? $receiver <(-100) : smalltalk.send($receiver, "__lt", [(-100)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", [])])), "__at", [smalltalk.send(smalltalk.send(self, "_height", []), "_atRandom", [])])]);return smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_remove_", [smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_first", [])]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", [])])), "__at", [smalltalk.send(smalltalk.send(self, "_height", []), "_atRandom", [])])]);return smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_remove_", [smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_first", [])]);})]));
smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_do_", [(function(each){return smalltalk.send(each, "_x_", [((($receiver = smalltalk.send(each, "_x", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self, "_scrollSpeed", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self, "_scrollSpeed", [])]))]);})]);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_started',
smalltalk.method({
selector: 'started',
fn: function (){
var self=this;
return (($receiver = self['@started']) == nil || $receiver == undefined) ? (function(){return self['@started']=false;})() : $receiver;
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_drawWelcomeScreen',
smalltalk.method({
selector: 'drawWelcomeScreen',
fn: function (){
var self=this;
var image=nil;
image=new Image();;
smalltalk.send(image, "_src_", [unescape("images/welcome.png")]);
smalltalk.send(self['@context'], "_drawImage_x_y_", [image, (40), (50)]);
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_scrollSpeed',
smalltalk.method({
selector: 'scrollSpeed',
fn: function (){
var self=this;
return (($receiver = self['@scrollSpeed']) == nil || $receiver == undefined) ? (function(){return self['@scrollSpeed']=(5);})() : $receiver;
return self;}
}),
smalltalk.SmallCave);

smalltalk.addMethod(
'_end',
smalltalk.method({
selector: 'end',
fn: function (){
var self=this;
smalltalk.send(self, "_end", [], smalltalk.Game);
smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [smalltalk.send(smalltalk.send(unescape("OUCH%21%20Your%20score%20is%20"), "__comma", [smalltalk.send(smalltalk.send(self, "_stepCount", []), "_asString", [])]), "__comma", [unescape(".%20Refresh%20the%20page%20to%20try%20again%21")])]);
return self;}
}),
smalltalk.SmallCave);



smalltalk.addClass('SokobanLevelCreator', smalltalk.Widget, ['level', 'table', 'palette', 'currentBrush', 'div', 'textarea'], 'Ludus-Examples');
smalltalk.addMethod(
'_renderOn_',
smalltalk.method({
selector: 'renderOn:',
fn: function (html){
var self=this;
smalltalk.send(self, "_renderTableOn_", [html]);
smalltalk.send(self, "_renderPaletteOn_", [html]);
(function($rec){smalltalk.send($rec, "_with_", ["Print Array"]);return smalltalk.send($rec, "_onClick_", [(function(){return smalltalk.send(self, "_renderTextAreaOn_", [html]);})]);})(smalltalk.send(html, "_button", []));
return self;}
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
'_emptyLevel',
smalltalk.method({
selector: 'emptyLevel',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;}
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
'_level',
smalltalk.method({
selector: 'level',
fn: function (){
var self=this;
return (($receiver = self['@level']) == nil || $receiver == undefined) ? (function(){return self['@level']=smalltalk.send(self, "_emptyLevel", []);})() : $receiver;
return self;}
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
'_renderPaletteOn_',
smalltalk.method({
selector: 'renderPaletteOn:',
fn: function (html){
var self=this;
self['@palette']=(function($rec){smalltalk.send($rec, "_id_", ["palette"]);return smalltalk.send($rec, "_with_", [(function(){(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(7)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(7);})]);})(smalltalk.send(html, "_img", []));(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(9)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(9);})]);})(smalltalk.send(html, "_img", []));(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(1)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(1);})]);})(smalltalk.send(html, "_img", []));(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(2)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(2);})]);})(smalltalk.send(html, "_img", []));(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(8)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(8);})]);})(smalltalk.send(html, "_img", []));return (function($rec){smalltalk.send($rec, "_src_", [unescape("images/eraserIcon.png")]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(0);})]);})(smalltalk.send(html, "_img", []));})]);})(smalltalk.send(html, "_table", []));
return self;}
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
'_renderTableOn_',
smalltalk.method({
selector: 'renderTableOn:',
fn: function (html){
var self=this;
self['@table']=(function($rec){smalltalk.send($rec, "_id_", ["levelTable"]);smalltalk.send($rec, "_style_", [unescape("border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B")]);return smalltalk.send($rec, "_with_", [(function(){return smalltalk.send((1), "_to_do_", [(18), (function(y){return (function($rec){smalltalk.send($rec, "_style_", [unescape("border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B")]);smalltalk.send($rec, "_id_", [y]);return smalltalk.send($rec, "_with_", [(function(){return smalltalk.send((1), "_to_do_", [(24), (function(x){var cell=nil;
return cell=(function($rec){smalltalk.send($rec, "_style_", [unescape("border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B%20background-image%3A%20url%28%22images/emptyIcon.png%22%29%3B")]);smalltalk.send($rec, "_id_", [x]);smalltalk.send($rec, "_with_", [(function(){return smalltalk.send(smalltalk.send(html, "_img", []), "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_level", []), "_at_", [y]), "_at_", [x])])]), "__comma", ["Icon.png"])]);})]);smalltalk.send($rec, "_class_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_level", []), "_at_", [y]), "_at_", [x])]);return smalltalk.send($rec, "_onClick_", [(function(){smalltalk.send(smalltalk.send(smalltalk.send(self, "_level", []), "_at_", [y]), "_at_put_", [x, self['@currentBrush']]);return smalltalk.send(self, "_updateTable", []);})]);})(smalltalk.send(html, "_td", []));})]);})]);})(smalltalk.send(html, "_tr", []));})]);})]);})(smalltalk.send(html, "_table", []));
return self;}
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
'_imageFor_',
smalltalk.method({
selector: 'imageFor:',
fn: function (anInteger){
var self=this;
return smalltalk.send(smalltalk.Dictionary._fromPairs_([smalltalk.send((7), "__minus_gt", ["box"]),smalltalk.send((9), "__minus_gt", ["exit"]),smalltalk.send((1), "__minus_gt", ["wall"]),smalltalk.send((2), "__minus_gt", ["floor"]),smalltalk.send((8), "__minus_gt", ["guy"]),smalltalk.send((0), "__minus_gt", ["no"])]), "_at_", [anInteger]);
return self;}
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
'_initialize',
smalltalk.method({
selector: 'initialize',
fn: function (){
var self=this;
smalltalk.send(self, "_initialize", [], smalltalk.Widget);
self['@currentBrush']=(0);
return self;}
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
'_updateTable',
smalltalk.method({
selector: 'updateTable',
fn: function (){
var self=this;
smalltalk.send(self['@table'], "_contents_", [(function(html){return smalltalk.send(self, "_renderTableOn_", [html]);})]);
return self;}
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
'_renderTextAreaOn_',
smalltalk.method({
selector: 'renderTextAreaOn:',
fn: function (html){
var self=this;
self['@textarea']=smalltalk.send(smalltalk.send(html, "_textarea", []), "_with_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_level", []), "_asString", []), "_replace_with_", ["a Array ", smalltalk.send(smalltalk.send((smalltalk.String || String), "_cr", []), "__comma", [unescape("%23")])])]);
return self;}
}),
smalltalk.SokobanLevelCreator);


smalltalk.addMethod(
'_open',
smalltalk.method({
selector: 'open',
fn: function (){
var self=this;
smalltalk.send(smalltalk.send(self, "_new", []), "_appendToJQuery_", [smalltalk.send("body", "_asJQuery", [])]);
return self;}
}),
smalltalk.SokobanLevelCreator.klass);


smalltalk.addClass('Ship', smalltalk.Sprite, ['speed'], 'Ludus-Examples');
smalltalk.addMethod(
'_initialize',
smalltalk.method({
selector: 'initialize',
fn: function (){
var self=this;
smalltalk.send(self, "_initialize", [], smalltalk.Sprite);
(function($rec){smalltalk.send($rec, "_spriteSheet_", [unescape("images/trail.png")]);return smalltalk.send($rec, "_addFrameGroupNamed_origin_size_frameCount_", ["ship", smalltalk.send((0), "__at", [(0)]), smalltalk.send((10), "__at", [(10)]), (1)]);})(self);
return self;}
}),
smalltalk.Ship);

smalltalk.addMethod(
'_speed',
smalltalk.method({
selector: 'speed',
fn: function (){
var self=this;
return (($receiver = self['@speed']) == nil || $receiver == undefined) ? (function(){return self['@speed']=(0);})() : $receiver;
return self;}
}),
smalltalk.Ship);

smalltalk.addMethod(
'_speed_',
smalltalk.method({
selector: 'speed:',
fn: function (aSpeed){
var self=this;
self['@speed']=aSpeed;
return self;}
}),
smalltalk.Ship);

smalltalk.addMethod(
'_increaseSpeed',
smalltalk.method({
selector: 'increaseSpeed',
fn: function (){
var self=this;
smalltalk.send(self, "_speed_", [((($receiver = smalltalk.send(self, "_speed", [])).klass === smalltalk.Number) ? $receiver +(0.5) : smalltalk.send($receiver, "__plus", [(0.5)]))]);
return self;}
}),
smalltalk.Ship);

smalltalk.addMethod(
'_decreaseSpeed',
smalltalk.method({
selector: 'decreaseSpeed',
fn: function (){
var self=this;
smalltalk.send(self, "_speed_", [((($receiver = smalltalk.send(self, "_speed", [])).klass === smalltalk.Number) ? $receiver -(0.5) : smalltalk.send($receiver, "__minus", [(0.5)]))]);
return self;}
}),
smalltalk.Ship);



