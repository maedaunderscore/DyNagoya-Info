smalltalk.addPackage('Ludus-Examples', {});
smalltalk.addClass('Pong', smalltalk.Game, ['ball', 'score', 'paddle1', 'paddle2', 'speed', 'ai'], 'Ludus-Examples');
smalltalk.addMethod(
unescape('_startGame'),
smalltalk.method({
selector: unescape('startGame'),
category: 'not yet classified',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_width_", [(640)]);return smalltalk.send($rec, "_height_", [(360)]);})(self);
self['@speed']=(10);
smalltalk.send(self['@canvas'], "_style_", [unescape("background-color%3A%20black")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/applause.ogg")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/click.ogg")]);
(function($rec){smalltalk.send($rec, "_createPaddle1", []);smalltalk.send($rec, "_createPaddle2", []);return smalltalk.send($rec, "_createBall", []);})(self);
smalltalk.send(self['@ball'], "_direction_", [smalltalk.send(smalltalk.send([(-1), (1)], "_at_", [smalltalk.send((2), "_atRandom", [])]), "__at", [((($receiver = ((($receiver = smalltalk.send((20), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(10) : smalltalk.send($receiver, "__minus", [(10)]))).klass === smalltalk.Number) ? $receiver /(10) : smalltalk.send($receiver, "__slash", [(10)]))])]);
return self;},
args: [],
source: unescape('startGame%0A%09self%20width%3A%20640%3B%20%0A%09%09height%3A%20360.%0A%0A%09speed%20%3A%3D%2010.%0A%0A%09canvas%20style%3A%20%27background-color%3A%20black%27.%0A%0A%09self%20addSound%3A%20%27sounds/applause.ogg%27.%0A%09self%20addSound%3A%20%27sounds/click.ogg%27.%0A%0A%09self%20createPaddle1%3B%0A%09%09createPaddle2%3B%0A%09%09createBall.%0A%0A%09ball%20direction%3A%20%28%23%28-1%201%29%20at%3A%20%282%20atRandom%29%29%20@%20%28%2820%20atRandom%20-%2010%29/10%29.'),
messageSends: ["width:", "height:", "style:", "addSound:", "createPaddle1", "createPaddle2", "createBall", "direction:", unescape("@"), "at:", "atRandom", unescape("/"), unescape("-")],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_createPaddle1'),
smalltalk.method({
selector: unescape('createPaddle1'),
category: 'not yet classified',
fn: function (){
var self=this;
var verticalOffset=nil;
self['@paddle1']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/paddle.png")]);
smalltalk.send(self['@paddle1'], "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send((0), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle1'], "_addFrameGroupNamed_origin_size_frameCount_", ["up", smalltalk.send((15), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle1'], "_addFrameGroupNamed_origin_size_frameCount_", ["down", smalltalk.send((30), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
verticalOffset=((($receiver = smalltalk.send(self['@paddle1'], "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]));
smalltalk.send(self['@paddle1'], "_x_", [(10)]);
smalltalk.send(self['@paddle1'], "_y_", [((($receiver = ((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))).klass === smalltalk.Number) ? $receiver -verticalOffset : smalltalk.send($receiver, "__minus", [verticalOffset]))]);
return self;},
args: [],
source: unescape('createPaddle1%0A%09%7CverticalOffset%7C%0A%09paddle1%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/paddle.png%27.%0A%09paddle1%20addFrameGroupNamed%3A%20%27still%27%20origin%3A%20%280@0%29%20size%3A%20%2815@80%29%20frameCount%3A%201.%0A%09paddle1%20addFrameGroupNamed%3A%20%27up%27%20origin%3A%20%2815@0%29%20size%3A%20%2815@80%29%20frameCount%3A%201.%0A%09paddle1%20addFrameGroupNamed%3A%20%27down%27%20origin%3A%20%2830@0%29%20size%3A%20%2815@80%29%20frameCount%3A%201.%0A%09verticalOffset%20%3A%3D%20paddle1%20height%20/%202.%0A%09paddle1%20x%3A%2010.%0A%09paddle1%20y%3A%20%28%28self%20height%20/%202%29%20-%20verticalOffset%29'),
messageSends: ["spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), unescape("/"), "height", "x:", "y:", unescape("-")],
referencedClasses: ["Sprite"]
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_createPaddle2'),
smalltalk.method({
selector: unescape('createPaddle2'),
category: 'not yet classified',
fn: function (){
var self=this;
self['@paddle2']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/paddle.png")]);
smalltalk.send(self['@paddle2'], "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send((0), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle2'], "_addFrameGroupNamed_origin_size_frameCount_", ["up", smalltalk.send((15), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle2'], "_addFrameGroupNamed_origin_size_frameCount_", ["down", smalltalk.send((30), "__at", [(0)]), smalltalk.send((15), "__at", [(80)]), (1)]);
smalltalk.send(self['@paddle2'], "_x_", [((($receiver = ((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self['@paddle2'], "_width", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self['@paddle2'], "_width", [])]))).klass === smalltalk.Number) ? $receiver -(10) : smalltalk.send($receiver, "__minus", [(10)]))]);
smalltalk.send(self['@paddle2'], "_y_", [smalltalk.send(self['@paddle1'], "_y", [])]);
return self;},
args: [],
source: unescape('createPaddle2%0A%09paddle2%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/paddle.png%27.%0A%09paddle2%20addFrameGroupNamed%3A%20%27still%27%20origin%3A%20%280@0%29%20size%3A%20%2815@80%29%20frameCount%3A%201.%0A%09paddle2%20addFrameGroupNamed%3A%20%27up%27%20origin%3A%20%2815@0%29%20size%3A%20%2815@80%29%20frameCount%3A%201.%0A%09paddle2%20addFrameGroupNamed%3A%20%27down%27%20origin%3A%20%2830@0%29%20size%3A%20%2815@80%29%20frameCount%3A%201.%0A%09paddle2%20x%3A%20self%20width%20-%20paddle2%20width%20-%2010.%0A%09paddle2%20y%3A%20paddle1%20y'),
messageSends: ["spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "x:", unescape("-"), "width", "y:", "y"],
referencedClasses: ["Sprite"]
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_draw'),
smalltalk.method({
selector: unescape('draw'),
category: 'not yet classified',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_clearCanvas", []);smalltalk.send($rec, "_drawSprite_", [self['@paddle1']]);smalltalk.send($rec, "_drawSprite_", [self['@paddle2']]);smalltalk.send($rec, "_drawMiddleLine", []);return smalltalk.send($rec, "_drawSprite_", [self['@ball']]);})(self);
smalltalk.send(self['@paddle1'], "_currentFrameGroup_", ["still"]);
smalltalk.send(self['@paddle2'], "_currentFrameGroup_", ["still"]);
return self;},
args: [],
source: unescape('draw%0A%09%09self%20clearCanvas%3B%0A%09%09%09drawSprite%3A%20paddle1%3B%0A%09%09%09drawSprite%3A%20paddle2%3B%0A%09%09%09drawMiddleLine%3B%0A%09%09%09drawSprite%3A%20ball.%0A%09%09paddle1%20currentFrameGroup%3A%20%27still%27.%0A%09%09paddle2%20currentFrameGroup%3A%20%27still%27'),
messageSends: ["clearCanvas", "drawSprite:", "drawMiddleLine", "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_drawMiddleLine'),
smalltalk.method({
selector: unescape('drawMiddleLine'),
category: 'not yet classified',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_moveTo_y_", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), (0)]);smalltalk.send($rec, "_lineTo_y_", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), smalltalk.send(self, "_height", [])]);smalltalk.send($rec, "_strokeStyle_", ["white"]);return smalltalk.send($rec, "_stroke", []);})(self['@context']);
return self;},
args: [],
source: unescape('drawMiddleLine%0A%09context%0A%09%09moveTo%3A%20%28self%20width%20/%202%29%20y%3A%200%3B%0A%09%09lineTo%3A%20%28self%20width%20/%202%29%20y%3A%20%28self%20height%29%3B%0A%09%09strokeStyle%3A%20%27white%27%3B%0A%09%09stroke.'),
messageSends: ["moveTo:y:", unescape("/"), "width", "lineTo:y:", "height", "strokeStyle:", "stroke"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_goUp_'),
smalltalk.method({
selector: unescape('goUp%3A'),
category: 'not yet classified',
fn: function (aPaddle){
var self=this;
((($receiver = ((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver <self['@speed'] : smalltalk.send($receiver, "__lt", [self['@speed']]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(aPaddle, "_y_", [((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver -self['@speed'] : smalltalk.send($receiver, "__minus", [self['@speed']]))]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(aPaddle, "_y_", [((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver -self['@speed'] : smalltalk.send($receiver, "__minus", [self['@speed']]))]);})]));
smalltalk.send(aPaddle, "_currentFrameGroup_", ["up"]);
return self;},
args: ["aPaddle"],
source: unescape('goUp%3A%20aPaddle%0A%09aPaddle%20y%20%3C%20speed%20%0A%09%09ifFalse%3A%20%0A%09%09%09%5BaPaddle%20y%3A%20aPaddle%20y%20-%20speed%5D.%0A%09aPaddle%20currentFrameGroup%3A%20%27up%27'),
messageSends: ["ifFalse:", unescape("%3C"), "y", "y:", unescape("-"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_goDown_'),
smalltalk.method({
selector: unescape('goDown%3A'),
category: 'not yet classified',
fn: function (aPaddle){
var self=this;
var maxBottom=nil;
maxBottom=((($receiver = ((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver -self['@speed'] : smalltalk.send($receiver, "__minus", [self['@speed']]))).klass === smalltalk.Number) ? $receiver -smalltalk.send(aPaddle, "_height", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(aPaddle, "_height", [])]));
((($receiver = ((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver >maxBottom : smalltalk.send($receiver, "__gt", [maxBottom]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(aPaddle, "_y_", [((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver +self['@speed'] : smalltalk.send($receiver, "__plus", [self['@speed']]))]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(aPaddle, "_y_", [((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver +self['@speed'] : smalltalk.send($receiver, "__plus", [self['@speed']]))]);})]));
smalltalk.send(aPaddle, "_currentFrameGroup_", ["down"]);
return self;},
args: ["aPaddle"],
source: unescape('goDown%3A%20aPaddle%0A%09%7CmaxBottom%7C%0A%09maxBottom%20%3A%3D%20%28%28self%20height%20-%20speed%29%20-%20aPaddle%20height%29.%0A%09%28aPaddle%20y%20%3E%20maxBottom%29%0A%09%09ifFalse%3A%20%0A%09%09%09%5BaPaddle%20y%3A%20aPaddle%20y%20+%20speed%5D.%0A%09aPaddle%20currentFrameGroup%3A%20%27down%27'),
messageSends: [unescape("-"), "height", "ifFalse:", unescape("%3E"), "y", "y:", unescape("+"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_createBall'),
smalltalk.method({
selector: unescape('createBall'),
category: 'not yet classified',
fn: function (){
var self=this;
var offsetX=nil;
var offsetY=nil;
self['@ball']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/ball.png")]);
smalltalk.send(self['@ball'], "_addFrameGroupNamed_origin_size_frameCount_", ["moving", smalltalk.send((0), "__at", [(0)]), smalltalk.send((15), "__at", [(15)]), (6)]);
smalltalk.send(self['@ball'], "_centre_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "__at", [((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))])]);
smalltalk.send(self['@ball'], "_frameRate_", [(5)]);
return self;},
args: [],
source: unescape('createBall%0A%09%7CoffsetX%20offsetY%7C%0A%09ball%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/ball.png%27.%0A%09ball%20addFrameGroupNamed%3A%20%27moving%27%20origin%3A%20%280@0%29%20size%3A%20%2815@15%29%20frameCount%3A%206.%0A%09ball%20centre%3A%20%20%28%28self%20width%20/%202%29%20@%20%28self%20height%20/%202%29%29.%0A%09ball%20frameRate%3A%205.'),
messageSends: ["spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "centre:", unescape("/"), "width", "height", "frameRate:"],
referencedClasses: ["Sprite"]
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_processBallMovement'),
smalltalk.method({
selector: unescape('processBallMovement'),
category: 'not yet classified',
fn: function (){
var self=this;
var ballStep=nil;
smalltalk.send(self, "_processBallCollision", []);
smalltalk.send(self['@ball'], "_centre_", [((($receiver = smalltalk.send(self['@ball'], "_centre", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *self['@speed'] : smalltalk.send($receiver, "__star", [self['@speed']])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *self['@speed'] : smalltalk.send($receiver, "__star", [self['@speed']]))]))]);
return self;},
args: [],
source: unescape('processBallMovement%0A%09%7CballStep%7C%0A%09self%20processBallCollision.%0A%09ball%20centre%3A%20ball%20centre%20+%20%28ball%20direction%20*%20speed%29.'),
messageSends: ["processBallCollision", "centre:", unescape("+"), "centre", unescape("*"), "direction"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_processBallCollision'),
smalltalk.method({
selector: unescape('processBallCollision'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_processBallBorderCollision", []);
((($receiver = smalltalk.send(self['@ball'], "_leftCollidesWith_", [self['@paddle1']])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_bounceAgainstPaddle1", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_bounceAgainstPaddle1", []);})]));
((($receiver = smalltalk.send(self['@ball'], "_rightCollidesWith_", [self['@paddle2']])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_bounceAgainstPaddle2", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_bounceAgainstPaddle2", []);})]));
smalltalk.send(self, "_processEndGame", []);
return self;},
args: [],
source: unescape('processBallCollision%0A%09self%20processBallBorderCollision.%0A%0A%09%28ball%20leftCollidesWith%3A%20paddle1%29%0A%09%09ifTrue%3A%20%5Bself%20bounceAgainstPaddle1%5D.%0A%0A%09%28ball%20rightCollidesWith%3A%20paddle2%29%0A%09%09ifTrue%3A%20%5Bself%20bounceAgainstPaddle2%5D.%0A%0A%09self%20processEndGame'),
messageSends: ["processBallBorderCollision", "ifTrue:", "leftCollidesWith:", "bounceAgainstPaddle1", "rightCollidesWith:", "bounceAgainstPaddle2", "processEndGame"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_processEndGame'),
smalltalk.method({
selector: unescape('processEndGame'),
category: 'not yet classified',
fn: function (){
var self=this;
var offsetX=nil;
offsetX=((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self['@ball'], "_width", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self['@ball'], "_width", [])]));
((($receiver = ((($receiver = smalltalk.send(self['@ball'], "_x", [])).klass === smalltalk.Number) ? $receiver <=(0) : smalltalk.send($receiver, "__lt_eq", [(0)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("Right%20player%20wins%21")]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("Right%20player%20wins%21")]);})]));
((($receiver = ((($receiver = smalltalk.send(self['@ball'], "_x", [])).klass === smalltalk.Number) ? $receiver >=offsetX : smalltalk.send($receiver, "__gt_eq", [offsetX]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("Left%20player%20wins%21")]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("Left%20player%20wins%21")]);})]));
return self;},
args: [],
source: unescape('processEndGame%0A%09%7CoffsetX%7C%0A%0A%09offsetX%20%3A%3D%20%28self%20width%20-%20ball%20width%29.%0A%0A%09%28ball%20x%20%3C%3D%200%29%20%0A%09%09ifTrue%3A%20%5B%20self%20end.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20window%20alert%3A%20%27Right%20player%20wins%21%27%5D.%0A%09%28ball%20x%20%3E%3D%20offsetX%29%0A%09%09ifTrue%3A%20%5B%20self%20end.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20window%20alert%3A%20%27Left%20player%20wins%21%27%5D.'),
messageSends: [unescape("-"), "width", "ifTrue:", unescape("%3C%3D"), "x", "end", "alert:", unescape("%3E%3D")],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_processBallBorderCollision'),
smalltalk.method({
selector: unescape('processBallBorderCollision'),
category: 'not yet classified',
fn: function (){
var self=this;
var offsetY=nil;
offsetY=((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self['@ball'], "_height", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self['@ball'], "_height", [])]));
((($receiver = smalltalk.send(((($receiver = smalltalk.send(self['@ball'], "_y", [])).klass === smalltalk.Number) ? $receiver <=(0) : smalltalk.send($receiver, "__lt_eq", [(0)])), "_or_", [(function(){return ((($receiver = smalltalk.send(self['@ball'], "_y", [])).klass === smalltalk.Number) ? $receiver >=offsetY : smalltalk.send($receiver, "__gt_eq", [offsetY]));})])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self['@ball'], "_direction_", [((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *smalltalk.send((1), "__at", [(-1)]) : smalltalk.send($receiver, "__star", [smalltalk.send((1), "__at", [(-1)])]))]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self['@ball'], "_direction_", [((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *smalltalk.send((1), "__at", [(-1)]) : smalltalk.send($receiver, "__star", [smalltalk.send((1), "__at", [(-1)])]))]);})]));
return self;},
args: [],
source: unescape('processBallBorderCollision%0A%09%7CoffsetY%7C%0A%09offsetY%20%3A%3D%20%28self%20height%20-%20ball%20height%29.%0A%09%28%28ball%20y%20%3C%3D%200%29%20or%3A%20%5B%28ball%20y%20%3E%3D%20offsetY%29%5D%29%20%0A%09%09ifTrue%3A%20%5Bball%20direction%3A%20ball%20direction%20*%20%281@%20-1%29%5D.'),
messageSends: [unescape("-"), "height", "ifTrue:", "or:", unescape("%3C%3D"), "y", unescape("%3E%3D"), "direction:", unescape("*"), "direction", unescape("@")],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_bounceAgainstPaddle1'),
smalltalk.method({
selector: unescape('bounceAgainstPaddle1'),
category: 'not yet classified',
fn: function (){
var self=this;
var y=nil;
y=smalltalk.send(self, "_verticalAngleFor_", [self['@paddle1']]);
smalltalk.send(self['@ball'], "_direction_", [((($receiver = ((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *smalltalk.send((-1), "__at", [(0)]) : smalltalk.send($receiver, "__star", [smalltalk.send((-1), "__at", [(0)])]))).klass === smalltalk.Number) ? $receiver +smalltalk.send((0), "__at", [y]) : smalltalk.send($receiver, "__plus", [smalltalk.send((0), "__at", [y])]))]);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["click"]), "_play", []);
return self;},
args: [],
source: unescape('bounceAgainstPaddle1%0A%09%7Cy%7C%0A%09y%20%3A%3D%20self%20verticalAngleFor%3A%20paddle1.%0A%09ball%20direction%3A%20%28ball%20direction%20*%20%28-1@%200%29%29%20+%20%280%20@%20y%29.%0A%09%28self%20soundNamed%3A%20%27click%27%29%20play.'),
messageSends: ["verticalAngleFor:", "direction:", unescape("+"), unescape("*"), "direction", unescape("@"), "play", "soundNamed:"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_bounceAgainstPaddle2'),
smalltalk.method({
selector: unescape('bounceAgainstPaddle2'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self['@ball'], "_direction_", [((($receiver = ((($receiver = smalltalk.send(self['@ball'], "_direction", [])).klass === smalltalk.Number) ? $receiver *smalltalk.send((-1), "__at", [(0)]) : smalltalk.send($receiver, "__star", [smalltalk.send((-1), "__at", [(0)])]))).klass === smalltalk.Number) ? $receiver +smalltalk.send((0), "__at", [smalltalk.send(self, "_verticalAngleFor_", [self['@paddle2']])]) : smalltalk.send($receiver, "__plus", [smalltalk.send((0), "__at", [smalltalk.send(self, "_verticalAngleFor_", [self['@paddle2']])])]))]);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["click"]), "_play", []);
return self;},
args: [],
source: unescape('bounceAgainstPaddle2%0A%09ball%20direction%3A%20%28ball%20direction%20*%20%28-1@%200%29%29%20+%20%280%20@%20%28self%20verticalAngleFor%3A%20paddle2%29%29.%0A%09%28self%20soundNamed%3A%20%27click%27%29%20play.'),
messageSends: ["direction:", unescape("+"), unescape("*"), "direction", unescape("@"), "verticalAngleFor:", "play", "soundNamed:"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_verticalAngleFor_'),
smalltalk.method({
selector: unescape('verticalAngleFor%3A'),
category: 'not yet classified',
fn: function (aPaddle){
var self=this;
var impactPosition=nil;
impactPosition=((($receiver = ((($receiver = smalltalk.send(aPaddle, "_y", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self['@ball'], "_y", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self['@ball'], "_y", [])]))).klass === smalltalk.Number) ? $receiver /smalltalk.send(aPaddle, "_height", []) : smalltalk.send($receiver, "__slash", [smalltalk.send(aPaddle, "_height", [])]));
return ((($receiver = ((($receiver = ((($receiver = impactPosition).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]))).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]));
return self;},
args: ["aPaddle"],
source: unescape('verticalAngleFor%3A%20aPaddle%0A%20%09%7CimpactPosition%7C%0A%09impactPosition%20%3A%3D%20%28aPaddle%20y%20-%20ball%20y%29%20/%20aPaddle%20height.%0A%09%5E%20%28%28impactPosition%20*%202%29%20+%201%29%20*%20-1.'),
messageSends: [unescape("/"), unescape("-"), "y", "height", unescape("*"), unescape("+")],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_step'),
smalltalk.method({
selector: unescape('step'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = self['@ai']).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return (function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_w", []), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})]);return smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_s", []), (function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);})]);})(self);})() : (function(){return smalltalk.send(self, "_processAI", []);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){return (function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_w", []), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})]);return smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_s", []), (function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);})]);})(self);}), (function(){return smalltalk.send(self, "_processAI", []);})]));
(function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_upArrow", []), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle2']]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_downArrow", []), (function(){return smalltalk.send(self, "_goDown_", [self['@paddle2']]);})]);return smalltalk.send($rec, "_processBallMovement", []);})(self);
return self;},
args: [],
source: unescape('step%0A%09ai%0A%09%09ifFalse%3A%20%5Bself%20whileKeyPressed%3A%20Key%20w%20do%3A%20%5Bself%20goUp%3A%20paddle1%5D%3B%0A%09%09%09whileKeyPressed%3A%20Key%20s%20do%3A%20%5Bself%20goDown%3A%20paddle1%5D%5D%0A%09%09ifTrue%3A%20%5Bself%20processAI%5D.%0A%09self%20whileKeyPressed%3A%20Key%20upArrow%20do%3A%20%5Bself%20goUp%3A%20paddle2%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20downArrow%20do%3A%20%5Bself%20goDown%3A%20paddle2%5D%3B%0A%09%09processBallMovement.'),
messageSends: ["ifFalse:ifTrue:", "whileKeyPressed:do:", "w", "goUp:", "s", "goDown:", "processAI", "upArrow", "downArrow", "processBallMovement"],
referencedClasses: ["Key"]
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_end'),
smalltalk.method({
selector: unescape('end'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_end", [], smalltalk.Game);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["applause"]), "_play", []);
return self;},
args: [],
source: unescape('end%0A%09super%20end.%0A%09%28self%20soundNamed%3A%20%27applause%27%29%20play.'),
messageSends: ["end", "play", "soundNamed:"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_withAI'),
smalltalk.method({
selector: unescape('withAI'),
category: 'not yet classified',
fn: function (){
var self=this;
self['@ai']=true;
return self;},
args: [],
source: unescape('withAI%0A%09ai%20%3A%3D%20true.'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_initialize'),
smalltalk.method({
selector: unescape('initialize'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_initialize", [], smalltalk.Game);
self['@ai']=false;
return self;},
args: [],
source: unescape('initialize%0A%09super%20initialize.%0A%09ai%20%3A%3D%20false.'),
messageSends: ["initialize"],
referencedClasses: []
}),
smalltalk.Pong);

smalltalk.addMethod(
unescape('_processAI'),
smalltalk.method({
selector: unescape('processAI'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = smalltalk.send(smalltalk.send(self['@step'], "_\\\\", [(5)]), "__eq", [(0)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ball'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver >smalltalk.send(smalltalk.send(self['@paddle1'], "_centre", []), "_y", []) : smalltalk.send($receiver, "__gt", [smalltalk.send(smalltalk.send(self['@paddle1'], "_centre", []), "_y", [])]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);})() : (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);}), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})]));})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ball'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver >smalltalk.send(smalltalk.send(self['@paddle1'], "_centre", []), "_y", []) : smalltalk.send($receiver, "__gt", [smalltalk.send(smalltalk.send(self['@paddle1'], "_centre", []), "_y", [])]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);})() : (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){return smalltalk.send(self, "_goDown_", [self['@paddle1']]);}), (function(){return smalltalk.send(self, "_goUp_", [self['@paddle1']]);})]));})]));
return self;},
args: [],
source: unescape('processAI%0A%09%28step%20%5C%5C%205%29%20%3D%200%0A%09%09ifTrue%3A%20%5B%0A%09%09%09ball%20centre%20y%20%3E%20paddle1%20centre%20y%20%0A%09%09%09%09ifTrue%3A%20%5B%20self%20goDown%3A%20paddle1%20%5D%0A%09%09%09%09ifFalse%3A%20%5B%20self%20goUp%3A%20paddle1%20%5D%20%5D'),
messageSends: ["ifTrue:", unescape("%3D"), unescape("%5C%5C%5C%5C"), "ifTrue:ifFalse:", unescape("%3E"), "y", "centre", "goDown:", "goUp:"],
referencedClasses: []
}),
smalltalk.Pong);



smalltalk.addClass('Sokoban', smalltalk.Game, ['guy', 'walls', 'stepSize', 'boxes', 'exits', 'lastMove', 'floor', 'currentLevel', 'directionDictionary', 'guyOffsetDictionary', 'boxOffsetDictionary'], 'Ludus-Examples');
smalltalk.addMethod(
unescape('_startGame'),
smalltalk.method({
selector: unescape('startGame'),
category: 'control',
fn: function (){
var self=this;
self['@fps']=(20);
self['@stepSize']=(10);
(function($rec){smalltalk.send($rec, "_width_", [(720)]);return smalltalk.send($rec, "_height_", [(540)]);})(self);
smalltalk.send(self['@canvas'], "_style_", [unescape("border%3A%201px%20solid%3B%20background-image%3A%20url%28%22images/background.png%22%29")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/slide.ogg")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/factory.ogg")]);
smalltalk.send(self, "_addSound_", [unescape("sounds/applause.ogg")]);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["factory"]), "_loop", []);
smalltalk.send(self, "_createLevel", []);
return self;},
args: [],
source: unescape('startGame%0A%09fps%20%3A%3D%2020.%09%0A%09stepSize%20%3A%3D%2010.%0A%0A%09self%20width%3A%20720%3B%20%0A%09%09height%3A%20540.%0A%0A%09canvas%20style%3A%20%27border%3A%201px%20solid%3B%20background-image%3A%20url%28%22images/background.png%22%29%27.%0A%0A%09self%20addSound%3A%20%27sounds/slide.ogg%27.%0A%09self%20addSound%3A%20%27sounds/factory.ogg%27.%0A%09self%20addSound%3A%20%27sounds/applause.ogg%27.%0A%0A%09%28self%20soundNamed%3A%20%27factory%27%29%20loop.%0A%0A%09self%20createLevel.'),
messageSends: ["width:", "height:", "style:", "addSound:", "loop", "soundNamed:", "createLevel"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_startPositionFor_'),
smalltalk.method({
selector: unescape('startPositionFor%3A'),
category: 'control',
fn: function (aLevel){
var self=this;
try{smalltalk.send(aLevel, "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(8)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(8)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return (function(){throw({name: 'stReturn', selector: '_startPositionFor_', fn: function(){return smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])}})})();})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return (function(){throw({name: 'stReturn', selector: '_startPositionFor_', fn: function(){return smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])}})})();})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(8)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return (function(){throw({name: 'stReturn', selector: '_startPositionFor_', fn: function(){return smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])}})})();})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return (function(){throw({name: 'stReturn', selector: '_startPositionFor_', fn: function(){return smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])}})})();})]));})]);})]));})]);
return self;
} catch(e) {if(e.name === 'stReturn' && e.selector === '_startPositionFor_'){return e.fn()} throw(e)}},
args: ["aLevel"],
source: unescape('startPositionFor%3A%20aLevel%0A%09aLevel%0A%09%09withIndexDo%3A%20%5B%3AeachRow%20%3Ay%20%7C%20%0A%09%09%09%28eachRow%20includes%3A%208%29%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09ifTrue%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5BeachRow%20withIndexDo%3A%20%5B%3AeachColumn%20%3Ax%20%7C%0A%09%09%09%09%09%09eachColumn%20%3D%208%20%0A%09%09%09%09%09%09%09ifTrue%3A%20%5B%20%5E%20%28%28x%20*%2030%29%20-%2015%29%20@%20%28%28y%20*%2030%29%20-%2015%29%20%5D%5D%5D%5D.'),
messageSends: ["withIndexDo:", "ifTrue:", "includes:", unescape("%3D"), unescape("@"), unescape("-"), unescape("*")],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_step'),
smalltalk.method({
selector: unescape('step'),
category: 'control',
fn: function (){
var self=this;
smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("still", "__comma", [smalltalk.send(self, "_lastMove", [])])]);
(function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_leftArrow", []), (function(){return smalltalk.send(self, "_go_", ["Left"]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_rightArrow", []), (function(){return smalltalk.send(self, "_go_", ["Right"]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_upArrow", []), (function(){return smalltalk.send(self, "_go_", ["Up"]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_downArrow", []), (function(){return smalltalk.send(self, "_go_", ["Down"]);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_r", []), (function(){return smalltalk.send(self, "_restartLevel", []);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_m", []), (function(){return smalltalk.send(smalltalk.send(self, "_soundNamed_", ["factory"]), "_stop", []);})]);return smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_n", []), (function(){return smalltalk.send(self, "_advanceLevel", []);})]);})(self);
((($receiver = smalltalk.send(self, "_isLevelOver", [])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_advanceLevel", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_advanceLevel", []);})]));
return self;},
args: [],
source: unescape('step%0A%09guy%20currentFrameGroup%3A%20%27still%27%20%2C%20self%20lastMove.%0A%09self%20whileKeyPressed%3A%20Key%20leftArrow%20do%3A%20%5Bself%20go%3A%20%27Left%27%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20rightArrow%20do%3A%20%5Bself%20go%3A%20%27Right%27%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20upArrow%20do%3A%20%5Bself%20go%3A%20%27Up%27%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20downArrow%20do%3A%20%5Bself%20go%3A%20%27Down%27%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20r%20do%3A%20%5Bself%20restartLevel%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20m%20do%3A%20%5B%28self%20soundNamed%3A%20%27factory%27%29%20stop%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20n%20do%3A%20%5Bself%20advanceLevel%5D.%0A%0A%09self%20isLevelOver%20ifTrue%3A%20%5Bself%20advanceLevel%5D'),
messageSends: ["currentFrameGroup:", unescape("%2C"), "lastMove", "whileKeyPressed:do:", "leftArrow", "go:", "rightArrow", "upArrow", "downArrow", "r", "restartLevel", "m", "stop", "soundNamed:", "n", "advanceLevel", "ifTrue:", "isLevelOver"],
referencedClasses: ["Key"]
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_end'),
smalltalk.method({
selector: unescape('end'),
category: 'control',
fn: function (){
var self=this;
smalltalk.send(self, "_end", [], smalltalk.Game);
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["factory"]), "_stop", []);
return self;},
args: [],
source: unescape('end%0A%09super%20end.%0A%09%28self%20soundNamed%3A%20%27factory%27%29%20stop.'),
messageSends: ["end", "stop", "soundNamed:"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_isLevelOver'),
smalltalk.method({
selector: unescape('isLevelOver'),
category: 'control',
fn: function (){
var self=this;
try{var exitCentres=nil;
exitCentres=smalltalk.send(smalltalk.send(self, "_exits", []), "_collect_", [(function(each){return smalltalk.send(each, "_centre", []);})]);
smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(elem){return ((($receiver = smalltalk.send(exitCentres, "_includes_", [smalltalk.send(elem, "_centre", [])])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return (function(){throw({name: 'stReturn', selector: '_isLevelOver', fn: function(){return false}})})();})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return (function(){throw({name: 'stReturn', selector: '_isLevelOver', fn: function(){return false}})})();})]));})]);
(function(){throw({name: 'stReturn', selector: '_isLevelOver', fn: function(){return true}})})();
return self;
} catch(e) {if(e.name === 'stReturn' && e.selector === '_isLevelOver'){return e.fn()} throw(e)}},
args: [],
source: unescape('isLevelOver%0A%09%7CexitCentres%7C%0A%09exitCentres%20%3A%3D%20%28self%20exits%20collect%3A%20%5B%3Aeach%20%7C%20each%20centre%5D%29.%0A%0A%09self%20boxes%20do%3A%20%5B%3Aelem%20%7C%20%28exitCentres%20includes%3A%20elem%20centre%29%20ifFalse%3A%20%5B%5E%20false%5D%5D.%0A%0A%09%5E%20true'),
messageSends: ["collect:", "exits", "centre", "do:", "boxes", "ifFalse:", "includes:"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_draw'),
smalltalk.method({
selector: unescape('draw'),
category: 'drawing',
fn: function (){
var self=this;
smalltalk.send(self, "_clearCanvas", []);
smalltalk.send(smalltalk.send(self, "_floor", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);
smalltalk.send(smalltalk.send(self, "_walls", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);
smalltalk.send(smalltalk.send(self, "_exits", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);
smalltalk.send(self, "_drawSprite_", [self['@guy']]);
smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);
return self;},
args: [],
source: unescape('draw%0A%09self%20clearCanvas.%0A%20%20%20%20%20%20%20%20self%20floor%20do%3A%20%5B%3Aeach%20%7C%20self%20drawSprite%3A%20each%5D.%0A%09self%20walls%20do%3A%20%5B%3Aeach%20%7C%20self%20drawSprite%3A%20each%5D.%0A%09self%20exits%20do%3A%20%5B%3Aeach%20%7C%20self%20drawSprite%3A%20each%5D.%0A%09self%20drawSprite%3A%20guy.%0A%09self%20boxes%20do%3A%20%5B%3Aeach%20%7C%20self%20drawSprite%3A%20each%5D.'),
messageSends: ["clearCanvas", "do:", "floor", "drawSprite:", "walls", "exits", "boxes"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level1'),
smalltalk.method({
selector: unescape('level1'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (2), (2), (7), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (2), (1), (2), (1), (1), (2), (1), (0), (0), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (1), (2), (2), (2), (1), (2), (1), (1), (2), (1), (1), (1), (1), (2), (2), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (1), (2), (7), (2), (2), (7), (2), (2), (2), (2), (2), (2), (2), (2), (2), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (1), (2), (1), (1), (1), (2), (1), (8), (1), (2), (2), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level1%0A%09%5E%20%20%0A%20%20%20%20%20%23%28%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%201%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%201%202%202%202%201%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%201%207%202%202%201%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%201%201%201%202%202%207%201%201%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%201%202%202%207%202%207%202%201%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%201%201%201%202%201%202%201%201%202%201%200%200%201%201%201%201%201%201%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%201%202%202%202%201%202%201%201%202%201%201%201%201%202%202%209%209%201%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%201%202%207%202%202%207%202%202%202%202%202%202%202%202%202%209%209%201%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%201%201%201%201%201%202%201%201%201%202%201%208%201%202%202%209%209%201%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%201%202%202%202%202%202%201%201%201%201%201%201%201%201%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%201%201%201%201%201%201%201%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level2'),
smalltalk.method({
selector: unescape('level2'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (2), (2), (2), (2), (2), (1), (1), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (2), (7), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (7), (1), (1), (1), (1), (2), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (2), (2), (8), (2), (1), (1), (2), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (2), (1), (2), (2), (7), (2), (1), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (2), (1), (1), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (2), (7), (2), (2), (7), (2), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level2%0A%09%5E%20%20%0A%20%20%20%23%28%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%201%201%201%201%201%201%201%201%201%201%201%201%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%201%209%209%202%202%201%202%202%202%202%202%201%201%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%201%209%209%202%202%201%202%207%202%202%207%202%202%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%201%209%209%202%202%201%207%201%201%201%201%202%202%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%201%209%209%202%202%202%202%208%202%201%201%202%202%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%201%209%209%202%202%201%202%201%202%202%207%202%201%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%201%201%201%201%201%201%202%201%201%207%202%207%202%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%201%202%207%202%202%207%202%207%202%207%202%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%201%202%202%202%202%201%202%202%202%202%202%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%201%201%201%201%201%201%201%201%201%201%201%201%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_currentLevel'),
smalltalk.method({
selector: unescape('currentLevel'),
category: 'levels',
fn: function (){
var self=this;
(($receiver = self['@currentLevel']) == nil || $receiver == undefined) ? (function(){return self['@currentLevel']=(1);})() : $receiver;
return smalltalk.send(self, "_perform_", [smalltalk.send("level", "__comma", [smalltalk.send(self['@currentLevel'], "_asString", [])])]);
return self;},
args: [],
source: unescape('currentLevel%0A%09currentLevel%20ifNil%3A%20%5BcurrentLevel%20%3A%3D%201%5D.%0A%09%5E%20self%20perform%3A%20%27level%27%20%2C%20currentLevel%20asString'),
messageSends: ["ifNil:", "perform:", unescape("%2C"), "asString"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_advanceLevel'),
smalltalk.method({
selector: unescape('advanceLevel'),
category: 'levels',
fn: function (){
var self=this;
smalltalk.send(smalltalk.send(self, "_soundNamed_", ["applause"]), "_play", []);
(($receiver = smalltalk.send(smalltalk.send(self, "_class", []), "_methodAt_", [smalltalk.send("level", "__comma", [smalltalk.send(((($receiver = self['@currentLevel']).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)])), "_asString", [])])])) == nil || $receiver == undefined) ? (function(){return smalltalk.send(self, "_end", []);})() : (function(){return self['@currentLevel']=((($receiver = self['@currentLevel']).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));})();
smalltalk.send(self, "_clearLevel", []);
smalltalk.send(self, "_createLevel", []);
return self;},
args: [],
source: unescape('advanceLevel%0A%09%28self%20soundNamed%3A%20%27applause%27%29%20play.%0A%09%28self%20class%20methodAt%3A%20%27level%27%20%2C%20%28currentLevel%20+%201%29%20asString%29%20%0A%09%09ifNil%3A%20%5Bself%20end%5D%0A%09%09ifNotNil%3A%09%5BcurrentLevel%20%3A%3D%20currentLevel%20+%201%5D.%0A%09self%20clearLevel.%0A%09self%20createLevel.'),
messageSends: ["play", "soundNamed:", "ifNil:ifNotNil:", "methodAt:", "class", unescape("%2C"), "asString", unescape("+"), "end", "clearLevel", "createLevel"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_createLevel'),
smalltalk.method({
selector: unescape('createLevel'),
category: 'levels',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_createFloor", []);smalltalk.send($rec, "_createExits", []);smalltalk.send($rec, "_createGuy", []);smalltalk.send($rec, "_createBoxes", []);return smalltalk.send($rec, "_createWalls", []);})(self);
return self;},
args: [],
source: unescape('createLevel%0A%09self%20createFloor%3B%0A%09%09createExits%3B%0A%09%09createGuy%3B%0A%09%09createBoxes%3B%0A%09%09createWalls.'),
messageSends: ["createFloor", "createExits", "createGuy", "createBoxes", "createWalls"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_clearLevel'),
smalltalk.method({
selector: unescape('clearLevel'),
category: 'levels',
fn: function (){
var self=this;
self['@boxes']=[];
self['@walls']=[];
self['@exits']=[];
self['@floor']=[];
return self;},
args: [],
source: unescape('clearLevel%0A%09boxes%20%3A%3D%20%23%28%29.%0A%09walls%20%3A%3D%20%23%28%29.%0A%09exits%20%3A%3D%20%23%28%29.%0A%09floor%20%3A%3D%20%23%28%29.'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level3'),
smalltalk.method({
selector: unescape('level3'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (8), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (1), (7), (2), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (2), (2), (7), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (7), (2), (1), (2), (1), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (1), (1), (2), (7), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (9), (9), (9), (2), (2), (2), (2), (7), (2), (2), (7), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level3%0A%09%5E%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%201%201%201%201%201%201%201%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%201%202%202%202%202%202%208%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%201%202%207%201%207%202%201%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%201%202%207%202%202%207%201%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%201%201%207%202%207%202%201%200%200%200%200%200%200%29%20%0A%23%280%200%200%201%201%201%201%201%201%201%201%201%202%207%202%201%202%201%201%201%200%200%200%200%29%20%0A%23%280%200%200%201%209%209%209%209%202%202%201%201%202%207%202%202%207%202%202%201%200%200%200%200%29%20%0A%23%280%200%200%201%201%209%209%209%202%202%202%202%207%202%202%207%202%202%202%201%200%200%200%200%29%20%0A%23%280%200%200%201%209%209%209%209%202%202%201%201%201%201%201%201%201%201%201%201%200%200%200%200%29%20%0A%23%280%200%200%201%201%201%201%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level4'),
smalltalk.method({
selector: unescape('level4'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (1), (2), (2), (7), (2), (7), (2), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (7), (7), (1), (7), (2), (2), (7), (2), (1), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (2), (2), (2), (2), (2), (7), (2), (1), (2), (2), (9), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (7), (2), (1), (7), (2), (7), (2), (7), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (2), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (1), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (1), (2), (2), (2), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (2), (7), (2), (2), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (7), (1), (7), (7), (2), (2), (8), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (1), (2), (2), (2), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level4%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%201%201%201%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%201%202%202%209%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%201%201%201%201%201%201%201%201%201%201%201%202%202%209%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%202%202%202%201%202%202%207%202%207%202%202%202%209%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%207%207%207%201%207%202%202%207%202%201%202%202%209%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%202%207%202%202%202%202%202%207%202%201%202%202%209%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%207%207%202%201%207%202%207%202%207%201%201%201%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%201%202%202%207%202%201%202%202%202%202%202%201%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%201%202%201%201%201%201%201%201%201%201%201%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%202%202%202%202%201%202%202%202%202%201%201%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%202%202%202%202%202%207%202%202%202%201%201%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%202%202%207%207%201%207%207%202%202%208%201%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%202%202%202%202%201%202%202%202%202%201%201%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%201%201%201%201%201%201%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%29%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level5'),
smalltalk.method({
selector: unescape('level5'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (1), (7), (1), (1), (2), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (7), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (1), (1), (1), (2), (2), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (1), (1), (2), (7), (2), (2), (7), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (2), (2), (7), (2), (7), (7), (2), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (9), (9), (9), (9), (2), (2), (1), (1), (7), (2), (2), (7), (2), (8), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (2), (7), (2), (2), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (2), (7), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (2), (1), (1), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level5%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%201%201%201%201%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%201%202%202%202%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%201%202%201%207%201%201%202%202%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%201%202%202%202%202%202%207%202%201%200%200%200%29%20%0A%23%280%200%200%200%201%201%201%201%201%201%201%201%201%202%201%201%201%202%202%202%201%200%200%200%29%20%0A%23%280%200%200%200%201%209%209%209%209%202%202%201%201%202%207%202%202%207%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%201%209%209%209%209%202%202%202%202%207%202%207%207%202%201%201%200%200%200%200%29%20%0A%23%280%200%200%200%201%209%209%209%209%202%202%201%201%207%202%202%207%202%208%201%200%200%200%200%29%20%0A%23%280%200%200%200%201%201%201%201%201%201%201%201%201%202%202%207%202%202%201%201%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%201%202%207%202%207%202%202%201%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%201%201%201%202%201%201%202%201%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%201%202%202%202%202%201%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%201%201%201%201%201%201%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level6'),
smalltalk.method({
selector: unescape('level6'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (0), (0), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (0), (1), (1), (8), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (1), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (2), (2), (2), (2), (2), (7), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (2), (2), (1), (2), (1), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (1), (1), (1), (2), (1), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (2), (7), (2), (1), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (7), (1), (2), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (1), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level6%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%201%201%201%201%201%200%200%201%201%201%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%209%209%202%202%201%200%201%201%208%201%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%209%209%202%202%201%201%201%202%202%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%209%209%202%202%202%202%202%207%207%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%209%209%202%202%201%202%201%202%207%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%209%209%201%201%201%202%201%202%207%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%201%201%201%202%207%202%201%207%202%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%201%202%202%207%201%202%207%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%201%202%207%202%202%207%202%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%201%202%202%201%201%202%202%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%201%201%201%201%201%201%201%201%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_restartLevel'),
smalltalk.method({
selector: unescape('restartLevel'),
category: 'levels',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_clearLevel", []);return smalltalk.send($rec, "_createLevel", []);})(self);
return self;},
args: [],
source: unescape('restartLevel%0A%09self%20clearLevel%3B%0A%09%09createLevel.'),
messageSends: ["clearLevel", "createLevel"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level7'),
smalltalk.method({
selector: unescape('level7'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (2), (2), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (2), (1), (2), (8), (1), (1), (2), (7), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (2), (2), (7), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (7), (2), (2), (1), (1), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (2), (1), (1), (1), (1), (1), (7), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (7), (2), (2), (1), (1), (1), (2), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (7), (2), (7), (2), (7), (2), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (2), (2), (1), (1), (1), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (7), (7), (2), (1), (0), (1), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (1), (1), (1), (0), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level7%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%201%201%201%201%201%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%201%201%201%201%201%201%202%202%202%201%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%201%202%201%202%208%201%201%202%207%207%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%202%202%202%207%202%202%202%202%202%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%202%207%202%202%201%201%201%202%202%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%201%201%202%201%201%201%201%201%207%201%201%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%207%202%202%201%201%201%202%209%209%201%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%207%202%207%202%207%202%209%209%209%201%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%202%202%202%201%201%201%209%209%209%201%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%207%207%202%201%200%201%209%209%209%201%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%202%201%201%201%200%201%201%201%201%201%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level8'),
smalltalk.method({
selector: unescape('level8'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (7), (2), (2), (2), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (7), (1), (2), (7), (2), (1), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (7), (2), (7), (2), (2), (1), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (2), (7), (1), (2), (1), (2), (2), (1), (1), (1), (1), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (8), (1), (7), (2), (7), (2), (7), (2), (2), (1), (1), (2), (2), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (2), (2), (2), (2), (7), (2), (1), (7), (1), (2), (2), (2), (1), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (2), (2), (2), (7), (2), (2), (2), (2), (7), (2), (7), (2), (7), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (9), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (9), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (9), (9), (9), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level8%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%202%202%201%201%201%201%201%201%201%201%201%201%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%202%202%202%202%207%202%202%202%207%202%207%202%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%202%207%201%202%207%202%201%202%202%207%202%202%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%202%202%207%202%207%202%202%201%202%202%202%202%201%200%200%200%200%200%29%20%0A%23%280%200%200%201%201%201%202%207%201%202%201%202%202%201%201%201%201%202%201%200%200%200%200%200%29%20%0A%23%280%200%200%201%208%201%207%202%207%202%207%202%202%201%201%202%202%202%201%200%200%200%200%200%29%20%0A%23%280%200%200%201%202%202%202%202%207%202%201%207%201%202%202%202%201%202%201%200%200%200%200%200%29%20%0A%23%280%200%200%201%202%202%202%207%202%202%202%202%207%202%207%202%207%202%201%200%200%200%200%200%29%20%0A%23%280%200%200%201%201%201%201%201%202%202%201%201%201%201%201%201%201%201%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%202%202%202%202%202%202%201%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%202%202%202%202%202%202%201%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%209%209%209%209%209%209%201%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%209%209%209%209%209%209%201%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%209%209%209%209%209%209%201%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%201%201%201%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level9'),
smalltalk.method({
selector: unescape('level9'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (9), (2), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (1), (1), (2), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (2), (1), (1), (2), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (2), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (7), (7), (7), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (7), (2), (7), (2), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (2), (2), (2), (1), (7), (2), (7), (2), (2), (2), (1), (2), (2), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (8), (2), (7), (2), (2), (7), (2), (2), (2), (2), (7), (2), (2), (7), (2), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (2), (7), (7), (2), (7), (2), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level9%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%201%201%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%201%202%202%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%201%201%201%201%201%202%202%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%201%202%202%202%202%202%202%209%202%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%201%202%202%201%201%202%202%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%201%201%202%201%201%202%202%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%201%201%201%202%201%201%201%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%201%202%207%207%207%202%201%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%201%201%201%201%202%202%207%202%207%202%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%201%201%202%202%202%201%207%202%207%202%202%202%201%202%202%202%201%200%200%200%29%20%0A%23%280%200%200%200%201%208%202%207%202%202%207%202%202%202%202%207%202%202%207%202%201%200%200%200%29%20%0A%23%280%200%200%200%201%201%201%201%201%201%202%207%207%202%207%202%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%201%202%202%202%202%202%202%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%201%201%201%201%201%201%201%201%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level10'),
smalltalk.method({
selector: unescape('level10'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (1), (1), (8), (1), (1), (1), (1), (2), (2), (2), (2), (2), (2), (2), (1), (2), (2), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (7), (2), (2), (2), (7), (7), (2), (2), (7), (2), (7), (2), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (7), (7), (1), (2), (2), (2), (2), (7), (2), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (2), (2), (2), (1), (2), (7), (7), (2), (7), (7), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (1), (1), (2), (2), (2), (1), (2), (2), (7), (2), (2), (2), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (2), (1), (2), (7), (2), (7), (2), (7), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (2), (1), (1), (1), (1), (1), (1), (2), (1), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (1), (2), (1), (2), (2), (1), (2), (2), (7), (2), (7), (2), (2), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (1), (1), (2), (1), (2), (7), (7), (2), (7), (2), (7), (1), (1), (9), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (9), (9), (1), (2), (1), (2), (2), (7), (2), (2), (2), (2), (2), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (1), (2), (9), (9), (1), (2), (1), (2), (7), (7), (7), (2), (7), (7), (7), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (1), (1), (1), (1), (1), (2), (1), (2), (2), (2), (2), (2), (2), (2), (1), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (2), (1), (1), (1), (1), (1), (1), (1), (1), (1), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (1), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level10%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%201%201%201%200%200%201%201%201%201%201%201%201%201%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%201%201%208%201%201%201%201%202%202%202%202%202%202%202%201%202%202%202%201%200%200%200%29%20%0A%23%280%200%201%202%207%207%202%202%202%207%207%202%202%207%202%207%202%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%202%207%207%207%201%202%202%202%202%207%202%202%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%207%202%202%202%201%202%207%207%202%207%207%202%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%201%201%202%202%202%201%202%202%207%202%202%202%202%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%202%202%202%202%201%202%207%202%207%202%207%202%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%202%202%202%201%201%201%201%201%201%202%201%201%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%201%202%201%202%202%201%202%202%207%202%207%202%202%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%202%201%201%202%201%202%207%207%202%207%202%207%201%201%209%209%201%200%200%200%29%20%0A%23%280%200%201%202%209%209%201%202%201%202%202%207%202%202%202%202%202%202%201%209%201%200%200%200%29%20%0A%23%280%200%201%202%209%209%201%202%201%202%207%207%207%202%207%207%207%202%201%209%201%200%200%200%29%20%0A%23%280%200%201%201%201%201%201%202%201%202%202%202%202%202%202%202%201%202%201%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%201%202%201%201%201%201%201%201%201%201%201%202%201%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%201%202%202%202%202%202%202%202%202%202%202%202%201%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%201%201%201%201%201%201%201%201%201%201%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level11'),
smalltalk.method({
selector: unescape('level11'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (0), (1), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (2), (8), (1), (1), (1), (7), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (1), (1), (2), (2), (2), (2), (2), (2), (7), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (1), (2), (2), (7), (2), (7), (7), (1), (1), (2), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (1), (7), (1), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (1), (2), (7), (2), (7), (7), (2), (1), (2), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (7), (2), (1), (2), (2), (1), (2), (7), (2), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (1), (1), (1), (1), (2), (2), (2), (2), (1), (2), (2), (7), (7), (2), (1), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (1), (1), (1), (1), (2), (1), (1), (2), (7), (2), (2), (2), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (1), (9), (2), (2), (2), (2), (1), (1), (1), (2), (2), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (1), (9), (9), (2), (9), (9), (1), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (1), (9), (9), (9), (1), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (1), (9), (9), (9), (9), (9), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level11%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%23%280%200%200%200%200%200%200%200%200%200%200%201%201%201%201%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%201%201%201%201%200%201%202%202%201%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%201%201%202%208%201%201%201%207%202%201%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%201%201%202%202%202%202%202%202%207%202%202%201%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%201%202%202%207%202%207%207%201%201%202%201%201%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%202%202%201%207%201%201%202%202%202%202%202%201%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%202%201%202%207%202%207%207%202%201%202%201%201%201%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%201%202%202%202%207%202%201%202%202%201%202%207%202%201%201%201%201%201%200%200%200%200%29%20%0A%23%280%201%201%201%201%202%202%202%202%201%202%202%207%207%202%201%202%202%202%201%200%200%200%200%29%20%0A%23%280%201%201%201%201%202%201%201%202%207%202%202%202%202%202%202%202%202%202%201%200%200%200%200%29%20%0A%23%280%201%209%202%202%202%202%201%201%201%202%202%201%201%201%201%201%201%201%201%200%200%200%200%29%20%0A%23%280%201%209%209%202%209%209%201%200%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%201%209%209%209%201%209%201%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%201%209%209%209%209%209%201%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%201%201%201%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level12'),
smalltalk.method({
selector: unescape('level12'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (1), (1), (1), (1), (1), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (2), (7), (2), (7), (2), (7), (2), (7), (1), (2), (2), (1), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (2), (2), (7), (8), (7), (2), (2), (2), (1), (1), (2), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (2), (7), (2), (7), (2), (7), (1), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (2), (2), (2), (7), (2), (7), (2), (2), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (1), (1), (1), (7), (7), (7), (2), (7), (2), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (1), (2), (1), (1), (2), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (2), (1), (1), (2), (1), (1), (9), (9), (9), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (2), (2), (2), (2), (2), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (2), (2), (2), (2), (2), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level12%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%201%201%201%201%201%201%201%201%201%201%201%201%201%201%201%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%202%202%202%202%202%202%202%202%202%202%202%202%202%201%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%201%202%201%201%201%201%201%201%202%202%202%202%202%201%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%201%202%202%207%202%207%202%207%202%207%201%202%202%201%200%200%200%200%29%20%0A%23%280%200%200%200%201%202%201%202%202%202%207%208%207%202%202%202%201%201%202%201%201%200%200%200%29%20%0A%23%280%200%200%200%201%202%201%202%202%207%202%207%202%207%201%201%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%201%202%201%202%202%202%207%202%207%202%202%201%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%201%202%201%201%201%207%207%207%202%207%202%201%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%201%202%202%202%202%202%201%202%201%201%202%201%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%201%201%201%201%201%202%202%202%201%201%202%201%201%209%209%209%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%201%201%201%201%201%202%202%202%202%202%201%201%201%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%201%202%202%202%202%202%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%201%201%201%201%201%201%201%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_level13'),
smalltalk.method({
selector: unescape('level13'),
category: 'levels',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (1), (1), (2), (2), (2), (1), (1), (2), (2), (1), (1), (1), (1), (1), (1), (0), (0), (0), (0), (0)], [(0), (0), (1), (1), (1), (2), (2), (2), (2), (2), (1), (2), (2), (1), (2), (2), (2), (2), (1), (1), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (7), (2), (1), (7), (2), (1), (2), (2), (1), (2), (2), (9), (9), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (1), (2), (7), (1), (8), (7), (1), (1), (2), (1), (2), (1), (9), (1), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (1), (2), (1), (7), (2), (2), (1), (2), (2), (2), (2), (9), (2), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (2), (2), (2), (2), (7), (2), (1), (2), (1), (2), (1), (9), (1), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (2), (2), (1), (1), (2), (2), (1), (1), (7), (2), (7), (2), (9), (2), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (2), (7), (2), (1), (2), (2), (2), (1), (2), (2), (1), (7), (1), (9), (1), (9), (2), (1), (0), (0), (0)], [(0), (0), (1), (1), (2), (7), (2), (2), (7), (2), (2), (2), (7), (2), (2), (7), (9), (9), (9), (2), (1), (0), (0), (0)], [(0), (0), (0), (1), (7), (2), (1), (1), (1), (1), (1), (1), (2), (2), (2), (2), (1), (1), (2), (2), (1), (0), (0), (0)], [(0), (0), (0), (1), (2), (2), (1), (0), (0), (0), (0), (1), (1), (1), (1), (1), (1), (1), (1), (1), (1), (0), (0), (0)], [(0), (0), (0), (1), (1), (1), (1), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('level13%0A%09%5E%20%20%0A%23%28%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%201%201%201%201%201%201%201%201%201%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%201%201%202%202%202%201%201%202%202%201%201%201%201%201%201%200%200%200%200%200%29%20%0A%23%280%200%201%201%201%202%202%202%202%202%201%202%202%201%202%202%202%202%201%201%201%200%200%200%29%20%0A%23%280%200%201%202%202%207%202%201%207%202%201%202%202%201%202%202%209%209%209%202%201%200%200%200%29%20%0A%23%280%200%201%202%201%202%207%201%208%207%201%201%202%201%202%201%209%201%209%202%201%200%200%200%29%20%0A%23%280%200%201%202%202%201%202%201%207%202%202%201%202%202%202%202%209%202%209%202%201%200%200%200%29%20%0A%23%280%200%201%202%207%202%202%202%202%207%202%201%202%201%202%201%209%201%209%202%201%200%200%200%29%20%0A%23%280%200%201%202%202%202%201%201%202%202%201%201%207%202%207%202%209%202%209%202%201%200%200%200%29%20%0A%23%280%200%201%202%207%202%201%202%202%202%201%202%202%201%207%201%209%201%209%202%201%200%200%200%29%20%0A%23%280%200%201%201%202%207%202%202%207%202%202%202%207%202%202%207%209%209%209%202%201%200%200%200%29%20%0A%23%280%200%200%201%207%202%201%201%201%201%201%201%202%202%202%202%201%201%202%202%201%200%200%200%29%20%0A%23%280%200%200%201%202%202%201%200%200%200%200%201%201%201%201%201%201%201%201%201%201%200%200%200%29%20%0A%23%280%200%200%201%201%201%201%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%20%0A%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29%0A%22%0A0%20%u2192%20empty%0A1%20%u2192%20wall%0A2%20%u2192%20floor%0A7%20%u2192%20box%0A8%20%u2192%20guy%0A9%20%u2192%20exit%0A%22'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_processMovement'),
smalltalk.method({
selector: unescape('processMovement'),
category: 'movement',
fn: function (){
var self=this;
smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("still", "__comma", [smalltalk.send(self, "_lastMove", [])])]);
return self;},
args: [],
source: unescape('processMovement%0A%09guy%20currentFrameGroup%3A%20%27still%27%20%2C%20self%20lastMove.'),
messageSends: ["currentFrameGroup:", unescape("%2C"), "lastMove"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_lastMove'),
smalltalk.method({
selector: unescape('lastMove'),
category: 'movement',
fn: function (){
var self=this;
return (($receiver = self['@lastMove']) == nil || $receiver == undefined) ? (function(){return self['@lastMove']="Down";})() : $receiver;
return self;},
args: [],
source: unescape('lastMove%0A%09%5E%20lastMove%20ifNil%3A%20%5BlastMove%20%3A%3D%20%27Down%27%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_moveBox_direction_'),
smalltalk.method({
selector: unescape('moveBox%3Adirection%3A'),
category: 'movement',
fn: function (aBox, aDirection){
var self=this;
var side=nil;
var offset=nil;
side=smalltalk.send(smalltalk.send(self, "_directionDictionary", []), "_at_", [aDirection]);
offset=smalltalk.send(smalltalk.send(self, "_boxOffsetDictionary", []), "_at_", [aDirection]);
smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver +offset : smalltalk.send($receiver, "__plus", [offset]))]);
((($receiver = smalltalk.send(aBox, "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@walls']]])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return ((($receiver = smalltalk.send(aBox, "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@boxes']]])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){smalltalk.send(smalltalk.send(self, "_soundNamed_", ["slide"]), "_play", []);return smalltalk.send((5), "_timesRepeat_", [(function(){smalltalk.send((function(){return smalltalk.send(aBox, "_moveCentreBy_", [offset]);}), "_valueWithTimeout_", [(100)]);smalltalk.send(self, "_clearCanvas", []);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]);})() : (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){smalltalk.send(smalltalk.send(self, "_soundNamed_", ["slide"]), "_play", []);return smalltalk.send((5), "_timesRepeat_", [(function(){smalltalk.send((function(){return smalltalk.send(aBox, "_moveCentreBy_", [offset]);}), "_valueWithTimeout_", [(100)]);smalltalk.send(self, "_clearCanvas", []);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]);}), (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})]));})() : (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){return ((($receiver = smalltalk.send(aBox, "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@boxes']]])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){smalltalk.send(smalltalk.send(self, "_soundNamed_", ["slide"]), "_play", []);return smalltalk.send((5), "_timesRepeat_", [(function(){smalltalk.send((function(){return smalltalk.send(aBox, "_moveCentreBy_", [offset]);}), "_valueWithTimeout_", [(100)]);smalltalk.send(self, "_clearCanvas", []);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]);})() : (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){smalltalk.send(smalltalk.send(self, "_soundNamed_", ["slide"]), "_play", []);return smalltalk.send((5), "_timesRepeat_", [(function(){smalltalk.send((function(){return smalltalk.send(aBox, "_moveCentreBy_", [offset]);}), "_valueWithTimeout_", [(100)]);smalltalk.send(self, "_clearCanvas", []);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]);}), (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})]));}), (function(){return smalltalk.send(aBox, "_centre_", [((($receiver = smalltalk.send(aBox, "_centre", [])).klass === smalltalk.Number) ? $receiver -offset : smalltalk.send($receiver, "__minus", [offset]))]);})]));
return self;},
args: ["aBox", "aDirection"],
source: unescape('moveBox%3A%20aBox%20direction%3A%20aDirection%0A%09%7Cside%20offset%7C%0A%09side%20%3A%3D%20self%20directionDictionary%20at%3A%20aDirection.%0A%09offset%20%3A%3D%20self%20boxOffsetDictionary%20at%3A%20aDirection.%0A%0A%09aBox%20centre%3A%20aBox%20centre%20+%20offset.%0A%09%28aBox%20perform%3A%20side%20%2C%20%27CollidesWithAnyOf%3A%27%20withArguments%3A%20%7Bwalls%7D%29%0A%09%09ifFalse%3A%0A%09%09%09%5B%28aBox%20perform%3A%20side%20%2C%20%27CollidesWithAnyOf%3A%27%20withArguments%3A%20%7Bboxes%7D%29%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09ifFalse%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5B%20%28self%20soundNamed%3A%20%27slide%27%29%20play.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%205%20timesRepeat%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%5B%5BaBox%20moveCentreBy%3A%20offset%5D%20valueWithTimeout%3A%20100.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09self%20clearCanvas.%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09self%20boxes%20do%3A%20%5B%3Aeach%20%7C%20self%20drawSprite%3A%20each%5D%5D%5D%0A%09%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20ifTrue%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5BaBox%20centre%3A%20aBox%20centre%20-%20offset%5D%5D%0A%09%09ifTrue%3A%20%5BaBox%20centre%3A%20aBox%20centre%20-%20offset%5D'),
messageSends: ["at:", "directionDictionary", "boxOffsetDictionary", "centre:", unescape("+"), "centre", "ifFalse:ifTrue:", "perform:withArguments:", unescape("%2C"), "play", "soundNamed:", "timesRepeat:", "valueWithTimeout:", "moveCentreBy:", "clearCanvas", "do:", "boxes", "drawSprite:", unescape("-")],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_go_'),
smalltalk.method({
selector: unescape('go%3A'),
category: 'movement',
fn: function (aDirection){
var self=this;
var side=nil;
var offset=nil;
side=smalltalk.send(smalltalk.send(self, "_directionDictionary", []), "_at_", [aDirection]);
offset=smalltalk.send(smalltalk.send(self, "_guyOffsetDictionary", []), "_at_", [aDirection]);
smalltalk.send(self['@guy'], "_moveCentreBy_", [offset]);
((($receiver = smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@walls']]])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return ((($receiver = smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@boxes']]])).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_moveBox_direction_", [smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithWhichOf:"]), [self['@boxes']]]), aDirection]);smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);})() : (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = ((($receiver = offset).klass === smalltalk.Number) ? $receiver /(8) : smalltalk.send($receiver, "__slash", [(8)]))).klass === smalltalk.Number) ? $receiver *((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)])) : smalltalk.send($receiver, "__star", [((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)]))]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("walk", "__comma", [aDirection])]);})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){smalltalk.send(self, "_moveBox_direction_", [smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithWhichOf:"]), [self['@boxes']]]), aDirection]);smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);}), (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = ((($receiver = offset).klass === smalltalk.Number) ? $receiver /(8) : smalltalk.send($receiver, "__slash", [(8)]))).klass === smalltalk.Number) ? $receiver *((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)])) : smalltalk.send($receiver, "__star", [((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)]))]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("walk", "__comma", [aDirection])]);})]));})() : (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){return ((($receiver = smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithAnyOf:"]), [self['@boxes']]])).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_moveBox_direction_", [smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithWhichOf:"]), [self['@boxes']]]), aDirection]);smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);})() : (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = ((($receiver = offset).klass === smalltalk.Number) ? $receiver /(8) : smalltalk.send($receiver, "__slash", [(8)]))).klass === smalltalk.Number) ? $receiver *((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)])) : smalltalk.send($receiver, "__star", [((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)]))]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("walk", "__comma", [aDirection])]);})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){smalltalk.send(self, "_moveBox_direction_", [smalltalk.send(self['@guy'], "_perform_withArguments_", [smalltalk.send(side, "__comma", ["CollidesWithWhichOf:"]), [self['@boxes']]]), aDirection]);smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);}), (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = ((($receiver = offset).klass === smalltalk.Number) ? $receiver /(8) : smalltalk.send($receiver, "__slash", [(8)]))).klass === smalltalk.Number) ? $receiver *((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)])) : smalltalk.send($receiver, "__star", [((($receiver = self['@stepSize']).klass === smalltalk.Number) ? $receiver -(8) : smalltalk.send($receiver, "__minus", [(8)]))]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("walk", "__comma", [aDirection])]);})]));}), (function(){smalltalk.send(self['@guy'], "_moveCentreBy_", [((($receiver = offset).klass === smalltalk.Number) ? $receiver *(-1) : smalltalk.send($receiver, "__star", [(-1)]))]);return smalltalk.send(self['@guy'], "_currentFrameGroup_", [smalltalk.send("push", "__comma", [aDirection])]);})]));
self['@lastMove']=aDirection;
return self;},
args: ["aDirection"],
source: unescape('go%3A%20aDirection%0A%09%7Cside%20offset%7C%0A%09side%20%3A%3D%20self%20directionDictionary%20at%3A%20aDirection.%0A%09offset%20%3A%3D%20self%20guyOffsetDictionary%20at%3A%20aDirection.%0A%0A%09guy%20moveCentreBy%3A%20offset.%0A%09%28guy%20perform%3A%20side%20%2C%20%27CollidesWithAnyOf%3A%27%20withArguments%3A%20%7Bwalls%7D%29%0A%09%09ifFalse%3A%0A%09%09%09%5B%28guy%20perform%3A%20side%20%2C%20%27CollidesWithAnyOf%3A%27%20withArguments%3A%20%7Bboxes%7D%29%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09ifTrue%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5Bself%20moveBox%3A%20%28guy%20perform%3A%20side%20%2C%20%27CollidesWithWhichOf%3A%27%20withArguments%3A%20%7Bboxes%7D%29%20direction%3A%20aDirection.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20guy%20moveCentreBy%3A%20%28offset%20*%20-1%29.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20guy%20currentFrameGroup%3A%20%27push%27%2C%20aDirection%5D%0A%09%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20ifFalse%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5Bguy%20moveCentreBy%3A%20%28%28offset%20/%208%29%20*%20%28stepSize%20-%208%29%29.%0A%20%20%20%20%20%20%20%20%09%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09guy%20currentFrameGroup%3A%20%27walk%27%2C%20aDirection%5D%5D%0A%09%09ifTrue%3A%20%0A%09%09%09%5Bguy%20moveCentreBy%3A%20%28offset%20*%20-1%29.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20guy%20currentFrameGroup%3A%20%27push%27%20%2C%20aDirection%5D.%0A%0A%09lastMove%20%3A%3D%20aDirection.'),
messageSends: ["at:", "directionDictionary", "guyOffsetDictionary", "moveCentreBy:", "ifFalse:ifTrue:", "perform:withArguments:", unescape("%2C"), "ifTrue:ifFalse:", "moveBox:direction:", unescape("*"), "currentFrameGroup:", unescape("/"), unescape("-")],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_walls'),
smalltalk.method({
selector: unescape('walls'),
category: 'sprite collections',
fn: function (){
var self=this;
return (($receiver = self['@walls']) == nil || $receiver == undefined) ? (function(){return self['@walls']=[];})() : $receiver;
return self;},
args: [],
source: unescape('walls%0A%09%5E%20walls%20ifNil%3A%20%5Bwalls%20%3A%3D%20%23%28%29%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_boxes'),
smalltalk.method({
selector: unescape('boxes'),
category: 'sprite collections',
fn: function (){
var self=this;
return (($receiver = self['@boxes']) == nil || $receiver == undefined) ? (function(){return self['@boxes']=[];})() : $receiver;
return self;},
args: [],
source: unescape('boxes%0A%09%5E%20boxes%20ifNil%3A%20%5Bboxes%20%3A%3D%20%23%28%29%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_exits'),
smalltalk.method({
selector: unescape('exits'),
category: 'sprite collections',
fn: function (){
var self=this;
return (($receiver = self['@exits']) == nil || $receiver == undefined) ? (function(){return self['@exits']=[];})() : $receiver;
return self;},
args: [],
source: unescape('exits%0A%09%5E%20exits%20ifNil%3A%20%5Bexits%20%3A%3D%20%23%28%29%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_floor'),
smalltalk.method({
selector: unescape('floor'),
category: 'sprite collections',
fn: function (){
var self=this;
return (($receiver = self['@floor']) == nil || $receiver == undefined) ? (function(){return self['@floor']=[];})() : $receiver;
return self;},
args: [],
source: unescape('floor%0A%09%5E%20floor%20ifNil%3A%20%5Bfloor%20%3A%3D%20%23%28%29%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_createGuy'),
smalltalk.method({
selector: unescape('createGuy'),
category: 'sprite creation',
fn: function (){
var self=this;
self['@guy']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/guy.png")]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["walkDown", smalltalk.send((0), "__at", [(0)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["walkUp", smalltalk.send((0), "__at", [(25)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["walkLeft", smalltalk.send((0), "__at", [(50)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["walkRight", smalltalk.send((0), "__at", [(75)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["stillDown", smalltalk.send((50), "__at", [(0)]), smalltalk.send((25), "__at", [(25)]), (1)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["stillUp", smalltalk.send((50), "__at", [(25)]), smalltalk.send((25), "__at", [(25)]), (1)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["stillLeft", smalltalk.send((50), "__at", [(50)]), smalltalk.send((25), "__at", [(25)]), (1)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["stillRight", smalltalk.send((50), "__at", [(75)]), smalltalk.send((25), "__at", [(25)]), (1)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["pushDown", smalltalk.send((75), "__at", [(0)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["pushUp", smalltalk.send((75), "__at", [(25)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["pushLeft", smalltalk.send((75), "__at", [(50)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_addFrameGroupNamed_origin_size_frameCount_", ["pushRight", smalltalk.send((75), "__at", [(75)]), smalltalk.send((25), "__at", [(25)]), (2)]);
smalltalk.send(self['@guy'], "_centre_", [smalltalk.send(self, "_startPositionFor_", [smalltalk.send(self, "_currentLevel", [])])]);
smalltalk.send(self['@guy'], "_frameRate_", [(2)]);
return self;},
args: [],
source: unescape('createGuy%0A%09guy%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/guy.png%27.%0A%09guy%20addFrameGroupNamed%3A%20%27walkDown%27%20origin%3A%20%280@0%29%20size%3A%20%2825@25%29%20frameCount%3A%202.%0A%09guy%20addFrameGroupNamed%3A%20%27walkUp%27%20origin%3A%20%280@25%29%20size%3A%20%2825@25%29%20frameCount%3A%202.%0A%09guy%20addFrameGroupNamed%3A%20%27walkLeft%27%20origin%3A%20%280@50%29%20size%3A%20%2825@25%29%20frameCount%3A%202.%0A%09guy%20addFrameGroupNamed%3A%20%27walkRight%27%20origin%3A%20%280@75%29%20size%3A%20%2825@25%29%20frameCount%3A%202.%0A%0A%09guy%20addFrameGroupNamed%3A%20%27stillDown%27%20origin%3A%20%2850@0%29%20size%3A%20%2825@25%29%20frameCount%3A%201.%0A%09guy%20addFrameGroupNamed%3A%20%27stillUp%27%20origin%3A%20%2850@25%29%20size%3A%20%2825@25%29%20frameCount%3A%201.%0A%09guy%20addFrameGroupNamed%3A%20%27stillLeft%27%20origin%3A%20%2850@50%29%20size%3A%20%2825@25%29%20frameCount%3A%201.%0A%09guy%20addFrameGroupNamed%3A%20%27stillRight%27%20origin%3A%20%2850@75%29%20size%3A%20%2825@25%29%20frameCount%3A%201.%0A%0A%09guy%20addFrameGroupNamed%3A%20%27pushDown%27%20origin%3A%20%2875@0%29%20size%3A%20%2825@25%29%20frameCount%3A%202.%0A%09guy%20addFrameGroupNamed%3A%20%27pushUp%27%20origin%3A%20%2875@25%29%20size%3A%20%2825@25%29%20frameCount%3A%202.%0A%09guy%20addFrameGroupNamed%3A%20%27pushLeft%27%20origin%3A%20%2875@50%29%20size%3A%20%2825@25%29%20frameCount%3A%202.%0A%09guy%20addFrameGroupNamed%3A%20%27pushRight%27%20origin%3A%20%2875@75%29%20size%3A%20%2825@25%29%20frameCount%3A%202.%0A%0A%09guy%20centre%3A%20%28self%20startPositionFor%3A%20self%20currentLevel%29.%0A%0A%09guy%20frameRate%3A%202.'),
messageSends: ["spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "centre:", "startPositionFor:", "currentLevel", "frameRate:"],
referencedClasses: ["Sprite"]
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_createWalls'),
smalltalk.method({
selector: unescape('createWalls'),
category: 'sprite creation',
fn: function (){
var self=this;
var wall=nil;
smalltalk.send(smalltalk.send(self, "_currentLevel", []), "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){wall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/wall.png")]);smalltalk.send(wall, "_addFrameGroupNamed_origin_size_frameCount_", ["wall", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);(function($rec){smalltalk.send($rec, "_x_", [((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);return smalltalk.send($rec, "_y_", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);})(wall);return smalltalk.send(smalltalk.send(self, "_walls", []), "_add_", [wall]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){wall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/wall.png")]);smalltalk.send(wall, "_addFrameGroupNamed_origin_size_frameCount_", ["wall", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);(function($rec){smalltalk.send($rec, "_x_", [((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);return smalltalk.send($rec, "_y_", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);})(wall);return smalltalk.send(smalltalk.send(self, "_walls", []), "_add_", [wall]);})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){wall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/wall.png")]);smalltalk.send(wall, "_addFrameGroupNamed_origin_size_frameCount_", ["wall", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);(function($rec){smalltalk.send($rec, "_x_", [((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);return smalltalk.send($rec, "_y_", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);})(wall);return smalltalk.send(smalltalk.send(self, "_walls", []), "_add_", [wall]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){wall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/wall.png")]);smalltalk.send(wall, "_addFrameGroupNamed_origin_size_frameCount_", ["wall", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);(function($rec){smalltalk.send($rec, "_x_", [((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);return smalltalk.send($rec, "_y_", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(30) : smalltalk.send($receiver, "__minus", [(30)]))]);})(wall);return smalltalk.send(smalltalk.send(self, "_walls", []), "_add_", [wall]);})]));})]);})]));})]);
return self;},
args: [],
source: unescape('createWalls%0A%09%7Cwall%7C%0A%0A%09self%20currentLevel%0A%09%09withIndexDo%3A%20%5B%3AeachRow%20%3Ay%20%7C%20%0A%09%09%09%28eachRow%20includes%3A%201%29%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09ifTrue%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5BeachRow%20withIndexDo%3A%20%5B%3AeachColumn%20%3Ax%20%7C%0A%09%09%09%09%09%09eachColumn%20%3D%201%20%0A%09%09%09%09%09%09%09ifTrue%3A%20%5B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09wall%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/wall.png%27.%0A%09%09%09%09%09%09%09%09wall%20addFrameGroupNamed%3A%20%27wall%27%20origin%3A%20%280@0%29%20size%3A%20%2830@30%29%20frameCount%3A%201.%0A%09%09%09%09%09%09%09%09wall%20x%3A%20%28%28x%20*%2030%29%20-%2030%29%3B%20y%3A%20%28%28y%20*%2030%29%20-%2030%29.%0A%09%09%09%09%09%09%09%09self%20walls%20add%3A%20wall%20%5D%5D%5D%5D.'),
messageSends: ["withIndexDo:", "currentLevel", "ifTrue:", "includes:", unescape("%3D"), "spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "x:", unescape("-"), unescape("*"), "y:", "add:", "walls"],
referencedClasses: ["Sprite"]
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_createBoxes'),
smalltalk.method({
selector: unescape('createBoxes'),
category: 'sprite creation',
fn: function (){
var self=this;
var box=nil;
smalltalk.send(smalltalk.send(self, "_currentLevel", []), "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(7)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(7)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){box=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/box.png")]);smalltalk.send(box, "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send(((($receiver = ((($receiver = smalltalk.send((6), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]))).klass === smalltalk.Number) ? $receiver *(28) : smalltalk.send($receiver, "__star", [(28)])), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(box, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_add_", [box]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){box=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/box.png")]);smalltalk.send(box, "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send(((($receiver = ((($receiver = smalltalk.send((6), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]))).klass === smalltalk.Number) ? $receiver *(28) : smalltalk.send($receiver, "__star", [(28)])), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(box, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_add_", [box]);})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(7)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){box=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/box.png")]);smalltalk.send(box, "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send(((($receiver = ((($receiver = smalltalk.send((6), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]))).klass === smalltalk.Number) ? $receiver *(28) : smalltalk.send($receiver, "__star", [(28)])), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(box, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_add_", [box]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){box=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/box.png")]);smalltalk.send(box, "_addFrameGroupNamed_origin_size_frameCount_", ["still", smalltalk.send(((($receiver = ((($receiver = smalltalk.send((6), "_atRandom", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]))).klass === smalltalk.Number) ? $receiver *(28) : smalltalk.send($receiver, "__star", [(28)])), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(box, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_boxes", []), "_add_", [box]);})]));})]);})]));})]);
return self;},
args: [],
source: unescape('createBoxes%0A%09%7Cbox%7C%0A%0A%09self%20currentLevel%0A%09%09withIndexDo%3A%20%5B%3AeachRow%20%3Ay%20%7C%20%0A%09%09%09%28eachRow%20includes%3A%207%29%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09ifTrue%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5BeachRow%20withIndexDo%3A%20%5B%3AeachColumn%20%3Ax%20%7C%0A%09%09%09%09%09%09eachColumn%20%3D%207%20%0A%09%09%09%09%09%09%09ifTrue%3A%20%5B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09box%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/box.png%27.%0A%09%09%09%09%09%09%09%09box%20addFrameGroupNamed%3A%20%27still%27%20origin%3A%20%28%28%286%20atRandom%20-%201%29%20*%2028%29@0%29%20size%3A%20%2828@28%29%20frameCount%3A%201.%0A%09%09%09%09%09%09%09%09box%20centre%3A%20%28%28x%20*%2030%29%20-%2015%29%20@%20%28%28y%20*%2030%29%20-%2015%29.%0A%09%09%09%09%09%09%09%09self%20boxes%20add%3A%20box%20%5D%5D%5D%5D.'),
messageSends: ["withIndexDo:", "currentLevel", "ifTrue:", "includes:", unescape("%3D"), "spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), unescape("*"), unescape("-"), "atRandom", "centre:", "add:", "boxes"],
referencedClasses: ["Sprite"]
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_createExits'),
smalltalk.method({
selector: unescape('createExits'),
category: 'sprite creation',
fn: function (){
var self=this;
var exit=nil;
smalltalk.send(smalltalk.send(self, "_currentLevel", []), "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(9)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(9)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){exit=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/exit.png")]);smalltalk.send(exit, "_addFrameGroupNamed_origin_size_frameCount_", ["exit", smalltalk.send((0), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(exit, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_exits", []), "_add_", [exit]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){exit=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/exit.png")]);smalltalk.send(exit, "_addFrameGroupNamed_origin_size_frameCount_", ["exit", smalltalk.send((0), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(exit, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_exits", []), "_add_", [exit]);})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = smalltalk.send(eachColumn, "__eq", [(9)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){exit=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/exit.png")]);smalltalk.send(exit, "_addFrameGroupNamed_origin_size_frameCount_", ["exit", smalltalk.send((0), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(exit, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_exits", []), "_add_", [exit]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){exit=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/exit.png")]);smalltalk.send(exit, "_addFrameGroupNamed_origin_size_frameCount_", ["exit", smalltalk.send((0), "__at", [(0)]), smalltalk.send((28), "__at", [(28)]), (1)]);smalltalk.send(exit, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_exits", []), "_add_", [exit]);})]));})]);})]));})]);
return self;},
args: [],
source: unescape('createExits%0A%09%7Cexit%7C%0A%0A%09self%20currentLevel%0A%09%09withIndexDo%3A%20%5B%3AeachRow%20%3Ay%20%7C%20%0A%09%09%09%28eachRow%20includes%3A%209%29%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09ifTrue%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5BeachRow%20withIndexDo%3A%20%5B%3AeachColumn%20%3Ax%20%7C%0A%09%09%09%09%09%09eachColumn%20%3D%209%20%0A%09%09%09%09%09%09%09ifTrue%3A%20%5B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09exit%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/exit.png%27.%0A%09%09%09%09%09%09%09%09exit%20addFrameGroupNamed%3A%20%27exit%27%20origin%3A%20%280@0%29%20size%3A%20%2828@28%29%20frameCount%3A%201.%0A%09%09%09%09%09%09%09%09exit%20centre%3A%20%28%28x%20*%2030%29%20-%2015%29%20@%20%28%28y%20*%2030%29%20-%2015%29.%0A%09%09%09%09%09%09%09%09self%20exits%20add%3A%20exit%20%5D%5D%5D%5D.'),
messageSends: ["withIndexDo:", "currentLevel", "ifTrue:", "includes:", unescape("%3D"), "spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "centre:", unescape("-"), unescape("*"), "add:", "exits"],
referencedClasses: ["Sprite"]
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_createFloor'),
smalltalk.method({
selector: unescape('createFloor'),
category: 'sprite creation',
fn: function (){
var self=this;
var tile=nil;
smalltalk.send(smalltalk.send(self, "_currentLevel", []), "_withIndexDo_", [(function(eachRow, y){return ((($receiver = smalltalk.send(eachRow, "_includes_", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = ((($receiver = eachColumn).klass === smalltalk.Number) ? $receiver >(1) : smalltalk.send($receiver, "__gt", [(1)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){tile=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/floor.png")]);smalltalk.send(tile, "_addFrameGroupNamed_origin_size_frameCount_", ["tile", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);smalltalk.send(tile, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_floor", []), "_add_", [tile]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){tile=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/floor.png")]);smalltalk.send(tile, "_addFrameGroupNamed_origin_size_frameCount_", ["tile", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);smalltalk.send(tile, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_floor", []), "_add_", [tile]);})]));})]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(eachRow, "_withIndexDo_", [(function(eachColumn, x){return ((($receiver = ((($receiver = eachColumn).klass === smalltalk.Number) ? $receiver >(1) : smalltalk.send($receiver, "__gt", [(1)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){tile=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/floor.png")]);smalltalk.send(tile, "_addFrameGroupNamed_origin_size_frameCount_", ["tile", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);smalltalk.send(tile, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_floor", []), "_add_", [tile]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){tile=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/floor.png")]);smalltalk.send(tile, "_addFrameGroupNamed_origin_size_frameCount_", ["tile", smalltalk.send((0), "__at", [(0)]), smalltalk.send((30), "__at", [(30)]), (1)]);smalltalk.send(tile, "_centre_", [smalltalk.send(((($receiver = ((($receiver = x).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)])), "__at", [((($receiver = ((($receiver = y).klass === smalltalk.Number) ? $receiver *(30) : smalltalk.send($receiver, "__star", [(30)]))).klass === smalltalk.Number) ? $receiver -(15) : smalltalk.send($receiver, "__minus", [(15)]))])]);return smalltalk.send(smalltalk.send(self, "_floor", []), "_add_", [tile]);})]));})]);})]));})]);
return self;},
args: [],
source: unescape('createFloor%0A%09%7Ctile%7C%0A%09self%20currentLevel%0A%09%09withIndexDo%3A%20%5B%3AeachRow%20%3Ay%20%7C%20%0A%09%09%09%28eachRow%20includes%3A%201%29%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09ifTrue%3A%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09%5BeachRow%20withIndexDo%3A%20%5B%3AeachColumn%20%3Ax%20%7C%0A%09%09%09%09%09%09eachColumn%20%3E%201%0A%09%09%09%09%09%09%09ifTrue%3A%20%5B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09tile%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/floor.png%27.%0A%09%09%09%09%09%09%09%09tile%20addFrameGroupNamed%3A%20%27tile%27%20origin%3A%20%280@0%29%20size%3A%20%2830@30%29%20frameCount%3A%201.%0A%09%09%09%09%09%09%09%09tile%20centre%3A%20%28%28x%20*%2030%29%20-%2015%29%20@%20%28%28y%20*%2030%29%20-%2015%29.%0A%09%09%09%09%09%09%09%09self%20floor%20add%3A%20tile%5D%5D%5D%5D.'),
messageSends: ["withIndexDo:", "currentLevel", "ifTrue:", "includes:", unescape("%3E"), "spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "centre:", unescape("-"), unescape("*"), "add:", "floor"],
referencedClasses: ["Sprite"]
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_directionDictionary'),
smalltalk.method({
selector: unescape('directionDictionary'),
category: 'movement',
fn: function (){
var self=this;
return (($receiver = self['@directionDictionary']) == nil || $receiver == undefined) ? (function(){return self['@directionDictionary']=smalltalk.HashedCollection._fromPairs_([smalltalk.send("Down", "__minus_gt", ["bottom"]),smalltalk.send("Up", "__minus_gt", ["top"]),smalltalk.send("Left", "__minus_gt", ["left"]),smalltalk.send("Right", "__minus_gt", ["right"])]);})() : $receiver;
return self;},
args: [],
source: unescape('directionDictionary%0A%09%5E%20directionDictionary%20ifNil%3A%20%5B%20directionDictionary%20%3A%3D%20%23%7B%27Down%27%20-%3E%20%27bottom%27.%20%27Up%27%20-%3E%20%27top%27.%20%27Left%27%20-%3E%20%27left%27.%20%27Right%27%20-%3E%20%27right%27%7D%20%5D'),
messageSends: ["ifNil:", unescape("-%3E")],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_guyOffsetDictionary'),
smalltalk.method({
selector: unescape('guyOffsetDictionary'),
category: 'movement',
fn: function (){
var self=this;
return (($receiver = self['@guyOffsetDictionary']) == nil || $receiver == undefined) ? (function(){return self['@guyOffsetDictionary']=smalltalk.HashedCollection._fromPairs_([smalltalk.send("Down", "__minus_gt", [smalltalk.send((0), "__at", [(8)])]),smalltalk.send("Up", "__minus_gt", [smalltalk.send((0), "__at", [(-8)])]),smalltalk.send("Left", "__minus_gt", [smalltalk.send((-8), "__at", [(0)])]),smalltalk.send("Right", "__minus_gt", [smalltalk.send((8), "__at", [(0)])])]);})() : $receiver;
return self;},
args: [],
source: unescape('guyOffsetDictionary%0A%09%5E%20guyOffsetDictionary%20ifNil%3A%20%5B%20guyOffsetDictionary%20%3A%3D%20%23%7B%27Down%27%20-%3E%20%280@8%29.%20%27Up%27%20-%3E%20%280@%20-8%29.%20%27Left%27%20-%3E%20%28-8@0%29.%20%27Right%27%20-%3E%20%288@0%29%7D%20%5D'),
messageSends: ["ifNil:", unescape("-%3E"), unescape("@")],
referencedClasses: []
}),
smalltalk.Sokoban);

smalltalk.addMethod(
unescape('_boxOffsetDictionary'),
smalltalk.method({
selector: unescape('boxOffsetDictionary'),
category: 'movement',
fn: function (){
var self=this;
return (($receiver = self['@boxOffsetDictionary']) == nil || $receiver == undefined) ? (function(){return self['@boxOffsetDictionary']=smalltalk.HashedCollection._fromPairs_([smalltalk.send("Down", "__minus_gt", [smalltalk.send((0), "__at", [(5)])]),smalltalk.send("Up", "__minus_gt", [smalltalk.send((0), "__at", [(-5)])]),smalltalk.send("Left", "__minus_gt", [smalltalk.send((-5), "__at", [(0)])]),smalltalk.send("Right", "__minus_gt", [smalltalk.send((5), "__at", [(0)])])]);})() : $receiver;
return self;},
args: [],
source: unescape('boxOffsetDictionary%0A%09%5E%20boxOffsetDictionary%20ifNil%3A%20%5B%20boxOffsetDictionary%20%3A%3D%20%23%7B%27Down%27%20-%3E%20%280@5%29.%20%27Up%27%20-%3E%20%280@%20-5%29.%20%27Left%27%20-%3E%20%28-5@0%29.%20%27Right%27%20-%3E%20%285@0%29%7D%20%5D'),
messageSends: ["ifNil:", unescape("-%3E"), unescape("@")],
referencedClasses: []
}),
smalltalk.Sokoban);



smalltalk.addClass('SimplePacman', smalltalk.Game, ['pacman', 'ghost', 'pills'], 'Ludus-Examples');
smalltalk.addMethod(
unescape('_startGame'),
smalltalk.method({
selector: unescape('startGame'),
category: 'not yet classified',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_width_", [(720)]);smalltalk.send($rec, "_height_", [(540)]);return smalltalk.send($rec, "_backgroundColor_", ["black"]);})(self);
smalltalk.send(self, "_createPacman", []);
smalltalk.send(self, "_createGhost", []);
return self;},
args: [],
source: unescape('startGame%0A%09self%20width%3A%20720%3B%20%0A%09%09height%3A%20540%3B%0A%09%09backgroundColor%3A%20%27black%27.%0A%0A%09self%20createPacman.%0A%09self%20createGhost.'),
messageSends: ["width:", "height:", "backgroundColor:", "createPacman", "createGhost"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_createPacman'),
smalltalk.method({
selector: unescape('createPacman'),
category: 'not yet classified',
fn: function (){
var self=this;
self['@pacman']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/pacman.png")]);
smalltalk.send(self['@pacman'], "_addFrameGroupNamed_origin_size_frameCount_", ["left", smalltalk.send((0), "__at", [(0)]), smalltalk.send((50), "__at", [(50)]), (2)]);
smalltalk.send(self['@pacman'], "_addFrameGroupNamed_origin_size_frameCount_", ["right", smalltalk.send((0), "__at", [(50)]), smalltalk.send((50), "__at", [(50)]), (2)]);
smalltalk.send(self['@pacman'], "_addFrameGroupNamed_origin_size_frameCount_", ["down", smalltalk.send((100), "__at", [(0)]), smalltalk.send((50), "__at", [(50)]), (2)]);
smalltalk.send(self['@pacman'], "_addFrameGroupNamed_origin_size_frameCount_", ["up", smalltalk.send((100), "__at", [(50)]), smalltalk.send((50), "__at", [(50)]), (2)]);
smalltalk.send(self['@pacman'], "_centre_", [smalltalk.send((100), "__at", [(100)])]);
return self;},
args: [],
source: unescape('createPacman%0A%09pacman%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/pacman.png%27.%0A%09pacman%20addFrameGroupNamed%3A%20%27left%27%20origin%3A%20%280@0%29%20size%3A%20%2850@50%29%20frameCount%3A%202.%0A%09pacman%20addFrameGroupNamed%3A%20%27right%27%20origin%3A%20%280@50%29%20size%3A%20%2850@50%29%20frameCount%3A%202.%0A%09pacman%20addFrameGroupNamed%3A%20%27down%27%20origin%3A%20%28100@0%29%20size%3A%20%2850@50%29%20frameCount%3A%202.%0A%09pacman%20addFrameGroupNamed%3A%20%27up%27%20origin%3A%20%28100@50%29%20size%3A%20%2850@50%29%20frameCount%3A%202.%0A%09pacman%20centre%3A%20100@100.'),
messageSends: ["spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "centre:"],
referencedClasses: ["Sprite"]
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_createGhost'),
smalltalk.method({
selector: unescape('createGhost'),
category: 'not yet classified',
fn: function (){
var self=this;
self['@ghost']=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/ghost.png")]);
smalltalk.send(self['@ghost'], "_addFrameGroupNamed_origin_size_frameCount_", ["down", smalltalk.send((0), "__at", [(0)]), smalltalk.send((50), "__at", [(55)]), (2)]);
smalltalk.send(self['@ghost'], "_addFrameGroupNamed_origin_size_frameCount_", ["up", smalltalk.send((100), "__at", [(0)]), smalltalk.send((50), "__at", [(55)]), (2)]);
smalltalk.send(self['@ghost'], "_addFrameGroupNamed_origin_size_frameCount_", ["right", smalltalk.send((0), "__at", [(55)]), smalltalk.send((50), "__at", [(55)]), (2)]);
smalltalk.send(self['@ghost'], "_addFrameGroupNamed_origin_size_frameCount_", ["left", smalltalk.send((100), "__at", [(55)]), smalltalk.send((50), "__at", [(55)]), (2)]);
smalltalk.send(self['@ghost'], "_centre_", [smalltalk.send((500), "__at", [(500)])]);
return self;},
args: [],
source: unescape('createGhost%0A%09ghost%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/ghost.png%27.%0A%09ghost%20addFrameGroupNamed%3A%20%27down%27%20origin%3A%20%280@0%29%20size%3A%20%2850@55%29%20frameCount%3A%202.%0A%09ghost%20addFrameGroupNamed%3A%20%27up%27%20origin%3A%20%28100@0%29%20size%3A%20%2850@55%29%20frameCount%3A%202.%0A%09ghost%20addFrameGroupNamed%3A%20%27right%27%20origin%3A%20%280@55%29%20size%3A%20%2850@55%29%20frameCount%3A%202.%0A%09ghost%20addFrameGroupNamed%3A%20%27left%27%20origin%3A%20%28100@55%29%20size%3A%20%2850@55%29%20frameCount%3A%202.%0A%09ghost%20centre%3A%20500@500.'),
messageSends: ["spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "centre:"],
referencedClasses: ["Sprite"]
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_draw'),
smalltalk.method({
selector: unescape('draw'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_clearCanvas", []);
smalltalk.send(self, "_drawSprite_", [self['@ghost']]);
smalltalk.send(self, "_drawSprite_", [self['@pacman']]);
return self;},
args: [],
source: unescape('draw%0A%09self%20clearCanvas.%0A%09self%20drawSprite%3A%20ghost.%0A%09self%20drawSprite%3A%20pacman.'),
messageSends: ["clearCanvas", "drawSprite:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveUp'),
smalltalk.method({
selector: unescape('moveUp'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@pacman'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver <=(25) : smalltalk.send($receiver, "__lt_eq", [(25)]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(-15)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(-15)])]);})]));
smalltalk.send(self['@pacman'], "_currentFrameGroup_", ["up"]);
return self;},
args: [],
source: unescape('moveUp%0A%09pacman%20centre%20y%20%3C%3D%2025%0A%09%09ifFalse%3A%20%0A%09%09%09%5Bpacman%20moveCentreBy%3A%20%280@%20-15%29%5D.%0A%09pacman%20currentFrameGroup%3A%20%27up%27'),
messageSends: ["ifFalse:", unescape("%3C%3D"), "y", "centre", "moveCentreBy:", unescape("@"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveDown'),
smalltalk.method({
selector: unescape('moveDown'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@pacman'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver +(25) : smalltalk.send($receiver, "__plus", [(25)]))).klass === smalltalk.Number) ? $receiver >=smalltalk.send(self, "_height", []) : smalltalk.send($receiver, "__gt_eq", [smalltalk.send(self, "_height", [])]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(15)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(15)])]);})]));
smalltalk.send(self['@pacman'], "_currentFrameGroup_", ["down"]);
return self;},
args: [],
source: unescape('moveDown%0A%09%28pacman%20centre%20y%20+%2025%29%20%3E%3D%20self%20height%20%0A%09%09ifFalse%3A%20%0A%09%09%09%5Bpacman%20moveCentreBy%3A%20%280@%2015%29%5D.%0A%09pacman%20currentFrameGroup%3A%20%27down%27'),
messageSends: ["ifFalse:", unescape("%3E%3D"), unescape("+"), "y", "centre", "height", "moveCentreBy:", unescape("@"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveLeft'),
smalltalk.method({
selector: unescape('moveLeft'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@pacman'], "_centre", []), "_x", [])).klass === smalltalk.Number) ? $receiver <=(25) : smalltalk.send($receiver, "__lt_eq", [(25)]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((-15), "__at", [(0)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((-15), "__at", [(0)])]);})]));
smalltalk.send(self['@pacman'], "_currentFrameGroup_", ["left"]);
return self;},
args: [],
source: unescape('moveLeft%0A%09pacman%20centre%20x%20%3C%3D%2025%0A%09%09ifFalse%3A%20%0A%09%09%09%5Bpacman%20moveCentreBy%3A%20%28-15@%200%29%5D.%0A%09pacman%20currentFrameGroup%3A%20%27left%27'),
messageSends: ["ifFalse:", unescape("%3C%3D"), "x", "centre", "moveCentreBy:", unescape("@"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveRight'),
smalltalk.method({
selector: unescape('moveRight'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@pacman'], "_centre", []), "_x", [])).klass === smalltalk.Number) ? $receiver +(25) : smalltalk.send($receiver, "__plus", [(25)]))).klass === smalltalk.Number) ? $receiver >=smalltalk.send(self, "_width", []) : smalltalk.send($receiver, "__gt_eq", [smalltalk.send(self, "_width", [])]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((15), "__at", [(0)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@pacman'], "_moveCentreBy_", [smalltalk.send((15), "__at", [(0)])]);})]));
smalltalk.send(self['@pacman'], "_currentFrameGroup_", ["right"]);
return self;},
args: [],
source: unescape('moveRight%0A%09pacman%20centre%20x%20+%2025%20%3E%3D%20self%20width%0A%09%09ifFalse%3A%20%0A%09%09%09%5Bpacman%20moveCentreBy%3A%20%2815@%200%29%5D.%0A%09pacman%20currentFrameGroup%3A%20%27right%27'),
messageSends: ["ifFalse:", unescape("%3E%3D"), unescape("+"), "x", "centre", "width", "moveCentreBy:", unescape("@"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveGhost'),
smalltalk.method({
selector: unescape('moveGhost'),
category: 'not yet classified',
fn: function (){
var self=this;
var direction=nil;
direction=smalltalk.send((4), "_atRandom", []);
((($receiver = smalltalk.send(direction, "__eq", [(1)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_moveGhostUp", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_moveGhostUp", []);})]));
((($receiver = smalltalk.send(direction, "__eq", [(2)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_moveGhostDown", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_moveGhostDown", []);})]));
((($receiver = smalltalk.send(direction, "__eq", [(3)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_moveGhostLeft", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_moveGhostLeft", []);})]));
((($receiver = smalltalk.send(direction, "__eq", [(4)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_moveGhostRight", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_moveGhostRight", []);})]));
return self;},
args: [],
source: unescape('moveGhost%0A%09%7Cdirection%7C%0A%09direction%20%3A%3D%204%20atRandom.%0A%09direction%20%3D%201%20ifTrue%3A%20%5Bself%20moveGhostUp%5D.%0A%09direction%20%3D%202%20ifTrue%3A%20%5Bself%20moveGhostDown%5D.%0A%09direction%20%3D%203%20ifTrue%3A%20%5Bself%20moveGhostLeft%5D.%0A%09direction%20%3D%204%20ifTrue%3A%20%5Bself%20moveGhostRight%5D.'),
messageSends: ["atRandom", "ifTrue:", unescape("%3D"), "moveGhostUp", "moveGhostDown", "moveGhostLeft", "moveGhostRight"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveGhostDown'),
smalltalk.method({
selector: unescape('moveGhostDown'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ghost'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver +(27) : smalltalk.send($receiver, "__plus", [(27)]))).klass === smalltalk.Number) ? $receiver >=smalltalk.send(self, "_height", []) : smalltalk.send($receiver, "__gt_eq", [smalltalk.send(self, "_height", [])]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(15)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(15)])]);})]));
smalltalk.send(self['@ghost'], "_currentFrameGroup_", ["down"]);
return self;},
args: [],
source: unescape('moveGhostDown%0A%09%28ghost%20centre%20y%20+%2027%29%20%3E%3D%20self%20height%20%0A%09%09ifFalse%3A%20%0A%09%09%09%5Bghost%20moveCentreBy%3A%20%280@%2015%29%5D.%0A%09ghost%20currentFrameGroup%3A%20%27down%27'),
messageSends: ["ifFalse:", unescape("%3E%3D"), unescape("+"), "y", "centre", "height", "moveCentreBy:", unescape("@"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveGhostLeft'),
smalltalk.method({
selector: unescape('moveGhostLeft'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ghost'], "_centre", []), "_x", [])).klass === smalltalk.Number) ? $receiver <=(25) : smalltalk.send($receiver, "__lt_eq", [(25)]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((-15), "__at", [(0)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((-15), "__at", [(0)])]);})]));
smalltalk.send(self['@ghost'], "_currentFrameGroup_", ["left"]);
return self;},
args: [],
source: unescape('moveGhostLeft%0A%09ghost%20centre%20x%20%3C%3D%2025%0A%09%09ifFalse%3A%20%0A%09%09%09%5Bghost%20moveCentreBy%3A%20%28-15@%200%29%5D.%0A%09ghost%20currentFrameGroup%3A%20%27left%27'),
messageSends: ["ifFalse:", unescape("%3C%3D"), "x", "centre", "moveCentreBy:", unescape("@"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveGhostUp'),
smalltalk.method({
selector: unescape('moveGhostUp'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ghost'], "_centre", []), "_y", [])).klass === smalltalk.Number) ? $receiver <=(27) : smalltalk.send($receiver, "__lt_eq", [(27)]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(-15)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((0), "__at", [(-15)])]);})]));
smalltalk.send(self['@ghost'], "_currentFrameGroup_", ["up"]);
return self;},
args: [],
source: unescape('moveGhostUp%0A%09ghost%20centre%20y%20%3C%3D%2027%0A%09%09ifFalse%3A%20%0A%09%09%09%5Bghost%20moveCentreBy%3A%20%280@%20-15%29%5D.%0A%09ghost%20currentFrameGroup%3A%20%27up%27'),
messageSends: ["ifFalse:", unescape("%3C%3D"), "y", "centre", "moveCentreBy:", unescape("@"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_moveGhostRight'),
smalltalk.method({
selector: unescape('moveGhostRight'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@ghost'], "_centre", []), "_x", [])).klass === smalltalk.Number) ? $receiver +(25) : smalltalk.send($receiver, "__plus", [(25)]))).klass === smalltalk.Number) ? $receiver >=smalltalk.send(self, "_width", []) : smalltalk.send($receiver, "__gt_eq", [smalltalk.send(self, "_width", [])]))).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((15), "__at", [(0)])]);})() : nil) : smalltalk.send($receiver, "_ifFalse_", [(function(){return smalltalk.send(self['@ghost'], "_moveCentreBy_", [smalltalk.send((15), "__at", [(0)])]);})]));
smalltalk.send(self['@ghost'], "_currentFrameGroup_", ["right"]);
return self;},
args: [],
source: unescape('moveGhostRight%0A%09ghost%20centre%20x%20+%2025%20%3E%3D%20self%20width%0A%09%09ifFalse%3A%20%0A%09%09%09%5Bghost%20moveCentreBy%3A%20%2815@%200%29%5D.%0A%09ghost%20currentFrameGroup%3A%20%27right%27'),
messageSends: ["ifFalse:", unescape("%3E%3D"), unescape("+"), "x", "centre", "width", "moveCentreBy:", unescape("@"), "currentFrameGroup:"],
referencedClasses: []
}),
smalltalk.SimplePacman);

smalltalk.addMethod(
unescape('_step'),
smalltalk.method({
selector: unescape('step'),
category: 'not yet classified',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_leftArrow", []), (function(){return smalltalk.send(self, "_moveLeft", []);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_rightArrow", []), (function(){return smalltalk.send(self, "_moveRight", []);})]);smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_upArrow", []), (function(){return smalltalk.send(self, "_moveUp", []);})]);return smalltalk.send($rec, "_whileKeyPressed_do_", [smalltalk.send((smalltalk.Key || Key), "_downArrow", []), (function(){return smalltalk.send(self, "_moveDown", []);})]);})(self);
smalltalk.send(self, "_onMouseClickDo_", [(function(){return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(self, "_mousePosition", []), "_x", []), "_asString", []), "__comma", [unescape("%2C")]), "__comma", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_mousePosition", []), "_y", []), "_asString", [])])]);})]);
smalltalk.send(self, "_moveGhost", []);
((($receiver = smalltalk.send(self['@pacman'], "_collidesWith_", [self['@ghost']])).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("You%20lost%21")]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){smalltalk.send(self, "_end", []);return smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [unescape("You%20lost%21")]);})]));
return self;},
args: [],
source: unescape('step%0A%09self%20whileKeyPressed%3A%20Key%20leftArrow%20do%3A%20%5Bself%20moveLeft%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20rightArrow%20do%3A%20%5Bself%20moveRight%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20upArrow%20do%3A%20%5Bself%20moveUp%5D%3B%0A%09%09whileKeyPressed%3A%20Key%20downArrow%20do%3A%20%5Bself%20moveDown%5D.%0A%09self%20onMouseClickDo%3A%20%5Bwindow%20alert%3A%20self%20mousePosition%20x%20asString%20%2C%20%27%2C%27%20%2C%20self%20mousePosition%20y%20asString%5D.%0A%09self%20moveGhost.%0A%09%28pacman%20collidesWith%3A%20ghost%29%20ifTrue%3A%20%5Bself%20end.%20window%20alert%3A%20%27You%20lost%21%27%5D'),
messageSends: ["whileKeyPressed:do:", "leftArrow", "moveLeft", "rightArrow", "moveRight", "upArrow", "moveUp", "downArrow", "moveDown", "onMouseClickDo:", "alert:", unescape("%2C"), "asString", "x", "mousePosition", "y", "moveGhost", "ifTrue:", "collidesWith:", "end"],
referencedClasses: ["Key"]
}),
smalltalk.SimplePacman);



smalltalk.addClass('SmallCave', smalltalk.Game, ['ship', 'gravity', 'trail', 'upOrDown', 'bumps', 'goingUp', 'light', 'maxVariation', 'obstaclePositions', 'started', 'scrollSpeed'], 'Ludus-Examples');
smalltalk.addMethod(
unescape('_startGame'),
smalltalk.method({
selector: unescape('startGame'),
category: 'not yet classified',
fn: function (){
var self=this;
self['@fps']=(30);
self['@gravity']=(1.1);
(function($rec){smalltalk.send($rec, "_width_", [(720)]);smalltalk.send($rec, "_height_", [(540)]);return smalltalk.send($rec, "_backgroundColor_", ["black"]);})(self);
return self;},
args: [],
source: unescape('startGame%0A%09fps%20%3A%3D%2030.%0A%09gravity%20%3A%3D%201.1.%0A%0A%09self%20width%3A%20720%3B%20%0A%09%09height%3A%20540%3B%0A%09%09backgroundColor%3A%20%27black%27.'),
messageSends: ["width:", "height:", "backgroundColor:"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_draw'),
smalltalk.method({
selector: unescape('draw'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = smalltalk.send(self, "_started", [])).klass === smalltalk.Boolean) ? (! $receiver ? (function(){return smalltalk.send(self, "_drawWelcomeScreen", []);})() : (function(){(function($rec){smalltalk.send($rec, "_clearCanvas", []);smalltalk.send($rec, "_drawCeiling", []);smalltalk.send($rec, "_drawFloor", []);smalltalk.send($rec, "_drawObstacles", []);return smalltalk.send($rec, "_drawSprite_", [self['@ship']]);})(self);return smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_allButLast", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})()) : smalltalk.send($receiver, "_ifFalse_ifTrue_", [(function(){return smalltalk.send(self, "_drawWelcomeScreen", []);}), (function(){(function($rec){smalltalk.send($rec, "_clearCanvas", []);smalltalk.send($rec, "_drawCeiling", []);smalltalk.send($rec, "_drawFloor", []);smalltalk.send($rec, "_drawObstacles", []);return smalltalk.send($rec, "_drawSprite_", [self['@ship']]);})(self);return smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_allButLast", []), "_do_", [(function(each){return smalltalk.send(self, "_drawSprite_", [each]);})]);})]));
smalltalk.send(self, "_onMouseClickDo_", [(function(){return self['@started']=true;})]);
return self;},
args: [],
source: unescape('draw%0A%09self%20started%20%0A%09%09ifFalse%3A%20%5Bself%20drawWelcomeScreen%5D%0A%09%09ifTrue%3A%20%5B%0A%09%09%09self%20clearCanvas%3B%0A%09%09%09%09drawCeiling%3B%20%0A%09%09%09%09drawFloor%3B%0A%09%09%09%09drawObstacles%3B%0A%09%09%09%09drawSprite%3A%20ship.%0A%09%09%09self%20trail%20allButLast%20do%3A%20%5B%3Aeach%20%7C%20self%20drawSprite%3A%20each%20%5D%5D.%0A%09self%20onMouseClickDo%3A%20%5Bstarted%20%3A%3D%20true%5D.'),
messageSends: ["ifFalse:ifTrue:", "started", "drawWelcomeScreen", "clearCanvas", "drawCeiling", "drawFloor", "drawObstacles", "drawSprite:", "do:", "allButLast", "trail", "onMouseClickDo:"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_step'),
smalltalk.method({
selector: unescape('step'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = smalltalk.send(self, "_started", [])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return (function($rec){smalltalk.send($rec, "_detectCollision", []);smalltalk.send($rec, "_updateTrail", []);smalltalk.send($rec, "_updateBumps", []);smalltalk.send($rec, "_updateObstacles", []);smalltalk.send($rec, "_updateDifficulty", []);return smalltalk.send($rec, "_moveShip", []);})(self);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return (function($rec){smalltalk.send($rec, "_detectCollision", []);smalltalk.send($rec, "_updateTrail", []);smalltalk.send($rec, "_updateBumps", []);smalltalk.send($rec, "_updateObstacles", []);smalltalk.send($rec, "_updateDifficulty", []);return smalltalk.send($rec, "_moveShip", []);})(self);})]));
return self;},
args: [],
source: unescape('step%0A%09self%20started%20ifTrue%3A%20%5Bself%20detectCollision%3B%20updateTrail%3B%20updateBumps%3B%20updateObstacles%3B%20updateDifficulty%3B%20moveShip%5D'),
messageSends: ["ifTrue:", "started", "detectCollision", "updateTrail", "updateBumps", "updateObstacles", "updateDifficulty", "moveShip"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_ship'),
smalltalk.method({
selector: unescape('ship'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@ship']) == nil || $receiver == undefined) ? (function(){return self['@ship']=smalltalk.send(smalltalk.send((smalltalk.Ship || Ship), "_new", []), "_centre_", [smalltalk.send((105), "__at", [((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))])]);})() : $receiver;
return self;},
args: [],
source: unescape('ship%0A%09%5E%20ship%20ifNil%3A%20%5Bship%20%3A%3D%20Ship%20new%20centre%3A%20105%20@%20%28self%20height%20/%202%29%5D'),
messageSends: ["ifNil:", "centre:", "new", unescape("@"), unescape("/"), "height"],
referencedClasses: ["Ship"]
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_moveShip'),
smalltalk.method({
selector: unescape('moveShip'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_whileMouseUpDo_", [(function(){return smalltalk.send(smalltalk.send(self, "_ship", []), "_increaseSpeed", []);})]);
smalltalk.send(self, "_whileMouseDownDo_", [(function(){return smalltalk.send(smalltalk.send(self, "_ship", []), "_decreaseSpeed", []);})]);
smalltalk.send(smalltalk.send(self, "_ship", []), "_y_", [((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_y", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_speed", [])).klass === smalltalk.Number) ? $receiver *self['@gravity'] : smalltalk.send($receiver, "__star", [self['@gravity']])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_speed", [])).klass === smalltalk.Number) ? $receiver *self['@gravity'] : smalltalk.send($receiver, "__star", [self['@gravity']]))]))]);
return self;},
args: [],
source: unescape('moveShip%0A%09self%20whileMouseUpDo%3A%20%5Bself%20ship%20increaseSpeed%5D.%0A%09self%20whileMouseDownDo%3A%20%5Bself%20ship%20decreaseSpeed%5D.%0A%09self%20ship%20y%3A%20%28self%20ship%20y%20+%20%28self%20ship%20speed%20*%20gravity%29%29'),
messageSends: ["whileMouseUpDo:", "increaseSpeed", "ship", "whileMouseDownDo:", "decreaseSpeed", "y:", unescape("+"), "y", unescape("*"), "speed"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_trail'),
smalltalk.method({
selector: unescape('trail'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@trail']) == nil || $receiver == undefined) ? (function(){self['@trail']=[];smalltalk.send((0), "_to_do_", [(10), (function(i){var ghostBall=nil;
ghostBall=smalltalk.send(smalltalk.send((smalltalk.Sprite || Sprite), "_new", []), "_spriteSheet_", [unescape("images/trail.png")]);smalltalk.send(ghostBall, "_addFrameGroupNamed_origin_size_frameCount_", ["trail", smalltalk.send((0), "__at", [(0)]), smalltalk.send((10), "__at", [(10)]), (1)]);smalltalk.send(ghostBall, "_position_", [smalltalk.send(((($receiver = i).klass === smalltalk.Number) ? $receiver *(10) : smalltalk.send($receiver, "__star", [(10)])), "__at", [((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))])]);return smalltalk.send(self['@trail'], "_add_", [ghostBall]);})]);return self['@trail'];})() : $receiver;
return self;},
args: [],
source: unescape('trail%0A%09%5E%20trail%20ifNil%3A%20%5B%0A%20%20%20%20%20%20%20%20%09trail%20%3A%3D%20%23%28%29.%0A%20%20%20%20%20%20%20%20%20%20%090%20to%3A%2010%20do%3A%20%5B%3Ai%20%7C%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%7CghostBall%7C%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20ghostBall%20%3A%3D%20Sprite%20new%20spriteSheet%3A%20%27images/trail.png%27.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20ghostBall%20addFrameGroupNamed%3A%20%27trail%27%20origin%3A%20%280@0%29%20size%3A%20%2810@10%29%20frameCount%3A%201.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20ghostBall%20position%3A%20%28i%20*%2010%29%20@%20%28self%20height%20/%202%29.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20trail%20add%3A%20ghostBall.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%5D.%0A%09%09trail%5D'),
messageSends: ["ifNil:", "to:do:", "spriteSheet:", "new", "addFrameGroupNamed:origin:size:frameCount:", unescape("@"), "position:", unescape("*"), unescape("/"), "height", "add:"],
referencedClasses: ["Sprite"]
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_updateTrail'),
smalltalk.method({
selector: unescape('updateTrail'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_allButLast", []), "_withIndexDo_", [(function(each, i){return smalltalk.send(each, "_y_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_at_", [((($receiver = i).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]))]), "_y", [])]);})]);
smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_last", []), "_centre_", [smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(self, "_trail", []), "_last", []), "_x", []), "__at", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_ship", []), "_centre", []), "_y", [])])]);
return self;},
args: [],
source: unescape('updateTrail%0A%09self%20trail%20allButLast%20withIndexDo%3A%20%5B%3Aeach%20%3Ai%20%7C%20each%20y%3A%20%28self%20trail%20at%3A%20i%20+%201%29%20y%5D.%0A%09self%20trail%20last%20centre%3A%20self%20trail%20last%20x%20@%20self%20ship%20centre%20y.'),
messageSends: ["withIndexDo:", "allButLast", "trail", "y:", "y", "at:", unescape("+"), "centre:", "last", unescape("@"), "x", "centre", "ship"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_drawCeiling'),
smalltalk.method({
selector: unescape('drawCeiling'),
category: 'not yet classified',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_beginPath", []);smalltalk.send($rec, "_moveTo_y_", [(-200), (0)]);return smalltalk.send($rec, "_lineTo_y_", [(-200), smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_first", []), "_y", [])]);})(self['@context']);
smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_allButFirst", []), "_allButLast", []), "_do_", [(function(eachBump){return smalltalk.send(self['@context'], "_lineTo_y_", [smalltalk.send(eachBump, "_x", []), smalltalk.send(eachBump, "_y", [])]);})]);
(function($rec){smalltalk.send($rec, "_lineTo_y_", [smalltalk.send(self, "_width", []), smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_last", []), "_y", [])]);smalltalk.send($rec, "_lineTo_y_", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +(200) : smalltalk.send($receiver, "__plus", [(200)])), (0)]);smalltalk.send($rec, "_closePath", []);smalltalk.send($rec, "_fillStyle_", ["green"]);return smalltalk.send($rec, "_fill", []);})(self['@context']);
return self;},
args: [],
source: unescape('drawCeiling%0A%09context%0A%09%09beginPath%3B%0A%09%09moveTo%3A-200%20y%3A%200%3B%0A%09%09lineTo%3A%20-200%20y%3A%20self%20bumps%20first%20y.%0A%0A%09self%20bumps%20allButFirst%20allButLast%20do%3A%20%5B%3AeachBump%20%7C%0A%09%09context%20lineTo%3A%20eachBump%20x%20y%3A%20eachBump%20y%5D.%0A%0A%09context%0A%09%09lineTo%3A%20self%20width%20y%3A%20self%20bumps%20last%20y%3B%0A%09%09lineTo%3A%20self%20width%20+%20200%20y%3A%200%3B%0A%09%09closePath%3B%0A%09%09fillStyle%3A%20%27green%27%3B%0A%09%09fill.'),
messageSends: ["beginPath", "moveTo:y:", "lineTo:y:", "y", "first", "bumps", "do:", "allButLast", "allButFirst", "x", "width", "last", unescape("+"), "closePath", "fillStyle:", "fill"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_drawFloor'),
smalltalk.method({
selector: unescape('drawFloor'),
category: 'not yet classified',
fn: function (){
var self=this;
(function($rec){smalltalk.send($rec, "_beginPath", []);smalltalk.send($rec, "_moveTo_y_", [(-200), smalltalk.send(self, "_height", [])]);return smalltalk.send($rec, "_lineTo_y_", [(-200), ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_first", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_light", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_light", [])]))]);})(self['@context']);
smalltalk.send(smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_allButFirst", []), "_allButLast", []), "_do_", [(function(eachBump){return smalltalk.send(self['@context'], "_lineTo_y_", [smalltalk.send(eachBump, "_x", []), ((($receiver = smalltalk.send(eachBump, "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_light", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_light", [])]))]);})]);
(function($rec){smalltalk.send($rec, "_lineTo_y_", [smalltalk.send(self, "_width", []), ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_light", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_light", [])]))]);smalltalk.send($rec, "_lineTo_y_", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +(200) : smalltalk.send($receiver, "__plus", [(200)])), smalltalk.send(self, "_height", [])]);smalltalk.send($rec, "_closePath", []);smalltalk.send($rec, "_fillStyle_", ["green"]);return smalltalk.send($rec, "_fill", []);})(self['@context']);
return self;},
args: [],
source: unescape('drawFloor%0A%09context%0A%09%09beginPath%3B%0A%09%09moveTo%3A-200%20y%3A%20self%20height%3B%0A%09%09lineTo%3A%20-200%20y%3A%20self%20bumps%20first%20y%20+%20self%20light.%0A%0A%09self%20bumps%20allButFirst%20allButLast%20do%3A%20%5B%3AeachBump%20%7C%0A%09%09context%20lineTo%3A%20eachBump%20x%20y%3A%20eachBump%20y%20+%20self%20light%5D.%0A%0A%09context%0A%09%09lineTo%3A%20self%20width%20y%3A%20self%20bumps%20last%20y%20+%20self%20light%3B%0A%09%09lineTo%3A%20self%20width%20+%20200%20y%3A%20self%20height%3B%0A%09%09closePath%3B%0A%09%09fillStyle%3A%20%27green%27%3B%0A%09%09fill.'),
messageSends: ["beginPath", "moveTo:y:", "height", "lineTo:y:", unescape("+"), "y", "first", "bumps", "light", "do:", "allButLast", "allButFirst", "x", "width", "last", "closePath", "fillStyle:", "fill"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_detectCollision'),
smalltalk.method({
selector: unescape('detectCollision'),
category: 'not yet classified',
fn: function (){
var self=this;
var imageData=nil;
var greenComponent=nil;
imageData=smalltalk.send(self['@context'], "_getImageData_y_width_height_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_ship", []), "_centre", []), "_x", []), ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_ship", []), "_height", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_ship", []), "_height", [])]))).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)])), (1), (1)]);
greenComponent = imageData.data[1];;
((($receiver = ((($receiver = greenComponent).klass === smalltalk.Number) ? $receiver >(0) : smalltalk.send($receiver, "__gt", [(0)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_end", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_end", []);})]));
imageData=smalltalk.send(self['@context'], "_getImageData_y_width_height_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_ship", []), "_centre", []), "_x", []), ((($receiver = smalltalk.send(smalltalk.send(self, "_ship", []), "_y", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)])), (1), (1)]);
greenComponent = imageData.data[1];;
((($receiver = ((($receiver = greenComponent).klass === smalltalk.Number) ? $receiver >(0) : smalltalk.send($receiver, "__gt", [(0)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return smalltalk.send(self, "_end", []);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return smalltalk.send(self, "_end", []);})]));
return self;},
args: [],
source: unescape('detectCollision%0A%09%7CimageData%20greenComponent%7C%0A%0A%09imageData%20%3A%3D%20context%20getImageData%3A%20self%20ship%20centre%20x%20y%3A%20self%20ship%20y%20+%20self%20ship%20height%20+%201%20width%3A%201%20height%3A%201.%0A%09%3CgreenComponent%20%3D%20imageData.data%5B1%5D%3B%3E.%0A%20%20%20%20%20%20%20%20greenComponent%20%3E%200%20ifTrue%3A%20%5Bself%20end%5D.%0A%0A%09imageData%20%3A%3D%20context%20getImageData%3A%20self%20ship%20centre%20x%20y%3A%20self%20ship%20y%20-%201%20width%3A%201%20height%3A%201.%0A%09%3CgreenComponent%20%3D%20imageData.data%5B1%5D%3B%3E.%0A%20%20%20%20%20%20%20%20greenComponent%20%3E%200%20ifTrue%3A%20%5Bself%20end%5D.'),
messageSends: ["getImageData:y:width:height:", "x", "centre", "ship", unescape("+"), "y", "height", "ifTrue:", unescape("%3E"), "end", unescape("-")],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_updateBumps'),
smalltalk.method({
selector: unescape('updateBumps'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_second", []), "_x", [])).klass === smalltalk.Number) ? $receiver <((($receiver = (0) - smalltalk.send(self, "_scrollSpeed", [])).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))])) : smalltalk.send($receiver, "__lt", [((($receiver = (0) - smalltalk.send(self, "_scrollSpeed", [])).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))]))]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){var y=nil;
y=((($receiver = smalltalk.send(self, "_goingUp", [])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]))).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))]));})() : (function(){return ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]));})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]))).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))]));}), (function(){return ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]));})]));smalltalk.send(smalltalk.send(self, "_bumps", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))])), "__at", [y])]);return smalltalk.send(smalltalk.send(self, "_bumps", []), "_remove_", [smalltalk.send(smalltalk.send(self, "_bumps", []), "_first", [])]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){var y=nil;
y=((($receiver = smalltalk.send(self, "_goingUp", [])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]))).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))]));})() : (function(){return ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]));})()) : smalltalk.send($receiver, "_ifTrue_ifFalse_", [(function(){return ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]))).klass === smalltalk.Number) ? $receiver -((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)])) : smalltalk.send($receiver, "__minus", [((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver *(2) : smalltalk.send($receiver, "__star", [(2)]))]));}), (function(){return ((($receiver = smalltalk.send(smalltalk.send(self['@bumps'], "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_maxVariation", []), "_atRandom", [])]));})]));smalltalk.send(smalltalk.send(self, "_bumps", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))])), "__at", [y])]);return smalltalk.send(smalltalk.send(self, "_bumps", []), "_remove_", [smalltalk.send(smalltalk.send(self, "_bumps", []), "_first", [])]);})]));
smalltalk.send(smalltalk.send(self, "_bumps", []), "_do_", [(function(each){return smalltalk.send(each, "_x_", [((($receiver = smalltalk.send(each, "_x", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self, "_scrollSpeed", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self, "_scrollSpeed", [])]))]);})]);
return self;},
args: [],
source: unescape('updateBumps%0A%09self%20bumps%20second%20x%20%3C%20%28%200%20-%20self%20scrollSpeed%20-%20%28self%20width%20/%2025%29%29%0A%09%09ifTrue%3A%20%5B%7Cy%7C%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20y%20%3A%3D%20self%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09goingUp%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09ifTrue%3A%20%5Bbumps%20last%20y%20+%20self%20maxVariation%20atRandom%20-%20%28self%20maxVariation%20*%202%29%5D%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09ifFalse%3A%20%5Bbumps%20last%20y%20+%20self%20maxVariation%20atRandom%5D.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20self%20bumps%20add%3A%20%28self%20width%20+%20%28self%20width%20/%2025%29%20@%20y%29.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20self%20bumps%20remove%3A%20self%20bumps%20first%5D.%0A%09self%20bumps%20do%3A%20%5B%3Aeach%20%7C%20each%20x%3A%20each%20x%20-%20self%20scrollSpeed%5D.'),
messageSends: ["ifTrue:", unescape("%3C"), "x", "second", "bumps", unescape("-"), "scrollSpeed", unescape("/"), "width", "ifTrue:ifFalse:", "goingUp", unescape("+"), "y", "last", "atRandom", "maxVariation", unescape("*"), "add:", unescape("@"), "remove:", "first", "do:", "x:"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_bumps'),
smalltalk.method({
selector: unescape('bumps'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@bumps']) == nil || $receiver == undefined) ? (function(){return self['@bumps']=smalltalk.send(smalltalk.send((0), "_to_", [(25)]), "_collect_", [(function(x){return smalltalk.send(((($receiver = ((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(25) : smalltalk.send($receiver, "__slash", [(25)]))).klass === smalltalk.Number) ? $receiver *x : smalltalk.send($receiver, "__star", [x])), "__at", [((($receiver = smalltalk.send(((($receiver = self['@step']).klass === smalltalk.Number) ? $receiver /(20) : smalltalk.send($receiver, "__slash", [(20)])), "_atRandom", [])).klass === smalltalk.Number) ? $receiver +((($receiver = self['@step']).klass === smalltalk.Number) ? $receiver /(20) : smalltalk.send($receiver, "__slash", [(20)])) : smalltalk.send($receiver, "__plus", [((($receiver = self['@step']).klass === smalltalk.Number) ? $receiver /(20) : smalltalk.send($receiver, "__slash", [(20)]))]))]);})]);})() : $receiver;
return self;},
args: [],
source: unescape('bumps%0A%09%5Ebumps%20ifNil%3A%20%5Bbumps%20%3A%3D%20%280%20to%3A%2025%29%20collect%3A%20%5B%3Ax%20%7C%20%28self%20width%20/%2025%29%20*%20x%20@%20%28%28step%20/%2020%29%20atRandom%20+%20%28step%20/%2020%29%29%5D%5D'),
messageSends: ["ifNil:", "collect:", "to:", unescape("@"), unescape("*"), unescape("/"), "width", unescape("+"), "atRandom"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_goingUp'),
smalltalk.method({
selector: unescape('goingUp'),
category: 'not yet classified',
fn: function (){
var self=this;
(($receiver = self['@goingUp']) == nil || $receiver == undefined) ? (function(){return self['@goingUp']=false;})() : $receiver;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver <(0) : smalltalk.send($receiver, "__lt", [(0)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@goingUp']=false;})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@goingUp']=false;})]));
((($receiver = ((($receiver = ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_bumps", []), "_last", []), "_y", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_light", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_light", [])]))).klass === smalltalk.Number) ? $receiver >smalltalk.send(self, "_height", []) : smalltalk.send($receiver, "__gt", [smalltalk.send(self, "_height", [])]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@goingUp']=true;})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@goingUp']=true;})]));
return self['@goingUp'];
return self;},
args: [],
source: unescape('goingUp%0A%09goingUp%20ifNil%3A%20%5BgoingUp%20%3A%3D%20false%5D.%0A%09self%20bumps%20last%20y%20%3C%200%20ifTrue%3A%20%5BgoingUp%20%3A%3D%20false%5D.%0A%09%28self%20bumps%20last%20y%20+%20self%20light%29%20%3E%20self%20height%20ifTrue%3A%20%5BgoingUp%20%3A%3D%20true%5D.%0A%09%5E%20goingUp'),
messageSends: ["ifNil:", "ifTrue:", unescape("%3C"), "y", "last", "bumps", unescape("%3E"), unescape("+"), "light", "height"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_light'),
smalltalk.method({
selector: unescape('light'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@light']) == nil || $receiver == undefined) ? (function(){return self['@light']=((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver *(0.75) : smalltalk.send($receiver, "__star", [(0.75)]));})() : $receiver;
return self;},
args: [],
source: unescape('light%0A%09%5E%20light%20ifNil%3A%20%5B%09light%20%3A%3D%20%28self%20height%20*%200.75%29%20%5D'),
messageSends: ["ifNil:", unescape("*"), "height"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_maxVariation'),
smalltalk.method({
selector: unescape('maxVariation'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@maxVariation']) == nil || $receiver == undefined) ? (function(){return self['@maxVariation']=(2);})() : $receiver;
return self;},
args: [],
source: unescape('maxVariation%0A%09%5E%20maxVariation%20ifNil%3A%20%5BmaxVariation%20%3A%3D%202%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_updateDifficulty'),
smalltalk.method({
selector: unescape('updateDifficulty'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_stepCount", []), "_\\\\", [(200)]), "__eq", [(0)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@goingUp']=smalltalk.send([false,true], "_at_", [smalltalk.send((2), "_atRandom", [])]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@goingUp']=smalltalk.send([false,true], "_at_", [smalltalk.send((2), "_atRandom", [])]);})]));
((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_stepCount", []), "_\\\\", [(50)]), "__eq", [(0)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@light']=((($receiver = smalltalk.send(self, "_light", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]));})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@light']=((($receiver = smalltalk.send(self, "_light", [])).klass === smalltalk.Number) ? $receiver -(1) : smalltalk.send($receiver, "__minus", [(1)]));})]));
((($receiver = ((($receiver = smalltalk.send(self, "_light", [])).klass === smalltalk.Number) ? $receiver <(20) : smalltalk.send($receiver, "__lt", [(20)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){return self['@light']=(20);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){return self['@light']=(20);})]));
((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_stepCount", []), "_\\\\", [(1200)]), "__eq", [(0)])).klass === smalltalk.Boolean) ? ($receiver ? (function(){self['@maxVariation']=((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", [])])), "__at", [smalltalk.send(smalltalk.send(self, "_height", []), "_atRandom", [])])]);return self['@scrollSpeed']=((($receiver = smalltalk.send(self, "_scrollSpeed", [])).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){self['@maxVariation']=((($receiver = smalltalk.send(self, "_maxVariation", [])).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", [])])), "__at", [smalltalk.send(smalltalk.send(self, "_height", []), "_atRandom", [])])]);return self['@scrollSpeed']=((($receiver = smalltalk.send(self, "_scrollSpeed", [])).klass === smalltalk.Number) ? $receiver +(1) : smalltalk.send($receiver, "__plus", [(1)]));})]));
return self;},
args: [],
source: unescape('updateDifficulty%0A%09%28self%20stepCount%20%5C%5C%20200%29%20%3D%200%0A%09%09ifTrue%3A%20%5BgoingUp%20%3A%3D%20%7Bfalse.%20true%7D%20at%3A%202%20atRandom%5D.%0A%09%28self%20stepCount%20%5C%5C%2050%20%3D%200%29%0A%09%09ifTrue%3A%20%5Blight%20%3A%3D%20self%20light%20-%201%5D.%0A%09self%20light%20%3C%2020%20ifTrue%3A%20%5Blight%20%3A%3D%2020%5D.%0A%09%28self%20stepCount%20%5C%5C%201200%29%20%3D%200%0A%09%09ifTrue%3A%20%5B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09maxVariation%20%3A%3D%20self%20maxVariation%20+%201.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20self%20obstaclePositions%20add%3A%20%28%28self%20width%20+%20self%20width%20atRandom%29%20@%20%28self%20height%20atRandom%29%29.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20scrollSpeed%20%3A%3D%20self%20scrollSpeed%20+%201%5D.'),
messageSends: ["ifTrue:", unescape("%3D"), unescape("%5C%5C%5C%5C"), "stepCount", "at:", "atRandom", unescape("-"), "light", unescape("%3C"), unescape("+"), "maxVariation", "add:", "obstaclePositions", unescape("@"), "width", "height", "scrollSpeed"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_obstaclePositions'),
smalltalk.method({
selector: unescape('obstaclePositions'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@obstaclePositions']) == nil || $receiver == undefined) ? (function(){return self['@obstaclePositions']=[smalltalk.send(smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "_atRandom", []), "__at", [smalltalk.send(((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "_atRandom", [])]),smalltalk.send(((($receiver = smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "_atRandom", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(self, "_width", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(self, "_width", [])])), "__at", [((($receiver = smalltalk.send(((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])), "_atRandom", [])).klass === smalltalk.Number) ? $receiver +((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)])) : smalltalk.send($receiver, "__plus", [((($receiver = smalltalk.send(self, "_height", [])).klass === smalltalk.Number) ? $receiver /(2) : smalltalk.send($receiver, "__slash", [(2)]))]))])];})() : $receiver;
return self;},
args: [],
source: unescape('obstaclePositions%0A%09%5EobstaclePositions%20ifNil%3A%20%5BobstaclePositions%20%3A%3D%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%7B%20%28self%20width%20/%202%29%20atRandom%20@%20%28self%20height%20/%202%29%20atRandom.%20%28%28self%20width%20/%202%29%20atRandom%20+%20self%20width%29%20@%20%28%28self%20height%20/%202%29%20atRandom%20+%20%28self%20height%20/%202%29%29%20%7D%20%5D'),
messageSends: ["ifNil:", unescape("@"), "atRandom", unescape("/"), "width", "height", unescape("+")],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_drawObstacles'),
smalltalk.method({
selector: unescape('drawObstacles'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_do_", [(function(each){return (function($rec){smalltalk.send($rec, "_fillStyle_", ["green"]);return smalltalk.send($rec, "_fillRect_y_width_height_", [smalltalk.send(each, "_x", []), smalltalk.send(each, "_y", []), (50), (100)]);})(self['@context']);})]);
return self;},
args: [],
source: unescape('drawObstacles%0A%09self%20obstaclePositions%20do%3A%20%5B%3Aeach%20%7C%0A%09%09context%0A%09%09%09fillStyle%3A%20%27green%27%3B%0A%09%09%09fillRect%3A%20each%20x%20y%3A%20each%20y%20width%3A%2050%20height%3A%20100%5D'),
messageSends: ["do:", "obstaclePositions", "fillStyle:", "fillRect:y:width:height:", "x", "y"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_updateObstacles'),
smalltalk.method({
selector: unescape('updateObstacles'),
category: 'not yet classified',
fn: function (){
var self=this;
((($receiver = ((($receiver = smalltalk.send(smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_first", []), "_x", [])).klass === smalltalk.Number) ? $receiver <(-100) : smalltalk.send($receiver, "__lt", [(-100)]))).klass === smalltalk.Boolean) ? ($receiver ? (function(){smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", [])])), "__at", [smalltalk.send(smalltalk.send(self, "_height", []), "_atRandom", [])])]);return smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_remove_", [smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_first", [])]);})() : nil) : smalltalk.send($receiver, "_ifTrue_", [(function(){smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_add_", [smalltalk.send(((($receiver = smalltalk.send(self, "_width", [])).klass === smalltalk.Number) ? $receiver +smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", []) : smalltalk.send($receiver, "__plus", [smalltalk.send(smalltalk.send(self, "_width", []), "_atRandom", [])])), "__at", [smalltalk.send(smalltalk.send(self, "_height", []), "_atRandom", [])])]);return smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_remove_", [smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_first", [])]);})]));
smalltalk.send(smalltalk.send(self, "_obstaclePositions", []), "_do_", [(function(each){return smalltalk.send(each, "_x_", [((($receiver = smalltalk.send(each, "_x", [])).klass === smalltalk.Number) ? $receiver -smalltalk.send(self, "_scrollSpeed", []) : smalltalk.send($receiver, "__minus", [smalltalk.send(self, "_scrollSpeed", [])]))]);})]);
return self;},
args: [],
source: unescape('updateObstacles%0A%09self%20obstaclePositions%20first%20x%20%3C%20-100%0A%09%09ifTrue%3A%20%5B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20self%20obstaclePositions%20add%3A%20%28%28self%20width%20+%20self%20width%20atRandom%29%20@%20%28self%20height%20atRandom%29%29.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20self%20obstaclePositions%20remove%3A%20self%20obstaclePositions%20first%5D.%0A%09self%20obstaclePositions%20do%3A%20%5B%3Aeach%20%7C%20each%20x%3A%20each%20x%20-%20self%20scrollSpeed%5D.'),
messageSends: ["ifTrue:", unescape("%3C"), "x", "first", "obstaclePositions", "add:", unescape("@"), unescape("+"), "width", "atRandom", "height", "remove:", "do:", "x:", unescape("-"), "scrollSpeed"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_started'),
smalltalk.method({
selector: unescape('started'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@started']) == nil || $receiver == undefined) ? (function(){return self['@started']=false;})() : $receiver;
return self;},
args: [],
source: unescape('started%0A%09%5E%20started%20ifNil%3A%20%5Bstarted%20%3A%3D%20false%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_drawWelcomeScreen'),
smalltalk.method({
selector: unescape('drawWelcomeScreen'),
category: 'not yet classified',
fn: function (){
var self=this;
var image=nil;
image=new Image();;
smalltalk.send(image, "_src_", [unescape("images/welcome.png")]);
smalltalk.send(self['@context'], "_drawImage_x_y_", [image, (40), (50)]);
return self;},
args: [],
source: unescape('drawWelcomeScreen%0A%09%7Cimage%7C%0A%09image%20%3A%3D%20%3Cnew%20Image%28%29%3B%3E.%0A%09image%20src%3A%20%27images/welcome.png%27.%0A%09context%20drawImage%3A%20image%20x%3A%2040%20y%3A%2050.'),
messageSends: ["src:", "drawImage:x:y:"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_scrollSpeed'),
smalltalk.method({
selector: unescape('scrollSpeed'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@scrollSpeed']) == nil || $receiver == undefined) ? (function(){return self['@scrollSpeed']=(5);})() : $receiver;
return self;},
args: [],
source: unescape('scrollSpeed%0A%09%5E%20scrollSpeed%20ifNil%3A%20%5BscrollSpeed%20%3A%3D%205%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.SmallCave);

smalltalk.addMethod(
unescape('_end'),
smalltalk.method({
selector: unescape('end'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_end", [], smalltalk.Game);
smalltalk.send((typeof window == 'undefined' ? nil : window), "_alert_", [smalltalk.send(smalltalk.send(unescape("OUCH%21%20Your%20score%20is%20"), "__comma", [smalltalk.send(smalltalk.send(self, "_stepCount", []), "_asString", [])]), "__comma", [unescape(".%20Refresh%20the%20page%20to%20try%20again%21")])]);
return self;},
args: [],
source: unescape('end%0A%09super%20end.%0A%09window%20alert%3A%20%27OUCH%21%20Your%20score%20is%20%27%20%2C%20self%20stepCount%20asString%20%2C%20%27.%20Refresh%20the%20page%20to%20try%20again%21%27'),
messageSends: ["end", "alert:", unescape("%2C"), "asString", "stepCount"],
referencedClasses: []
}),
smalltalk.SmallCave);



smalltalk.addClass('SokobanLevelCreator', smalltalk.Widget, ['level', 'table', 'palette', 'currentBrush', 'div', 'textarea'], 'Ludus-Examples');
smalltalk.addMethod(
unescape('_renderOn_'),
smalltalk.method({
selector: unescape('renderOn%3A'),
category: 'not yet classified',
fn: function (html){
var self=this;
smalltalk.send(self, "_renderTableOn_", [html]);
smalltalk.send(self, "_renderPaletteOn_", [html]);
(function($rec){smalltalk.send($rec, "_with_", ["Print Array"]);return smalltalk.send($rec, "_onClick_", [(function(){return smalltalk.send(self, "_renderTextAreaOn_", [html]);})]);})(smalltalk.send(html, "_button", []));
return self;},
args: ["html"],
source: unescape('renderOn%3A%20html%0A%09self%20renderTableOn%3Ahtml.%0A%09self%20renderPaletteOn%3A%20html.%0A%09html%20button%20%0A%09%09with%3A%20%27Print%20Array%27%3B%20%0A%09%09onClick%3A%20%5Bself%20renderTextAreaOn%3A%20html%5D.'),
messageSends: ["renderTableOn:", "renderPaletteOn:", "with:", "onClick:", "renderTextAreaOn:", "button"],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
unescape('_emptyLevel'),
smalltalk.method({
selector: unescape('emptyLevel'),
category: 'not yet classified',
fn: function (){
var self=this;
return [[(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)], [(0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0), (0)]];
return self;},
args: [],
source: unescape('emptyLevel%0A%5E%20%20%20%23%28%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%0A%20%20%20%20%20%20%20%23%280%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%29%29'),
messageSends: [],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
unescape('_level'),
smalltalk.method({
selector: unescape('level'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@level']) == nil || $receiver == undefined) ? (function(){return self['@level']=smalltalk.send(self, "_emptyLevel", []);})() : $receiver;
return self;},
args: [],
source: unescape('level%0A%09%5E%20level%20ifNil%3A%20%5Blevel%20%3A%3D%20self%20emptyLevel%5D'),
messageSends: ["ifNil:", "emptyLevel"],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
unescape('_renderPaletteOn_'),
smalltalk.method({
selector: unescape('renderPaletteOn%3A'),
category: 'not yet classified',
fn: function (html){
var self=this;
self['@palette']=(function($rec){smalltalk.send($rec, "_id_", ["palette"]);return smalltalk.send($rec, "_with_", [(function(){(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(7)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(7);})]);})(smalltalk.send(html, "_img", []));(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(9)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(9);})]);})(smalltalk.send(html, "_img", []));(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(1)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(1);})]);})(smalltalk.send(html, "_img", []));(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(2)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(2);})]);})(smalltalk.send(html, "_img", []));(function($rec){smalltalk.send($rec, "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [(8)])]), "__comma", ["Icon.png"])]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(8);})]);})(smalltalk.send(html, "_img", []));return (function($rec){smalltalk.send($rec, "_src_", [unescape("images/eraserIcon.png")]);return smalltalk.send($rec, "_onClick_", [(function(){return self['@currentBrush']=(0);})]);})(smalltalk.send(html, "_img", []));})]);})(smalltalk.send(html, "_table", []));
return self;},
args: ["html"],
source: unescape('renderPaletteOn%3A%20html%0A%09palette%20%3A%3D%20html%20table%0A%09%09id%3A%20%27palette%27%3B%0A%09%09with%3A%20%5B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09html%20img%20src%3A%20%27images/%27%2C%20%28self%20imageFor%3A%207%29%20%2C%20%27Icon.png%27%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09onClick%3A%20%5BcurrentBrush%20%3A%3D%207%5D.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09html%20img%20src%3A%20%27images/%27%2C%20%28self%20imageFor%3A%209%29%20%2C%20%27Icon.png%27%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09onClick%3A%20%5BcurrentBrush%20%3A%3D%209%5D.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09html%20img%20src%3A%20%27images/%27%2C%20%28self%20imageFor%3A%201%29%20%2C%20%27Icon.png%27%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09onClick%3A%20%5BcurrentBrush%20%3A%3D%201%5D.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09html%20img%20src%3A%20%27images/%27%2C%20%28self%20imageFor%3A%202%29%20%2C%20%27Icon.png%27%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09onClick%3A%20%5BcurrentBrush%20%3A%3D%202%5D.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09html%20img%20src%3A%20%27images/%27%2C%20%28self%20imageFor%3A%208%29%20%2C%20%27Icon.png%27%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09onClick%3A%20%5BcurrentBrush%20%3A%3D%208%5D.%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09html%20img%20src%3A%20%27images/eraserIcon.png%27%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%09onClick%3A%20%5BcurrentBrush%20%3A%3D%200%5D%5D'),
messageSends: ["id:", "with:", "src:", unescape("%2C"), "imageFor:", "onClick:", "img", "table"],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
unescape('_renderTableOn_'),
smalltalk.method({
selector: unescape('renderTableOn%3A'),
category: 'not yet classified',
fn: function (html){
var self=this;
self['@table']=(function($rec){smalltalk.send($rec, "_id_", ["levelTable"]);smalltalk.send($rec, "_style_", [unescape("border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B")]);return smalltalk.send($rec, "_with_", [(function(){return smalltalk.send((1), "_to_do_", [(18), (function(y){return (function($rec){smalltalk.send($rec, "_style_", [unescape("border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B")]);smalltalk.send($rec, "_id_", [y]);return smalltalk.send($rec, "_with_", [(function(){return smalltalk.send((1), "_to_do_", [(24), (function(x){var cell=nil;
return cell=(function($rec){smalltalk.send($rec, "_style_", [unescape("border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B%20background-image%3A%20url%28%22images/emptyIcon.png%22%29%3B")]);smalltalk.send($rec, "_id_", [x]);smalltalk.send($rec, "_with_", [(function(){return smalltalk.send(smalltalk.send(html, "_img", []), "_src_", [smalltalk.send(smalltalk.send(unescape("images/"), "__comma", [smalltalk.send(self, "_imageFor_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_level", []), "_at_", [y]), "_at_", [x])])]), "__comma", ["Icon.png"])]);})]);smalltalk.send($rec, "_class_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_level", []), "_at_", [y]), "_at_", [x])]);return smalltalk.send($rec, "_onClick_", [(function(){smalltalk.send(smalltalk.send(smalltalk.send(self, "_level", []), "_at_", [y]), "_at_put_", [x, self['@currentBrush']]);return smalltalk.send(self, "_updateTable", []);})]);})(smalltalk.send(html, "_td", []));})]);})]);})(smalltalk.send(html, "_tr", []));})]);})]);})(smalltalk.send(html, "_table", []));
return self;},
args: ["html"],
source: unescape('renderTableOn%3Ahtml%0A%09table%20%3A%3D%20html%20table%0A%09%09id%3A%20%27levelTable%27%3B%0A%09%09style%3A%20%27border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B%27%3B%0A%09%09with%3A%20%5B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%091%20to%3A%2018%20do%3A%20%5B%3Ay%20%7C%20%0A%09%09%09%09html%20tr%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09style%3A%20%27border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B%27%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09id%3A%20y%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09with%3A%20%5B%201%20to%3A%2024%20do%3A%20%5B%3Ax%20%7C%0A%09%09%09%09%09%09%7Ccell%7C%0A%09%09%09%09%09%09cell%20%3A%3D%20html%20td%20%0A%09%09%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09style%3A%20%27border-spacing%3A%200%3B%20height%3A%200px%3B%20width%3A%200px%3B%20padding%3A%200%3B%20margin%3A%200%3B%20font%3A%200px%20serif%3B%20background-image%3A%20url%28%22images/emptyIcon.png%22%29%3B%27%3B%0A%09%09%09%09%09%09%09id%3A%20x%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20with%3A%20%5B%20html%20img%20src%3A%20%27images/%27%2C%20%28self%20imageFor%3A%20%28%28self%20level%20at%3A%20y%29%20at%3A%20x%29%29%20%2C%20%27Icon.png%27%20%5D%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20class%3A%20%28%28self%20level%20at%3A%20y%29%20at%3A%20x%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20onClick%3A%20%5B%0A%09%09%09%09%09%09%09%09%28self%20level%20at%3A%20y%29%20at%3A%20x%20put%3A%20%28currentBrush%29.%20%0A%09%09%09%09%09%09%09%09self%20updateTable%5D%5D%5D%5D%5D.'),
messageSends: ["id:", "style:", "with:", "to:do:", "src:", "img", unescape("%2C"), "imageFor:", "at:", "level", "class:", "onClick:", "at:put:", "updateTable", "td", "tr", "table"],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
unescape('_imageFor_'),
smalltalk.method({
selector: unescape('imageFor%3A'),
category: 'not yet classified',
fn: function (anInteger){
var self=this;
return smalltalk.send(smalltalk.Dictionary._fromPairs_([smalltalk.send((7), "__minus_gt", ["box"]),smalltalk.send((9), "__minus_gt", ["exit"]),smalltalk.send((1), "__minus_gt", ["wall"]),smalltalk.send((2), "__minus_gt", ["floor"]),smalltalk.send((8), "__minus_gt", ["guy"]),smalltalk.send((0), "__minus_gt", ["no"])]), "_at_", [anInteger]);
return self;},
args: ["anInteger"],
source: unescape('imageFor%3A%20anInteger%0A%09%5E%20%23%7B7%20-%3E%20%27box%27.%209%20-%3E%20%27exit%27.%201%20-%3E%20%27wall%27.%202%20-%3E%20%27floor%27.%208%20-%3E%20%27guy%27.%200%20-%3E%20%27no%27%20%7D%20at%3A%20anInteger'),
messageSends: ["at:", unescape("-%3E")],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
unescape('_initialize'),
smalltalk.method({
selector: unescape('initialize'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_initialize", [], smalltalk.Widget);
self['@currentBrush']=(0);
return self;},
args: [],
source: unescape('initialize%0A%09super%20initialize.%0A%09currentBrush%20%3A%3D%200.'),
messageSends: ["initialize"],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
unescape('_updateTable'),
smalltalk.method({
selector: unescape('updateTable'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self['@table'], "_contents_", [(function(html){return smalltalk.send(self, "_renderTableOn_", [html]);})]);
return self;},
args: [],
source: unescape('updateTable%0A%09table%20contents%3A%20%5B%3Ahtml%20%7C%20self%20renderTableOn%3A%20html%5D.'),
messageSends: ["contents:", "renderTableOn:"],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator);

smalltalk.addMethod(
unescape('_renderTextAreaOn_'),
smalltalk.method({
selector: unescape('renderTextAreaOn%3A'),
category: 'not yet classified',
fn: function (html){
var self=this;
self['@textarea']=smalltalk.send(smalltalk.send(html, "_textarea", []), "_with_", [smalltalk.send(smalltalk.send(smalltalk.send(self, "_level", []), "_asString", []), "_replace_with_", ["a Array ", smalltalk.send(smalltalk.send((smalltalk.String || String), "_cr", []), "__comma", [unescape("%23")])])]);
return self;},
args: ["html"],
source: unescape('renderTextAreaOn%3A%20html%0A%09textarea%20%3A%3D%20html%20textarea%20with%3A%20%28self%20level%20asString%20replace%3A%20%27a%20Array%20%27%20with%3A%20String%20cr%20%2C%20%27%23%27%29'),
messageSends: ["with:", "textarea", "replace:with:", "asString", "level", unescape("%2C"), "cr"],
referencedClasses: ["String"]
}),
smalltalk.SokobanLevelCreator);


smalltalk.addMethod(
unescape('_open'),
smalltalk.method({
selector: unescape('open'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(smalltalk.send(self, "_new", []), "_appendToJQuery_", [smalltalk.send("body", "_asJQuery", [])]);
return self;},
args: [],
source: unescape('open%0A%09self%20new%20appendToJQuery%3A%20%27body%27%20asJQuery'),
messageSends: ["appendToJQuery:", "new", "asJQuery"],
referencedClasses: []
}),
smalltalk.SokobanLevelCreator.klass);


smalltalk.addClass('Ship', smalltalk.Sprite, ['speed'], 'Ludus-Examples');
smalltalk.addMethod(
unescape('_initialize'),
smalltalk.method({
selector: unescape('initialize'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_initialize", [], smalltalk.Sprite);
(function($rec){smalltalk.send($rec, "_spriteSheet_", [unescape("images/trail.png")]);return smalltalk.send($rec, "_addFrameGroupNamed_origin_size_frameCount_", ["ship", smalltalk.send((0), "__at", [(0)]), smalltalk.send((10), "__at", [(10)]), (1)]);})(self);
return self;},
args: [],
source: unescape('initialize%0A%09super%20initialize.%0A%09self%20spriteSheet%3A%20%27images/trail.png%27%3B%0A%09%09addFrameGroupNamed%3A%20%27ship%27%20origin%3A%200@0%20size%3A%2010@10%20frameCount%3A%201.'),
messageSends: ["initialize", "spriteSheet:", "addFrameGroupNamed:origin:size:frameCount:", unescape("@")],
referencedClasses: []
}),
smalltalk.Ship);

smalltalk.addMethod(
unescape('_speed'),
smalltalk.method({
selector: unescape('speed'),
category: 'not yet classified',
fn: function (){
var self=this;
return (($receiver = self['@speed']) == nil || $receiver == undefined) ? (function(){return self['@speed']=(0);})() : $receiver;
return self;},
args: [],
source: unescape('speed%0A%09%5E%20speed%20ifNil%3A%20%5Bspeed%20%3A%3D%200%5D'),
messageSends: ["ifNil:"],
referencedClasses: []
}),
smalltalk.Ship);

smalltalk.addMethod(
unescape('_speed_'),
smalltalk.method({
selector: unescape('speed%3A'),
category: 'not yet classified',
fn: function (aSpeed){
var self=this;
self['@speed']=aSpeed;
return self;},
args: ["aSpeed"],
source: unescape('speed%3A%20aSpeed%0A%09speed%20%3A%3D%20aSpeed'),
messageSends: [],
referencedClasses: []
}),
smalltalk.Ship);

smalltalk.addMethod(
unescape('_increaseSpeed'),
smalltalk.method({
selector: unescape('increaseSpeed'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_speed_", [((($receiver = smalltalk.send(self, "_speed", [])).klass === smalltalk.Number) ? $receiver +(0.5) : smalltalk.send($receiver, "__plus", [(0.5)]))]);
return self;},
args: [],
source: unescape('increaseSpeed%0A%09self%20speed%3A%20self%20speed%20+%200.05'),
messageSends: ["speed:", unescape("+"), "speed"],
referencedClasses: []
}),
smalltalk.Ship);

smalltalk.addMethod(
unescape('_decreaseSpeed'),
smalltalk.method({
selector: unescape('decreaseSpeed'),
category: 'not yet classified',
fn: function (){
var self=this;
smalltalk.send(self, "_speed_", [((($receiver = smalltalk.send(self, "_speed", [])).klass === smalltalk.Number) ? $receiver -(0.5) : smalltalk.send($receiver, "__minus", [(0.5)]))]);
return self;},
args: [],
source: unescape('decreaseSpeed%0A%09self%20speed%3A%20self%20speed%20-%200.05'),
messageSends: ["speed:", unescape("-"), "speed"],
referencedClasses: []
}),
smalltalk.Ship);



